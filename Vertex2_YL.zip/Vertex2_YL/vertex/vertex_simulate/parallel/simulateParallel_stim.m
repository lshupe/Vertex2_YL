function [NeuronModel, SynModel, InModel, numSaves] = ...
    simulateParallel_stim(TP, NP, SS, RS, ...
    IDMap, NeuronModel, SynModel, InModel,DVModel, RecVar, lineSourceModCell, synArr, wArr, synMap, nsaves,paraStimParam)
%Parallel version of simulate.
% Change log:
% 10/26/2022 Forked from StimulateParallel.m for more flexible field
% 10/27/2022 Changes to accommadate multiple fields and combined fields.
% 10/27/2022 Changes to handle symmetric biphasic stimulation.
% 10/16/2023 Clean up field stimulation to simplify starting a stimulation.

outputDirectory = RS.saveDir;
if ~strcmpi(outputDirectory(end), '/')
    outputDirectory = [outputDirectory '/'];
end
    
nIntSize = 'uint32';
tIntSize = 'uint16';

%excitatory = [NP.isExcitatory];
groupComparts = [NP.numCompartments];

N = TP.N;
numInGroup = TP.numInGroupInLab;
neuronInGroup = createGroupsFromBoundaries(TP.groupBoundaryIDArr);
bufferLength = SS.maxDelaySteps;
if ~isempty(DVModel)
    bufferLengthDV = SS.maxDelayStepsDV;
end
simulationSteps = round(SS.simulationTime / SS.timeStep);

if isfield(SS,'spikeLoad')
    S.spikeLoad = SS.spikeLoad;
else
    S.spikeLoad = false;
end

if S.spikeLoad
    inputDirectory = SS.spikeLoadDir;
    if ~strcmpi(inputDirectory(end), '/')
        inputDirectory = [inputDirectory '/'];
    end
end

[cpexLoopTotal, partnerLab] = cpexGetExchangePartners();

if nargin == 14
    ns = 0;
    paraStimParam = [];
else
    ns = nsaves;
end
% set field inputs
stdp = SS.stdp;
% for iPostGroup = 1:TP.numGroups
%     for iGroup = 1:size(SynModel,2)
%         synm = SynModel{1};
%         if  ~isempty(synm{iPostGroup, iGroup})
%             if isa(synm{iPostGroup, iGroup}, 'STDPModel')
%                 stdp = true;
%             end
%         end
%     end
% end

if stdp
    disp('Using stdp, so calculating postsynaptic to presynaptic map');
    %Calculate reversed synapse array on each node
    spmd
        posttoprearr = reverseSynArr(synArr);
        disp('Map calculated');
    end
    %combine reversed array from each node into a single array
    revSynArr = posttoprearr{1};
    for iLab = 1:length(posttoprearr)
        currLabSynArr = posttoprearr{iLab};
        revSynArr(~cellfun(@isempty,currLabSynArr(:,1)),1) = currLabSynArr(~cellfun(@isempty,currLabSynArr(:,1)),1);
        revSynArr(~cellfun(@isempty,currLabSynArr(:,2)),2) = currLabSynArr(~cellfun(@isempty,currLabSynArr(:,2)),2);
        revSynArr(~cellfun(@isempty,currLabSynArr(:,3)),3) = currLabSynArr(~cellfun(@isempty,currLabSynArr(:,3)),3);
    end
    %revSynArr = distributed(revSynArr);
    clear posttoprearr;
end

spmd
    %Get the neuron ids processed in this lab
    subsetInLab = find(SS.neuronInLab==labindex());
    
    % x = compartments{1:10,labindex()}
    %if we are applying an electric field stimulus
    %     if SS.ef_stimulation
    %         % get compartments locations in suitable vectorised form
    %         % for each neuron group
    %         for iGroup = 1:TP.numGroups
    %             %Get neuron ids of neurons in this group and in this lab
    %             ingroupinlab = subsetInLab(neuronInGroup(subsetInLab)==iGroup);
    %              x = {compartments{ingroupinlab,1}};
    %              y = {compartments{ingroupinlab,2}};
    %              z = {compartments{ingroupinlab,3}};
    %             [StimParams.compartmentlocations{iGroup,1}, StimParams.compartmentlocations{iGroup,2}] = ...
    %                 convertcompartmentlocations(x,y,z);
    %         end
    %
    %         %Calculate the activation function for each compartment
    %         %Can be called on each iteration if the input field is time varying
    %         StimParams.activation = getExtracellularInput(TP, StimParams,1,NeuronModel,NP);
    %
    %     end
    %
    %      %if we are applying an focussed ultrasound
    %     if SS.fu_stimulation
    %         %Get compartments in suitable  vectorised form
    %         for iGroup = 1:TP.numGroups
    %             ingroupinlab = subsetInLab(neuronInGroup(subsetInLab)==iGroup);
    %             [StimParams.compartmentlocations{iGroup,1}, StimParams.compartmentlocations{iGroup,2}] = ...
    %                 convertcompartmentlocations({TP.compartmentlocations{ingroupinlab,1}},...
    %                 {TP.compartmentlocations{ingroupinlab,2}},{TP.compartmentlocations{ingroupinlab,3}});
    %         end
    %         %Calculate the ultrasound value function for each compartment
    %         %Can be called on each iteration if the input field is time varying
    %         StimParams.ultrasound = getUltraSoundAtCompartments(TP, StimParams,0);
    %     end
      
    recordIntra = RecVar.recordIntra;
    recordI_syn = RecVar.recordI_syn;
    recordstp_syn = RecVar.recordstp_syn;
    recordWeights = RecVar.recordWeights;
    recordWeightsArr = RecVar.recordWeightsArr;
    recordstdpvars = RecVar.recordstdpvars;
    weightsArrcount = 1;
    comCount = SS.minDelaySteps;
    
    saveWeightsCount = 0; % Assume weights are not saved mid-simulation ...
    if isfield(RS, 'weight_save_time_steps') && ~isempty(RS.weight_save_time_steps) % ... unless defined
        saveWeightsCount = 1; % Increments for each saved weight file.
    end
    
    % vars to keep track of where we are in recording buffers:
    
    recTimeCounter = 1;
    sampleStepCounter = 1;
    spikeRecCounter = 1;
    
    % vars to keep track of spikes
    S.spikes = zeros(N * SS.minDelaySteps, 1, nIntSize);
    S.spikeStep = zeros(N * SS.minDelaySteps, 1, tIntSize);
    receivedSpikes = cell(numlabs, 2);
    receivedVectors = cell(numlabs,1);
    S.spikeCount = zeros(1, 1, nIntSize);
    %numSaves = 0;
    numSaves = 1;
    
    if S.spikeLoad
        fName = sprintf('%sRecordings%d_.mat', inputDirectory, numSaves+ns);
        loadedSpikes = pload(fName);
    end
    
    % LFP electrode recordings can be used for closed-loop stimulation.
    % If enabled, the mean LFP will be calculated at each simstep where 
    % LFP is saved, and the closed loop condition will be tested then.
    if isfield(TP, 'LFP_filter_band')
        [LFP_filterB, LFP_filterA] = butter(1, TP.LFP_filter_band * 2 / RS.sampleRate, 'bandpass');
        LFP_filterZ = zeros(1, max(length(LFP_filterB), length(LFP_filterA)) - 1); % filter state
        %disp(['filter band w= ' num2str(TP.LFP_filter_band * 2 / RS.sampleRate)]);
    else
        % If no filter band is given, use a wide-band filter
        [LFP_filterB, LFP_filterA] = butter(1, [1 RS.sampleRate/4] * 2 / RS.sampleRate, 'bandpass');
        LFP_filterZ = zeros(1, max(length(LFP_filterB), length(LFP_filterA)) - 1); % filter state
    end 
    if isfield(TP, 'LFP_filter_index')
        % Recorded LFP channels used for average of LFP
        LFP_filter_index = TP.LFP_filter_index;
    else
        % Use all LFP channels
        LFP_filter_index = 1:size(RecVar.LFPRecording{1}, 1);
    end

    LFP_oldlevel = 0; % Previous LFP level.
    LFP_lastmax = 0;  % Last LFP maximum before next rising 0 crossing.
    LFP_lastmin = 0;  % Last LFP minimum before next falling 0 crossing.
    LFP_opto_response_amplitude = 0; % maximum LFP since last opto stim.
    LFP_stim_response_amplitude = 0; % maximum LFP since last field stim.

    if isfield(TP, 'LFP_trigger_direction') && (TP.LFP_trigger_direction ~= 0)
        LFP_trigger_next_possible_time = TP.stim_start_ms; % next possible trigger time. -1 to stop future triggers
        %disp(['Closed-loop trigger on LFP starts at ms ' num2str(LFP_trigger_next_possible_time)]);
    else
        LFP_trigger_next_possible_time = -1; % LFP threshold trigger is off.
    end

    % Field stimulation parameters
    stim_pattern_count = 1;
    stim_pattern_time = []; % Times for pattern stimulation (ms)
    if isfield(TP, 'stim_ms')     
        stim_pattern_time = TP.stim_ms;  % Predefined stimulation times
    end

    stim_phases = 1; % Default is monophasic stimulation
    if isfield(TP, 'stim_phases')
        stim_phases = TP.stim_phases;
    end
    if (stim_phases > 0) && (stim_phases < 1)
        stim_phase_switch = stim_phases; % Direct specification of the fraction of the pulse duration to spend in the first phase.
    elseif stim_phases == 1
        stim_phase_switch = 1; % monophasic pulses.
    elseif stim_phases == 2
        stim_phase_switch = 0.5; % biphasic pulses switch at halfway between the stim_on and stim_off time.
    else
        disp('**WARNING: TP.stim_phases should be 1 (monophasic) or 2 (biphasic), or specifiy a fractional value > 0 and < 1');
        disp('**Using biphasic stimulation');
        stim_phase_switch = 0.5; % biphasic pulses switch at halfway between the stim_on and stim_off time.
    end
 
    stimcount = 1;
    stim_on_time = [];
    stim_off_time = [];
    stim_vext_index = 1;  % Index of current field stimulation
    record_next_stim_event = true;
    if isfield(TP, 'StimulationOn')
        % Handle cases where TP.StimulationOn/Off were specified directly.
        stim_on_time = TP.StimulationOn;
        stim_off_time = TP.StimulationOff;
    end

    % Optical stimulation parameters
    opto_start_timestep = []; % Can be altered during the simulation loop to hold closed_loop stimulation starting timesteps.
    opto_start_index = 1;     % Which opto_start_timestep is next.
    if isfield(TP, 'opto_stim_timesteps')
        opto_start_timestep = TP.opto_stim_timesteps;
    end
    
    % Other variables
    timeStimStep = 1;
    numspikes=0;
    weightdiff = 0;

    %%
    % Simulation loop

    labBarrier();       
    tic;

    for simStep = 1:simulationSteps
        current_time = simStep * SS.timeStep; % Get current time in ms
        
        %%%%
        % Optical stimulation code block
        if opto_start_index <= length(opto_start_timestep)
            if simStep == opto_start_timestep(opto_start_index)
                opto_start_index = opto_start_index + 1;
                for iopto = 1:length(TP.opto_source_power_mW) % Number of light sources
                    % Light source and Pulse train parameters can be
                    % changed before the optical stimulation is delivered.
                    % If they are modified, then OptoSetupLightSource()
                    % and OptoSetupPulseTrain() must be called in the
                    % following loop.  Example:
                    %TP.opto_pulse_duration_ms(iopto) = TP.opto_pulse_duration_ms(iopto) + 1; % Test change in pulse duration parameter
                    %TP.opto_pulse_count(iopto) = TP.opto_pulse_count(iopto) + 1;          % Test change to pulse train parameter
                    %TP.opto_source_power_mW(iopto) = TP.opto_source_power_mW(iopto) + 1;  % Test change to light source parameter

                    % Adjust stimulus amplitude to keep LFP response in a magnitude range.
                    if isfield(TP, 'LFP_opto_max_response') &&  (LFP_opto_response_amplitude > TP.LFP_opto_max_response) 
                        TP.opto_source_power_mW(iopto) = TP.opto_source_power_mW(iopto) / TP.LFP_opto_scaler;               
                    elseif isfield(TP, 'LFP_opto_min_response') &&  (LFP_opto_response_amplitude < TP.LFP_opto_min_response) 
                        TP.opto_source_power_mW(iopto) = TP.opto_source_power_mW(iopto) * TP.LFP_opto_scaler;                         
                    end
%                     if (iopto == 1) &&  (labindex() == 1)
%                         % Display power for first light source
%                         disp(['Opto stim1 power mW: ' num2str(TP.opto_source_power_mW(iopto))]);
%                     end

                    % Start optical stimulation pulse train for each
                    % affected neuron group.
                    opto_groups = TP.opto_neuron_groups{iopto};
                    for index = 1:length(opto_groups)
                        iGroup = opto_groups(index);
                        iIn = TP.opto_input_model_index(iGroup, iopto);
                        OptoSetupLightSource(InModel{iGroup, iIn}, TP); % Must be called if light source parameters were modified.
                        OptoSetupPulseTrain(InModel{iGroup, iIn}, TP);  % Must be called if pulse train parameters were modified.
                        OptoStartPulseTrain(InModel{iGroup, iIn}, 0);   % Start the modified pulse train.
                    end
                    % Create an event to mark this stimulation
                    RecVar.nevents = RecVar.nevents + 1;
                    RecVar.events(RecVar.nevents) = struct('marker', 'o', ...
                        'time_ms', current_time + TP.opto_train_delay_ms(iopto), 'id', iopto, ...
                        'info', ['width_ms ' num2str(TP.opto_pulse_duration_ms(iopto)) ' count ' num2str(TP.opto_pulse_count(iopto))]);
                end
                LFP_opto_response_amplitude = 0; % Reset response level
           end
        end
        % End optical stimulation code block
        %%%% 
        
        %%%%
        % Field stimulation code block
        % Turns stimulation dynamics on or off for neuron groups

        if stim_pattern_count <= length(stim_pattern_time)
            % Pattern stimulation times are defined.  Closed-loop field
            % stimulation could set this up during the simulation and
            % modify TP.stim_width_ms, TP.stim_delay_ms, and
            % TP.stim_field_scale for the next pattern stimulation.
            if current_time >= stim_pattern_time(stim_pattern_count)
                % Time for next pattern stimulation
                if isfield(TP, 'LFP_stim_max_response') && (LFP_stim_response_amplitude > TP.LFP_stim_max_response)
                    TP.stim_field_scale = TP.stim_field_scale / TP.LFP_stim_scaler;
                elseif isfield(TP, 'LFP_stim_min_response') && (LFP_stim_response_amplitude < TP.LFP_stim_min_response)
                    TP.stim_field_scale = TP.stim_field_scale * TP.LFP_stim_scaler;
                end
                [stim_on_time, stim_off_time, stim_vext_index] = SetupFieldStimulatonPattern(TP, current_time);
                stimcount = 1;
                stim_pattern_count = stim_pattern_count + 1;
                LFP_stim_response_amplitude = 0;
%                 if (labindex() == 1)
%                     % Display pulse amplitude for first stim channel
%                     disp(['Field stim1 mV: ' num2str(TP.stim_size(1) .* TP.stim_field_scale(1))]);
%                 end
            end
        end

        if stimcount <= length(stim_on_time)
            % If the current time is greater than the next stimulation
            % start time then turn field stimulation on.
            if current_time >= stim_on_time(stimcount) && current_time < stim_off_time(stimcount)
                iField = 1; % Default stimulation field
                for iGroup = 1:TP.numGroups
                    if ~NeuronModel{iGroup}.incorporate_vext
                        stimulationOn(NeuronModel{iGroup});
                    end
                    % For time varying stimulation, step through the time
                    % dimension of the vext matrix for each simStep where
                    % stimulation is active. The vext matrix should have
                    % been previously interpolated in runSimulation.
                    if ~isempty(stim_vext_index)
                        % Each stimulus can apply a different static V_ext
                        % field with a scaling amplitude.
                        iField = stim_vext_index(stimcount);
                        stimScale = TP.stim_field_scale(iField);
                        % Invert field for last half of the duration for symmetric biphasic stimulation.
                        if current_time < stim_phase_switch * (stim_on_time(stimcount) + stim_off_time(stimcount))
                            setVext(NeuronModel{iGroup}, stimScale * paraStimParam(iGroup).V_ext_mat(:,:,iField));
                        else
                            setVext(NeuronModel{iGroup}, -stimScale * paraStimParam(iGroup).V_ext_mat(:,:,iField));
                        end
                        if record_next_stim_event
                            % Create an event to mark beginning of this stimulation
                            RecVar.nevents = RecVar.nevents + 1;
                            RecVar.events(RecVar.nevents) = struct('marker', num2str(iField), ...
                                'time_ms', current_time, 'id', iField, ...
                                'info', ['scale ' num2str(stimScale)]);
                            record_next_stim_event = false;
                            %disp('stim');
                        end
                    elseif isa(TP.StimulationField, 'pde.TimeDependentResults')
                        setVext(NeuronModel{iGroup},paraStimParam(iGroup).V_ext_mat(:,:,timeStimStep));
                    elseif isfield(TP,'tRNS')
                        setVext(NeuronModel{iGroup},NeuronModel{iGroup}.v_ext*TP.tRNS);
                    end
                end
                
                if isfield(TP,'tRNS')
                    TP.tRNS=wgn(1,1,0);
                end
                
                timeStimStep = timeStimStep+1;
                % reset timeStimStep if it gets passed the length of the
                % time dimension in the stimulation field, this will loop
                % back to the beginning of the time varying stimulation.
                if timeStimStep > size(TP.StimulationField(iField).NodalSolution,2)
                    timeStimStep = 1;
                end
            elseif current_time >= stim_off_time(stimcount)
                % Turn stimulation off
                for iGroup = 1:TP.numGroups
                    if NeuronModel{iGroup}.incorporate_vext
                        stimulationOff(NeuronModel{iGroup});
                    end
                end 
                % Get ready for next stimulation pulse.
                stimcount = stimcount+1;  
                record_next_stim_event = true;
            end          
        end 
        % End field stimulation code block
        %%%%
        
        %Update weight recording
        %Records all weights from presynaptic neurons specified to the
        %users to all neurons in this lab. Results are compiled in
        %loadResults.
        if simStep == RS.samplingSteps(sampleStepCounter)
            if recordWeights
                RecVar = updateWeightsRecording(RecVar,recTimeCounter,wArr);
            end
        end
        
        if saveWeightsCount
            if (saveWeightsCount <= length(RS.weight_save_time_steps)) && ...
                    (simStep >= RS.weight_save_time_steps(saveWeightsCount))               
                % Save current weights to a file: 'weightsN_M.mat'
                fName = sprintf('weights%d_.mat', saveWeightsCount);
                saveDataSPMD(outputDirectory, fName, wArr);
                saveWeightsCount = saveWeightsCount + 1;
                %disp(['Saved weights file: ' outputDirectory fName ' for each group, timestep ' num2str(simStep)]);
            end
        end
        
        if recordWeightsArr           
            if weightsArrcount <= length(RS.weights_arr) && simStep == RS.weights_arr(weightsArrcount)
%                 disp(['recording weights ' num2str(weightsArrcount)]);
%                 disp(['simstep: ' num2str(simStep)]);
%                 disp(['rectime: ' num2str(RS.weights_arr(weightsArrcount))]);
                RecVar.WeightArrRec{weightsArrcount} = wArr;
                weightsArrcount = weightsArrcount+1;
            end
        end
        
        for iGroup = 1:TP.numGroups
            
            [NeuronModel, SynModel, InModel, wArr] = ...
                groupUpdateSchedule(NP,TP,SS,NeuronModel,SynModel,InModel,iGroup,synArr,wArr, IDMap, neuronInGroup);
            
            
            S = addGroupSpikesToSpikeList(NeuronModel,IDMap,S,iGroup,comCount);
            
            % store group-collected recorded variables for membrane potential:
            if simStep == RS.samplingSteps(sampleStepCounter)
                if recordIntra
                    RecVar = ...
                        updateIntraRecording(NeuronModel,RecVar,iGroup,recTimeCounter);
                end
                
                % for synaptic currents:
                
                if recordI_syn
                    RecVar = ...
                        updateI_synRecording(SynModel,synMap,RecVar,iGroup,recTimeCounter);
                end
                
                % for LFP:
                if RS.LFP && NP(iGroup).numCompartments ~= 1
                    RecVar = ...
                        updateLFPRecording(RS,NeuronModel,RecVar,lineSourceModCell,iGroup,recTimeCounter);
                    %disp(num2str(RecVar.LFPRecording{1}(1,recTimeCounter)));
                end
                if RS.CSD 
                    RecVar = updateCSDRecording(RS, NeuronModel, RecVar, iGroup, recTimeCounter);
                end
                if recordstp_syn
                    RecVar = updateSTPVarsRecording(SynModel,RecVar,iGroup,recTimeCounter,synMap,neuronInGroup,TP);
                end
                
                if recordstdpvars
                    RecVar = updateSTDPVarsRecording(SynModel,RecVar,iGroup,recTimeCounter,synMap,neuronInGroup,TP);
                end
                if RS.I_synComp
                    RecVar = updateI_synCompRecording(RS,SynModel,synMap, RecVar,iGroup,recTimeCounter);
                end
                
            end
            
        end % for each group
        
        %% RIYA JAIN, Closed-loop LFP calculations.
        % If LFP is used as a condition for closed-loop stimulation,
        % communicate LFP between Labs only at times where LFP is saved
        % which is typically once per millisecond.
        % Calculate LFP(iElectrode) as the LFP contribution from all
        % neuron groups across all Labs at each LFP electrode.
        
        if simStep == RS.samplingSteps(sampleStepCounter)
            LFP = RecVar.LFPRecording{1}(:,recTimeCounter);
            for iGroup = 2:TP.numGroups
                % LFP accross all groups
                LFP = LFP + RecVar.LFPRecording{iGroup}(:,recTimeCounter);
            end
            if numlabs > 1
                % LFP accross all Labs
                labLFP = LFP; % This lab's LFP contribution
                destination = 1 + mod(labindex, numlabs); % Next Lab
                source = 1 + mod(labindex - 2, numlabs);  % Previous Lab
                % Send each Lab's LFP around to other labs as if in a ring buffer
                for iLab = 2:numlabs
                    labLFP = labSendReceive(destination, source, labLFP);
                    LFP = LFP + labLFP; % Each Lab will get a copy of the total LFP
                    labBarrier();
                end
            end

            % Filter the selected LFP.  Keep track of min and max.
            [LFP_level, LFP_filterZ] = filter(LFP_filterB, LFP_filterA, mean(LFP(LFP_filter_index)), LFP_filterZ);
            LFP_lastmax = max(LFP_lastmax, LFP_level);
            LFP_lastmin = min(LFP_lastmin, LFP_level);
            LFP_opto_response_amplitude = max(LFP_opto_response_amplitude, abs(LFP_level)); % maximum LFP since last opto stim.
            LFP_stim_response_amplitude = max(LFP_stim_response_amplitude, abs(LFP_level)); % maximum LFP since last field stim.

            % Closed loop triggers off of LFP thrshold crossings
            if LFP_trigger_next_possible_time >= 0
                % Reset min and max LFP each time LFP crosses 0.
                if (LFP_level * LFP_oldlevel < 0)
                    if LFP_level > 0
                        LFP_lastmax = LFP_level;
                    else
                        LFP_lastmin = LFP_level;
                    end
                end
                % Check for closed-loop LFP trigger condition
                if (current_time >= LFP_trigger_next_possible_time) && (current_time < TP.stim_stop_ms)
                    if (TP.LFP_trigger_direction >= 0) % Rising through trigger level
                        if (LFP_oldlevel < TP.LFP_trigger_level) && (LFP_level >= TP.LFP_trigger_level) && (-LFP_lastmin >= TP.LFP_trigger_amplitude)
                            LFP_trigger_next_possible_time = current_time + TP.LFP_trigger_refractory_ms; % trigger now
                            %disp(['CL Rising Trig: LFP max, min: ' num2str(LFP_lastmax) ', ' num2str(LFP_lastmin)]);
                        end
                    else % Falling through trigger level
                        if (LFP_oldlevel > TP.LFP_trigger_level) && (LFP_level <= TP.LFP_trigger_level) && (LFP_lastmax >= TP.LFP_trigger_amplitude)
                            LFP_trigger_next_possible_time = current_time + TP.LFP_trigger_refractory_ms; % trigger now
                            %disp(['CL Falling Trig: LFP min, max: ' num2str(LFP_lastmin) ', ' num2str(LFP_lastmax)]);
                        end
                    end
                    if LFP_trigger_next_possible_time > current_time
                        if isfield(TP, 'stim_ms')
                            stim_pattern_time = current_time; % Start close-loop field stim on next time step
                            stim_pattern_count = 1;
                        end
                        if isfield(TP, 'opto_stim_ms')
                            opto_start_timestep = simStep + 1; % Start close-loop opto stim on next time step
                            opto_start_index = 1;
                            %disp('CL Optostim start');
                        end
                    end
                end
            end

            LFP_oldlevel = LFP_level;
        end
        %%

        % Disease Vector
        if RS.DV
            if simStep == RS.samplingSteps(sampleStepCounter)
                RecVar = updateDVRecording(DVModel, RecVar,recTimeCounter);
            end
        end
 
        if ~isempty(DVModel)
            updateDiseaseVectorModel(DVModel, SS.timeStep);
            updateBuffer(DVModel);
        end

        % increment the recording sample pointer
        if simStep == RS.samplingSteps(sampleStepCounter)
            recTimeCounter = recTimeCounter + 1;
            
            % Only increment sampleStepCounter if this isn't the last scheduled
            % recording step
            if sampleStepCounter < length(RS.samplingSteps)
                sampleStepCounter = sampleStepCounter + 1;
            end
        end
        
        % communicate spikes
        if comCount == 1
            % update neuron event queues
            % first process own spikes
            if ~S.spikeLoad
                if S.spikeCount ~= 0
                    receivedSpikes(labindex(), :) = {S.spikes(1:S.spikeCount), ...
                        S.spikeStep(1:S.spikeCount)};
                else
                    receivedSpikes(labindex(), :) = {zeros(0, nIntSize), ...
                        zeros(0, tIntSize)};
                end
            else
                tt = loadedSpikes.data.spikeRecording{spikeRecCounter};
                toKeep = ismember(tt{1}, S.spikeLoad);
                tt{1} = tt{1}(toKeep);
                tt{2} = tt{2}(toKeep);
                if S.spikeCount ~= 0
                    tt{1} = [tt{1}; S.spikes(1:S.spikeCount)];
                    tt{2} = [tt{2}; S.spikeStep(1:S.spikeCount)];
                end
                if isempty(tt)
                    tt = {zeros(0, nIntSize), zeros(0, tIntSize)};
                end
                receivedSpikes(labindex(), :) = tt;
            end
            
            for iLab = 1:cpexLoopTotal
                if partnerLab(iLab) == -1
                    %no partner
                else
                    % exchange spikes with partner iLab
                    receivedSpikes(partnerLab(iLab), :) = ...
                        labSendReceive(partnerLab(iLab), partnerLab(iLab), ...
                        receivedSpikes(labindex(), :));
                end
                labBarrier();
            end % for each pairwise exchange
            %disp(receivedSpikes)
            % Record the spikes
            RecVar.spikeRecording{spikeRecCounter} = ...
                receivedSpikes(labindex(), :);
            spikeRecCounter = spikeRecCounter + 1;
            allSpike = cell2mat(receivedSpikes(:, 1));
            allSpikeTimes = cell2mat(receivedSpikes(:, 2));
            if labindex() == 1
                numspikes = numspikes +length(allSpike);
            end
            
            % Transmit the disease vector between labs
            if ~isempty(DVModel)
                receivedVectors{labindex()} = [];
                if ~isempty(receivedSpikes{labindex(), 1})
                    [~,ind] = ismember(allSpike,subsetInLab);
                    inD = nonzeros(ind);
                    if ~isempty(ind)
                        receivedVectors{labindex()} = DVModel.pC(:,inD)';
                    end
                end
                
                for iLab = 1:cpexLoopTotal
                    if partnerLab(iLab) == -1
                        %no partner
                    else
                        % exchange spikes with partner iLab
                        receivedVectors(partnerLab(iLab),:) = ...
                            labSendReceive(partnerLab(iLab), partnerLab(iLab), ...
                            receivedVectors(labindex(),:));
                    end
                    labBarrier();
                end
                % store the DV concentration traces for each neuron that has
                % fired. 
                allDVs = cell2mat(receivedVectors);

            end
            
            if ~isempty(DVModel)
                [~,spikesinlab] = ismember(subsetInLab,S.spikes(:,1));
                updatePresynapticCellsAfterSpike(DVModel, find(spikesinlab));
            end
            % Go through spikes and insert events into relevant buffers
            % mat3d(ii+((jj-1)*x)+((kk-1)*y)*x))
            for iSpk = 1:length(allSpike)
                
                % if we have are using a DV model then transmit the vector
                % across synapses which have fired.
                if ~isempty(DVModel)
                    % buffer location for synaptic transmission delay.
                    tBufferLoc = synArr{allSpike(iSpk), 3} + ...
                            DVModel.bufferCount - allSpikeTimes(iSpk);
                    tBufferLoc(tBufferLoc > bufferLength) = ...
                            tBufferLoc(tBufferLoc > bufferLength) - bufferLength;
                    
                    %buffer location of vector transport delay
                    pCBufferLoc = DVModel.pCTraceInd - synArr{allSpike(iSpk),4};
                    pCBufferLoc(pCBufferLoc < 1) = ...
                            pCBufferLoc(pCBufferLoc < 1) + bufferLengthDV;

                    [~,postNeuronInThisLab] = ismember(synArr{allSpike(iSpk), 1},subsetInLab);
                    
                    postInLab = SS.neuronInLab(synArr{allSpike(iSpk), 1})==labindex(); 

                    bufferVectorFlow(DVModel,postNeuronInThisLab,tBufferLoc(postInLab),...
                        wArr{allSpike(iSpk)}(postInLab),allDVs(iSpk,pCBufferLoc));

                    
                end
                % Get which groups the targets are in
                postInGroup = neuronInGroup(synArr{allSpike(iSpk), 1});
                for iPostGroup = 1:TP.numGroups
                    iSpkSynGroup = synMap{iPostGroup}(neuronInGroup(allSpike(iSpk)));
                    if ~isempty(SynModel{iPostGroup, iSpkSynGroup})
                        tBufferLoc = synArr{allSpike(iSpk), 3} + ...
                            SynModel{iPostGroup, iSpkSynGroup}.bufferCount - allSpikeTimes(iSpk);
                        tBufferLoc(tBufferLoc > bufferLength) = ...
                            tBufferLoc(tBufferLoc > bufferLength) - bufferLength;
                        inGroup = postInGroup == iPostGroup;
                        
                        inGroupInLab = subsetInLab(inGroup);
                        
                        if sum(inGroup ~= 0)
                            %
                            ind = ...
                                uint32(IDMap.modelIDToCellIDMap(synArr{allSpike(iSpk), 1}(inGroup), 1)') + ...
                                (uint32(synArr{allSpike(iSpk), 2}(inGroup)) - ...
                                uint32(1)) .* ...
                                uint32(numInGroup(iPostGroup, labindex())) + ...
                                (uint32(tBufferLoc(inGroup)) - ...
                                uint32(1)) .* ...
                                uint32(groupComparts(iPostGroup)) .* ...
                                uint32(numInGroup(iPostGroup, labindex()));
                            if isa(SynModel{iPostGroup, iSpkSynGroup}, 'STPModel') 
                                %synapse model function updates the stp variables and adds
                                %spikes to the buffers.
                                %we pass the id of the presynaptic neuron: allSpike(iSpk)
                                %Synapse model stores stp vars for each pre to post
                                %connection. iSpkSynGroup is the presynaptic group.
                                %on each lab we call bufferIncomingSpikes
                                %to process each spike as arrives at its
                                
                                relative_preID = allSpike(iSpk) - TP.groupBoundaryIDArr(neuronInGroup(allSpike(iSpk)));

                                SynModel{iPostGroup, iSpkSynGroup} = bufferIncomingSpikes( ...
                                    SynModel{iPostGroup, iSpkSynGroup}, ...
                                    ind, wArr{allSpike(iSpk)}(inGroup),relative_preID,neuronInGroup(allSpike(iSpk)));
                                
 
                            else
                                bufferIncomingSpikes(SynModel{iPostGroup, iSpkSynGroup}, ind, ...
                                    wArr{allSpike(iSpk)}(inGroup));
                            end
                            %Update synapse vars on presynaptic side
                            %Each lab only has the weights of synapses onto
                            %neurons in its group
                            if  isa(SynModel{iPostGroup, iSpkSynGroup}, 'STDPModel_delays')
                                %process spike as presynaptic spike, updating weights for
                                %post synaptic neurons in this synapse group.
                                %passing weights and group relative ids of post synaptic neurons.
                                
                                %update Apre for synapses of spiking neuron
                                %synapse model has Apre for all presynaptic neurons, Apost only for those on this lab
                                %
                                relativeSpikeID = allSpike(iSpk) - TP.groupBoundaryIDArr(neuronInGroup(allSpike(iSpk)));
                                relativepostneuronIDs = IDMap.modelIDToCellIDMap(synArr{allSpike(iSpk), 1}(inGroup), 1)';
                                processAsPreSynSpike(SynModel{iPostGroup, iSpkSynGroup},relativeSpikeID,neuronInGroup(allSpike(iSpk)),relativepostneuronIDs,tBufferLoc(inGroup) );
                            elseif isa(SynModel{iPostGroup, iSpkSynGroup}, 'STDPModel')
                                processAsPreSynSpike(SynModel{iPostGroup, iSpkSynGroup}, allSpike(iSpk) -TP.groupBoundaryIDArr(neuronInGroup(allSpike(iSpk))),neuronInGroup(allSpike(iSpk)));
                                relativepostneuronIDs = IDMap.modelIDToCellIDMap(synArr{allSpike(iSpk), 1}(inGroup), 1)';
                                wArr{allSpike(iSpk)}(inGroup) = updateweightsaspresynspike(SynModel{iPostGroup, iSpkSynGroup}, wArr{allSpike(iSpk)}(inGroup),relativepostneuronIDs);
                            end
                        end
                    end
                end
                %if we are using stdp on any synapses, then update weights on
                %connections presynaptic to the spiking neuron.
                %labBarrier();
                if stdp
                    %get all neurons presynaptic to the spiking neuron
                    % in this lab
                    presynaptic = revSynArr{allSpike(iSpk),1};
                    postsynapticlocation = revSynArr{allSpike(iSpk),2};
                    
                    preInGroup = neuronInGroup(presynaptic);
                    postGroup = neuronInGroup(allSpike(iSpk));
                    processed = false(1,TP.numGroups); %stores pre synaptic groups already processes
                    % as we process through the pre
                    % synaptic neuron groups we must make
                    % sure not to process the same pre
                    % synaptic synapse group twice.
                    
                    %for each group get neurons presynaptic to the firing neuron
                    for iPreGroup = 1:TP.numGroups
                        
                        %if the synapse between the spiking neuron and this
                        %pre synaptic group has stdp then
                        
                        
                        %%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % EXPLANATION OF iSpkSynGroup
                        % The SynModel{postGroup, iSpkSynGroup} class
                        % stores the synapse from all neurons in the
                        % iSpkSynGroup to all in the postGroup.
                        % iSpkSynGroup is not the same as pre synaptic
                        % neuron group. presynaptic neuron groups that
                        % have the same synapse parameters to the post
                        % synaptic group are combined so that iSpkSynGroup
                        % is often smaller than the number of neuron
                        % groups.
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        iSpkSynGroup = synMap{postGroup}(iPreGroup);
                        
                        if isa(SynModel{postGroup,iSpkSynGroup}, 'STDPModel') 
                            % if the spiking neuron is on this lab
                            % then it is our responsibility to update its
                            % Apost value - it is a postsynaptic spike on
                            % the synapse currently being processed. The
                            % Apost value for neurons on other labs will be
                            % part of a synapse model hosted there. Synapse
                            % models split up and exist individually on
                            % each lab.

                            
                            if ismember(allSpike(iSpk), subsetInLab)
                                relativeind =  IDMap.modelIDToCellIDMap(allSpike(iSpk));
                                if ~processed(iSpkSynGroup)
                                    processAsPostSynSpike(SynModel{postGroup, iSpkSynGroup},relativeind);
                                    processed(iSpkSynGroup) = true;
                                end

                                %logical array specifying which presynaptic
                                %neurons are in the current group
                                inGroup = preInGroup == iPreGroup;
                                
                                %inGroupInLab = subsetInLab(inGroup);
                                %if there are presynaptic neurons in current
                                %group
                                if sum(inGroup ~= 0)
                                    
                                    
                                    presyningroup = presynaptic(inGroup);
                                    
                                    
                                    %ingroupinlab = ismember(presyningroup,subsetInLab);
                                    %presyningroup = presyningroup(ingroupinlab);
                                    postsynlocingroup = postsynapticlocation(inGroup);
                                    %postsynlocingroup = postsynlocingroup(ingroupinlab);
                                    
                                    %relative IDs of neurons in presynaptic group
                                    relativepreID = presyningroup - TP.groupBoundaryIDArr(iPreGroup);
                                    
                                    %weights for connections to neurons presynaptic to
                                    %the spiking neuron
                                    
                                    %%% Explanation of weights array and syn array %%%%%
                                    %weights array mirrors synArr, it is a cell array containing an
                                    %entry for each pre synaptic neuron, containing
                                    %the weights of its connections to all of its
                                    %post synaptic neurons. The post synaptic
                                    %neuron IDs can be found in the same location
                                    %in synArr. One might think that the weights
                                    % array and syn array could be sparse matrices,
                                    % but to allow multiple synapses between a
                                    % single pair of neurons it must be a cell
                                    % array. In parallel mode the weights
                                    % array contains all synapse weights to
                                    % from all presynaptic neurons to the
                                    % neurons in the present lab.
                                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                    wMat = zeros(length(presyningroup),1);
                                    
                                    for synInd = 1:length(presyningroup)
                                        wMat(synInd) = wArr{presyningroup(synInd)}(postsynlocingroup(synInd));
                                    end
                                    %calculate delay for synapses with
                                    %delay
                                    if isa(SynModel{postGroup,iSpkSynGroup}, 'STDPModel_delays')
                                        tBufferLoc =  cast(revSynArr{allSpike(iSpk), 3}, 'int16') + cast(SynModel{postGroup,iSpkSynGroup}.bufferCount,'int16')...
                                            - cast(allSpikeTimes(iSpk), 'int16');
                                        
                                        tBufferLoc(tBufferLoc > bufferLength) = ...
                                            tBufferLoc(tBufferLoc > bufferLength) - bufferLength;
                                        
                                        tBufferLoc(tBufferLoc<1) = bufferLength + tBufferLoc(tBufferLoc<1) ;
                                        wMat = updateweightsaspostsynspike(SynModel{postGroup,iSpkSynGroup},...
                                            wMat,relativepreID, neuronInGroup(presyningroup),tBufferLoc(inGroup));
                                    else
                                        wMat = updateweightsaspostsynspike(SynModel{postGroup,iSpkSynGroup},...
                                            wMat,relativepreID, neuronInGroup(presyningroup));
                                    end
                                    for synInd = 1:length(presyningroup)
                                        weightdiff = weightdiff+sum((wMat(synInd)-wArr{presyningroup(synInd)}(postsynlocingroup(synInd)) ));
                                        wArr{presyningroup(synInd)}(postsynlocingroup(synInd)) = wMat(synInd);
                                    end
                                    
                                end
                            end
                        end
                    end
                end
            end

            
            S.spikeCount = 0;
            comCount = SS.minDelaySteps;
        else
            comCount = comCount - 1;
        end
        
        if labindex() == 1 && mod(simStep * SS.timeStep, 5) == 0
            disp([num2str(simStep * SS.timeStep) 'ms']);
            %disp(['dv levels: ' num2str(median(DVModel.pC(DVModel.pCTraceInd,:)))]);
        end
        
        % write recorded variables to disk
        if simStep == RS.dataWriteSteps(numSaves)
            % Mark end of this data section
            RecVar.nevents = RecVar.nevents + 1;
            RecVar.events(RecVar.nevents) = struct('marker', '|', ...
                'time_ms', current_time, 'id', simStep, 'info', 'Section');
            RecVar.events = RecVar.events(1:RecVar.nevents);
            
            if spikeRecCounter-1 ~= length(RecVar.spikeRecording)
                RecVar.spikeRecording{end} = {[], []};
            end
            recTimeCounter = 1;
            fName = sprintf('Recordings%d_.mat', numSaves+ns);
            saveDataSPMD(outputDirectory, fName, RecVar);
                        
            % Only imcrement numSaves if this isn't the last scheduled save point.
            if numSaves < length(RS.dataWriteSteps)
                numSaves = numSaves + 1;
            end
            
            RecVar.nevents = 0;
            spikeRecCounter = 1;
            if S.spikeLoad
                if numSaves <= length(RS.dataWriteSteps)
                    fName = sprintf('%sRecordings%d_.mat',inputDirectory,numSaves+ns);
                    loadedSpikes = pload(fName);
                    %disp(size(loadedSpikes.data.spikeRecording));
                end
            end
        end

    end % end of simulation time loop

    if isfield(RS,'LFPoffline') && RS.LFPoffline
        saveDataSPMD(outputDirectory, 'LineSourceConsts_.mat', lineSourceModCell);
    end
    %numSaves = numSaves - 1; % - no longer need this as numSaves is not
    %updated beyond the final scheduled save point
end % spmd

global RecVarGlobal;
RecVarGlobal = RecVar;
global wArrGlobal;
wArrGlobal = wArr;