function RecVar = updateCSDRecording(RS,NeuronModel,RecVar,iGroup,recTimeCounter)
  if ismember(iGroup, RS.CSD_groups)
    NeuronModel{iGroup}.I_ax
    temp = -NeuronModel{iGroup}.I_ax(RecVar.CSD_NeuronIDs{iGroup}(:,1),:);
    RecVar.CSDRecording{iGroup}(:,:,recTimeCounter) = temp;
%     RecVar.CSDRecording{iGroup}(:,:,recTimeCounter) = -NeuronModel{iGroup}.I_ax(RS.CSD_NeuronIDs{iGroup}(:,1),:);
  end
end
