classdef InputModel_i_opto < InputModel
%InputModel_i_opto optogenetic input current (based on InputModel_i_step)
%   Parameters to set in NeuronParams.Input:
%   - irradianceFNC, function converting light source to watts/mm^2 at
%   soma postion.
%   - currentFNC, function converting irradiance to pico-amps.
%   - tau_on, current on rise constant in milliseconds.
%   - tau_off, current off decay constant in milliseconds.
%   - opto_source_index, The index of the lights source.
%       Used to access Tissue Parameters: TP.opto_<parameter>(index)
%   - compartments, which compartments of the neurons the current
%       should be applied to. If not specified, the current is applied to
%       all compartments. For standard somatic current injection,
%       compartments should be set to 1.
%
%   Expected TissueParameters:
%   - TP.opto_source_power_mW(index) % Light source output power in milli-Watts.
%   - TP.opto_source_diameter(index) % Micron diameter of optical light sources.
%   - TP.opto_source_tau(index)      % Light source exponential falloff in microns.
%   - TP.opto_source_xpos(index)     % Light source center position (x,y,z)
%   - TP.opto_source_ypos(index)
%   - TP.opto_source_zpos(index)
%   - TP.somaPositionMat             % Location of each soma.
%
%   Sets
%   - meanInput, mean current input (pA) for each soma.
%   - stepOn, the simulation times (in timesteps) to turn the current on.
%       The last value must be > simulationTime.
%   - stepOff, the simulation times (in timesteps) to turn the current off.
%   - istep, the index into stepOn and stepOff for expected next light pulse.
%   - tau_on_rise, precumputed value based on Input.tau_on
%   - tau_off_decay, precomputed value based on Input.tau_off.
%   - pulse_on, 1 during pulse, 0 otherwise.
%   - iopto, the index of this light source.
%
%   The current is weighted by compartment membrane area.
%   Optical stimulation can be turned on and off externally with the
%   OptoStepOn(IM) and OptoStepOff(IM) methods, but this should be done
%   exclusive to using OptoStartPulseTrain(IM, delay_ms) to
%   initiate trains of pulses.  Use OptoSetupPulseTrain(IM, TP) to
%   recalculate the pulse train.  Use OptoStartPulseTrain(IM, -1) to stop
%   any on-going pulse train.  OptoSetupLightSource(IM, TP, subset, subsetInLab) to
%   recalculate meanInput for any changes in the light source parameters.

properties (SetAccess = private)
    meanInput      % Asymptotic current input (pA) for each soma.
    tau_on_rise    % Tau_on factor converted to timesteps.
    tau_off_decay  % Tau_off factor converted to timesteps.
    simStep        % Simulation timestep (mirrors simStep in simulateParallel)
    stepOn     % List of timesteps when light source is turned on.
    stepOff    % List of timesteps when light source is turned off.
    istep      % Current index into stepOn and stepOff.
    pulse_on   % 1 during pulse, 0 outside of pulse.
    iopto      % Optical souce index
    ts_ms      % Copy of the simulation timestep size in milliseconds
    delaySteps % Initial delay for the pulse train.
    calc_irradiance % Function to calculate light source irradiance at each neuron in the subset
    calc_current    % Function to calculate current from irradiance.
    subset          % Subset of neuron IDs affected by this input model.
    groupBoundary   % To convert subset index to a global neuron index.
end

methods
    function IM = InputModel_i_opto(N, inputID, number, timeStep, compartmentsInput, subset, TP)
        N.Input(inputID).meanInput = 0;
        IM = IM@InputModel(N, inputID, number, compartmentsInput, subset);

        IM.pulse_on = 0; % Start with light source off.
        IM.iopto = N.Input(inputID).opto_source_index; % Light source index
        IM.ts_ms = timeStep;  % Timestep size in milliseconds
        IM.simStep = 1; % Current Timestep
        IM.subset = subset;
        IM.groupBoundary = TP.groupBoundaryIDArr(N.Input(inputID).groupID);

        % Store references to the irradiance and current functions.
        IM.calc_irradiance = str2func(N.Input(inputID).irradianceFNC);
        IM.calc_current = str2func(N.Input(inputID).currentFNC);

        % Calculate IM.meanInput, the input current based on light source and neuron locations
        OptoSetupLightSource(IM, TP);
        
        % Start with 0 current for all compartments
        IM.I_input = 0 .* IM.meanInput;
        %disp(num2str(IM.meanInput));
        
        % Pre-calculate rise and decay constants for when stimulation pulses are on/off.
        OptoSetTauOn(IM, N.Input(inputID).tau_on);
        OptoSetTauOff(IM,  N.Input(inputID).tau_off)
        %disp(['decay ' num2str(IM.tau_off_decay) ' = 1 - ' num2str(timeStep) '/' num2str(N.Input(inputID).tau_off)]);

        % Setup list of on/off times for pulses
        OptoSetupPulseTrain(IM, TP)
    end
    
    function OptoSetTauOn(IM, tau_on_ms)
        % Calculate rise constant for asymptotic approach to IM_meanInput when a light pulse is on.
        IM.tau_on_rise = 1 - (IM.ts_ms / tau_on_ms);
    end
    
    function OptoSetTauOff(IM, tau_off_ms)
        % Calculate decay constant for when stimulation pulses are off.
        IM.tau_off_decay = 1 - (IM.ts_ms / tau_off_ms);
    end
    
    function OptoSetupLightSource(IM, TP)
        % Calculate light-source input-current from TP light source parameters
        % for the subset of neurons in the calling Lab
        neuron_set = IM.subset + IM.groupBoundary; % Global neuron index.
        irradiance_values_for_subset = IM.calc_irradiance(TP, IM.iopto, neuron_set);  % Nsubset x 1 array
        mi = IM.calc_current(TP, IM.iopto, neuron_set, irradiance_values_for_subset); % Nsubset x 1 array        
        IM.meanInput = bsxfun(@times, mi, IM.membraneAreaRatio); % Nsubset x Ncompartments  
    end
    
    function OptoSetupPulseTrain(IM, TP)
        % Recaculates the pulse train based on current values in:
        % TP.opto_pulse_freq         % Pulses per second in each train.
        % TP.opto_pulse_count        % Number of pulses in each train.
        % TP.opto_train_delay_ms     % Delay to the first pulse in the train.
        % TP.opto_pulse_duration_ms  % Duration of pulse
        % Pulse train is deactivated until started with OptoStartPulseTrain(IM, start_delay_ms)
        OptoStepOff(IM); % Stop any on-going pulse
     	IM.delaySteps = floor(TP.opto_train_delay_ms(IM.iopto) / IM.ts_ms);
        nPulses = TP.opto_pulse_count(IM.iopto);
        pulse_times = (0:nPulses-1) * 1000 / TP.opto_pulse_freq(IM.iopto);
        IM.stepOn  = floor(pulse_times / IM.ts_ms) + IM.delaySteps;
        IM.stepOff = IM.stepOn + floor(TP.opto_pulse_duration_ms(IM.iopto) / IM.ts_ms);
        IM.stepOn(end+1) = -1;  % Terminate the pulse list with a timestep that cannot occur.
        IM.stepOff(end+1) = -1;
        IM.istep = length(IM.stepOn); % Deactivate pulse train
%         disp(['On' num2str(labindex) ' ' num2str(IM.stepOn)]);
%         disp(['Off' num2str(labindex) ' ' num2str(IM.stepOff)]);
    end
    
    function OptoStartPulseTrain(IM, start_delay_ms)
        % Start pulse train at current timestep + start_delay_ms.
        % This will also end any active pulse.
        % If start_delay_ms < 0 then any on-going pulse train is stopped.
        if start_delay_ms < 0
            IM.istep = length(IM.stepOn); % Last stepOn value is always -1
        else
            if IM.stepOn(1) >= 0  % If pulse train is not empty
                offset_steps = floor(start_delay_ms / IM.ts_ms) + IM.delaySteps - IM.stepOn(1) + IM.simStep;
                IM.stepOff = IM.stepOff + offset_steps;
                IM.stepOn = IM.stepOn + offset_steps;
            end
            IM.istep = 1; % Start at first pulse
        end
        if IM.simStep == IM.stepOn(IM.istep)
            OptoStepOn(IM); % Pulse train starts immediately
        else
            OptoStepOff(IM); % In case pulse is on-going.
        end
%         disp(['xOn' num2str(labindex) ' ' num2str(IM.stepOn)]);
%         disp(['xOff' num2str(labindex) ' ' num2str(IM.stepOff)]);
   end
    
    function OptoStepOn(IM)
        % Turn light pulse on
        IM.pulse_on = 1;
    end
    
    function OptoStepOff(IM)
        % Turn light pulse off
        IM.pulse_on = 0;
    end
    
    function IM = updateInput(IM, ~)
        if IM.simStep == IM.stepOn(IM.istep)
            % Turn light pulse on
            IM.pulse_on = 1;
        end
        if IM.simStep == IM.stepOff(IM.istep)
            % Turn light pulse off, setup for next pulse in list
            IM.pulse_on = 0;
            if IM.istep < length(IM.stepOn)
                IM.istep = IM.istep + 1;
            end
        end
        if IM.pulse_on == 0
            % pulse is off, decay any current to zero
            IM.I_input = bsxfun(@times, IM.tau_off_decay, IM.I_input);
        else
            % pulse is on, current asymptotically approaches IM.meanInput
            % I_input = I_input + tau_on_rise * (meanInput - I_input)
            IM.I_input = bsxfun(@plus, IM.I_input, bsxfun(@times, IM.tau_on_rise, bsxfun(@minus, IM.meanInput, IM.I_input)));
        end
        IM.simStep = IM.simStep + 1; % Count one more timestep
    end

    function I = getRecordingVar(IM)
        I = IM.I_input;
    end

end % methods

methods(Static)
    function params = getRequiredParams()
        params = {'tau_on', 'tau_off', 'opto_source_index', 'irradianceFNC', 'currentFNC'};
    end
end

end % classdef