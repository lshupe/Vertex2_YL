disp("Printing pwd and mfilename, then going to add that to the path")
disp(pwd);
disp(mfilename);
folder = fileparts(which(mfilename)); 
disp(folder);
addpath(genpath(folder));

% Set driving current scaling of default params
std_scalars = 1:0.25:2;
mean_scalars = 0.5:0.25:1.5;
arb_radius_scalar = 1;
b_2_3_std_scalar = 1;

[x, y] = meshgrid(std_scalars, mean_scalars);
scalar_coords = [x(:), y(:)];

% not sure the settings on NSG so just using default for everything
% default 'local' profile probably
% default preferredNumWorkers workers
poolobj = parpool(12, 'SpmdEnabled', false);
disp(poolobj)
parfor idx = 1:25
    std_scalar = scalar_coords(idx, 1);
    mean_scalar = scalar_coords(idx, 2);
    length = 1500;  
    time = 5000;
    coords = make_3D_electrode_grid([250, 250, 0], [1000, 1000, 2500], [3, 3, 6]);
    std_str = num2str(std_scalar);
    mean_str = num2str(mean_scalar);
    disp(strcat("Kicking off model with std ", ...
        std_str, " and mean ", mean_str));
    std_file = strrep(std_str, '.', 'p');
    mean_file = strrep(mean_str, '.', 'p');
    dir = strcat('vertex_results/', std_file, 'std_', ...
        mean_file, 'mean_', num2str(length));
    run_bsf_model_sim(length, time, coords, ...
        dir, std_scalar, ...
        mean_scalar, arb_radius_scalar, b_2_3_std_scalar, true, false);
end
disp('Complete all sweep for all params!');
delete(poolobj);
