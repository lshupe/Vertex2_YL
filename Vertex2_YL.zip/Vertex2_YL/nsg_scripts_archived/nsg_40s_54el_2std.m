disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 2;
input_mean_scaler = 1;
b_2_3_std_scalar = 1.25;
arb_radius_scalar = 1.5;

length = 1500;
time = 40000;
% gaps in x,y at 250, 3x3 electrodes, 6 layers
coords = make_3D_electrode_grid([250, 250, 0], [1000, 1000, 2500], [3, 3, 6]);
res = run_bsf_model_sim(length, time, coords, ...
    'vertex_results/nsg_40s_54el_2std', input_std_scaler, ...
    input_mean_scaler, arb_radius_scalar, b_2_3_std_scalar, true, false);