disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

disp_with_time('loading connections from directory');
% Load connections, params from relative path
%%
% SPECIFY INPUT DIRECTORY HERE
dir = 'data';
params = load_params_from_dir(dir);
[synapses, weights] = load_randomized_connectivity(params, dir); 
disp_with_time('connections loaded');

% Generate sparse matrix
%%
disp_with_time('sparse matrix generated, calculated ground truth');
neuron_type = 'e';
disp_with_time(sprintf('generating connectivity matrix for neuron type %s', neuron_type));
connectivity_matrix = get_sparse_weighted_connectivity_2(params, synapses, weights, neuron_type);
for radius = [100 500 900 1300 3000]
    disp_with_time(sprintf('calculating ground truth for radius %i', radius));
    res = par_calc_ground_truth_matrix(params, connectivity_matrix, radius);
    % SPECIFY OUTPUT DIRECTORY HERE
    if ~exist('vertex_results', 'dir')
        mkdir('vertex_results');
    end
    save_path = sprintf('vertex_results/ground_truth_%s_%i.mat', neuron_type, radius);
    save(save_path, 'res', '-v7.3');
end