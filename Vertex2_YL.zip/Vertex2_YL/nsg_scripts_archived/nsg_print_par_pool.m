p = gcp('nocreate');
if ~isempty(p)
    disp_with_time("Parallel Pool exists with the following properties, deleting");
    disp(p);
    delete(p);
else
    disp("There is no current parallel pool");
end