disp("Printing pwd and mfilename, then going to add that to the path")
disp(pwd);
disp(mfilename);
folder = fileparts(which(mfilename)); 
disp(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 1.25;
input_mean_scaler = 1.25;

length = 2500;
time = 5000;
coords = make_electrode_grid(length, length/8, 9);
res = run_bsf_model_sim(length, time, coords, 'vertex_results/1p25std_1p25mean_full', input_std_scaler, input_mean_scaler);