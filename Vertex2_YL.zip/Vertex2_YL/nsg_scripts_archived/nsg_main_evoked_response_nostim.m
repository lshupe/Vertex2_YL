%% Environment Setup for running evoked response testing with field stimulation
s = []; % Setup parameters are added to this structure

% Run with local (true), or cluster (false) parameters
s.run_local = false;

% Duration of simulation in milliseconds.
% 5 stimulation pulses at each of 54 electrodes.
% Pulses are separated by 200 ms.
% 1 second of rest before and after stimulation.
s.simulation_time = 40000;

% Optionally load weights from a previously saved simulation with the
% exact same topology, random seed, and parallel processor cores.
% Example: s.LoadWeightsFromFile = '.\weights_';
% This will load files 'weights_1.mat', 'weights_2.mat', ... into
% Lab 1,2,... after weights have been initialized runSimulation.m.
s.LoadWeightsFromFile = '';  % = ''  for normal run.

% Subdirectory for saving results
s.results_dir = 'vertex_results';

% Enable or disable Spike-timing Dependant Plasticity
s.stdp_enabled = false; % Spike-timing Dependant Plasticity

% Field Stimulation Types: 'none' for no stimulation.
% 'paired_pulse' for paired pulse field stimulation.
% 'evoked_response' for field stimulation at LFP recording sites.
s.field_stim_type = 'none'; 

% Optogenetic stimulation types: 'none' for no opto stimulation
% 'pulse_train' for open-loop current-pulse-trains delivered through InputModel_i_opto.
% 'closed_loop' for optical stimulation based on run-time calls to InputModel_i_opto methods OptoStepOn() and OptoStepOff()
s.opto_stim_type = 'none';

% Standard Deviation scalar for neuronal input current
s.input_std_scaler = 1.75;

% Mean scalar for neuronal input current
s.input_mean_scaler = 1.125;

% Mean scaler for B7 Neuron Group
s.b_4_mean_scaler = 1;

% Standard Deviation scalar specifically for B2/3 Neuron Group input current
s.b_2_3_std_scalar = 1.75;

% Arborisation radius scalar of syaptic connectivity params
% see http://vertexsimulator.org/tutorial-1/#12 
s.arb_radius_scalar = 1;

%%
% X,Y Dimensions of the model, in micrometers
s.xy_length = [1500 1500];

%% Add current sub-folders to path
addpath(genpath(pwd));
disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);

%% Run Model
% Make 3D Grid of Recording sites
% 2.0 x 2.0 mm: starting at [500, 500, 0], with dimensions [1000, 1000, 2500], with 3x3x6 sites.
% 1.5 x 1.5 mm: Starting at [250, 250, 0], with dimensions [1000, 1000, 2500], with 3x3x6 sites.
% 1.5 x 1.0 mm: Starting at [500, 250, 0], with dimensions [500, 500, 2500], with 3x3x6 sites.
s.coords = make_3D_electrode_grid([250, 250, 0], [1000, 1000, 2500], [3, 3, 6]);
s.should_save_model = false;
s.should_save_ground_truth = false;
s.should_save_randomized_connectivity = true;
s.should_save_v = false;

% Run the model
res = run_bsf_model_stdp_sim(s.xy_length, s.simulation_time, s.coords, s.results_dir, s);
