disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 1.75;
input_mean_scaler = 1;
b_2_3_std_scalar = 1.25;

length = 2000;
time = 5000;
% gaps in x,y at 250, 4x4 electrodes, 6 layers
coords = make_3D_electrode_grid([250, 250, 0], [1500, 1500, 2500], [4, 4, 6]);
res = run_bsf_model_sim(length, time, coords, ...
    'vertex_results/nsg_slightly_bigger', input_std_scaler, ...
    input_mean_scaler, true, false);