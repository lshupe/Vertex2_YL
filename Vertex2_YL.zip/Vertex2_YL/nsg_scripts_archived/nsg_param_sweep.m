disp("Printing pwd and mfilename, then going to add that to the path")
disp(pwd);
disp(mfilename);
folder = fileparts(which(mfilename)); 
disp(folder);
addpath(genpath(folder));

% Set driving current scaling of default params
std_scalars = 1:0.25:2;
mean_scalars = 0.5:0.25:1.5;
[x, y] = meshgrid(std_scalars, mean_scalars);
scalar_coords = [x(:), y(:)];

% not sure the settings on NSG so just using default for everything
% default 'local' profile probably
% default preferredNumWorkers workers
poolobj = parpool(12, 'SpmdEnabled', false);
disp(poolobj)
parfor idx = 25:25
    std_scalar = scalar_coords(idx, 1);
    mean_scalar = scalar_coords(idx, 2);
    length = 2500;
    time = 5000;
    electrode_coords = make_electrode_grid(length, length/8, 9);
    std_str = num2str(std_scalar);
    mean_str = num2str(mean_scalar);
    disp(strcat("Kicking off model with std ", ...
        std_str, " and mean ", mean_str));
    std_file = strrep(std_str, '.', 'p');
    mean_file = strrep(mean_str, '.', 'p');
    dir = strcat('vertex_results/', std_file, 'std_', ...
        mean_file, 'mean_', num2str(length));
    run_bsf_model_sim(length, time, electrode_coords, ...
        dir, std_scalar, mean_scalar);
end
disp('Complete all sweep for all params!');
delete(poolobj);
