std_scalar = 1.25;
mean_scalar = 0.75;

arb_radius_scalar = 1;
b_2_3_std_scalar = 1;

length = 1500;  
time = 5000;
coords = make_3D_electrode_grid([250, 250, 0], [1000, 1000, 2500], [3, 3, 6]);
std_str = num2str(std_scalar);
mean_str = num2str(mean_scalar);
disp(strcat("Kicking off model with std ", ...
    std_str, " and mean ", mean_str));
std_file = strrep(std_str, '.', 'p');
mean_file = strrep(mean_str, '.', 'p');
dir = strcat('vertex_results/', std_file, 'std_', ...
    mean_file, 'mean_', num2str(length));
run_bsf_model_sim(length, time, coords, ...
    dir, std_scalar, ...
    mean_scalar, arb_radius_scalar, b_2_3_std_scalar, false, false);