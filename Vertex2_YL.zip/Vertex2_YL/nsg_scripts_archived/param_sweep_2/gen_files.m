% open the template file
% for 
template = fileread('vertex_2/param_sweep_2/template');
std_scalars = 1:0.25:2;
mean_scalars = 0.5:0.25:1.5;
[x, y] = meshgrid(std_scalars, mean_scalars);
scalar_coords = [x(:), y(:)];
for idx = 1:25
    std_scalar = scalar_coords(idx, 1);
    mean_scalar = scalar_coords(idx, 2);

    std_str = num2str(std_scalar);
    mean_str = num2str(mean_scalar);
    
    content = strrep(strrep(template, 'STD_VAR', std_str), 'MEAN_VAR', mean_str);
    std_file = strrep(std_str, '.', 'p');
    mean_file = strrep(mean_str, '.', 'p');
    file_name = strcat('vertex_2/param_sweep_2/nsg_', std_file, 'std_', mean_file, 'mean.m');
    fid = fopen(file_name, 'w');
    fprintf(fid, content);
    fid = fclose(fid);
end