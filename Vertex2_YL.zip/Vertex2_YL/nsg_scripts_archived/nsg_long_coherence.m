input_dir = '~/vertex_results/nsg_long';
output_dir = '~/vertex_results/nsg_long/coherence';
results = loadResults(input_dir);
for i = 1:4
    for j = (i + 1):4
        evaluate_coherence(results, output_dir, i, j, true);
    end
end