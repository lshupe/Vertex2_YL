disp("Printing pwd and mfilename, then going to add that to the path")
disp(pwd);
disp(mfilename);
folder = fileparts(which(mfilename)); 
disp(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 1.75;
input_mean_scaler = 1;
b_2_3_std_scalar = 1.25;

length = 2500;
time = 5000;
coords = make_electrode_grid(length, length/8, 9);
run_bsf_model_sim(length, time, coords, 'vertex_results/nsg_main', ... 
    input_std_scaler, input_mean_scaler, b_2_3_std_scalar, false, true);

