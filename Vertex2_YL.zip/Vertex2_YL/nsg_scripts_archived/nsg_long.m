disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 1.75;
input_mean_scaler = 1;

length = 1500;
time = 40000;
coords = make_electrode_grid(length, 500, 4);
res = run_bsf_model_sim(length, time, coords, 'vertex_results/nsg_long', input_std_scaler, input_mean_scaler);