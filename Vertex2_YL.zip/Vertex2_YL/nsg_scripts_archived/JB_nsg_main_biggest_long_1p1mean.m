disp("Printing pwd and mfilename, then going to add that to the path")
disp(pwd);
disp(mfilename);
folder = fileparts(which(mfilename)); 
disp(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 2;
input_mean_scaler = 1.1;

length = 10000;
time = 10000;
coords = make_electrode_grid(length, length/8, 9);
res = run_bsf_model_sim(length, time, coords, 'vertex_results/2std_1p1m_biggest_long', input_std_scaler, input_mean_scaler);