% choose random 20 neurons to display interspike interval for
input_dir = '~/vertex_results/nsg_long';
results = loadResults(input_dir);
num_neurons = results.params.TissueParams.N;
interval = num_neurons / 20;
for neuron_id = 1:interval:num_neurons
    disp(strcat("Generating histogram for neuron_id: ", num2str(neuron_id)));
    isi_hist_for_neuron(neuron_id, input_dir, results, true);
end
