function [cathode_uA, anode_uA, cathode_n, anode_n] = EstimateElectrodeCurrent(TP, diffpair)
% Estimate current flowing through the differential electrode pair.
R = TP.StimulationField(diffpair);
Ex = R.XGradients; % Get the Electric Field (Ex, Ey, Ez)
Ey = R.YGradients;
Ez = R.ZGradients;

% Find points on the boundary of the cathode
xw = TP.stim_electrode_base_xy(diffpair,1);   % Elec x width
yw = TP.stim_electrode_base_xy(diffpair,2);   % Elec y width
zh = TP.stim_electrode_tip_length(diffpair,1);% Elec z height
tipx = TP.stim_electrode_tip_xy(diffpair,1);  % Elec tip x width
tipy = TP.stim_electrode_tip_xy(diffpair,2);  % Elec tip y width
index = find( ...
    (R.Mesh.Nodes(1,:) >= TP.stim_electrode_xpos(diffpair,1) - xw/2 - 0.1) & ...
    (R.Mesh.Nodes(1,:) <= TP.stim_electrode_xpos(diffpair,1) + xw/2 + 0.1) & ...
    (R.Mesh.Nodes(2,:) >= TP.stim_electrode_ypos(diffpair,1) - yw/2 - 0.1) & ...
    (R.Mesh.Nodes(2,:) <= TP.stim_electrode_ypos(diffpair,1) + yw/2 + 0.1) & ...
    (R.Mesh.Nodes(3,:) >= TP.stim_electrode_zpos(diffpair,1) - 0.1) & ...
    (R.Mesh.Nodes(3,:) <= TP.stim_electrode_zpos(diffpair,1) + zh + 0.1) );
% Calculate electrode tip area which is composed of 4 trapezoids.
trapz_height1 = sqrt(zh^2 + ((xw - tipx)/2)^2);
trapz_area1 = trapz_height1 * (xw + tipx) / 2;
trapz_height2 = sqrt(zh^2 + ((yw - tipy)/2)^2);
trapz_area2 = trapz_height2 * (yw + tipy) / 2;
elec_area = 2 * (trapz_area1 + trapz_area2) + tipx * tipy;
% Current density = Conductivity * Electric Field (for a purely resistive medium)
currentDensityMagnitude = sqrt(Ex(index).^2 + Ey(index).^2 + Ez(index).^2)  * (TP.tissueConductivity / 1000000); % mA
zf = (R.Mesh.Nodes(3,index) - TP.stim_electrode_zpos(diffpair,1)) / zh; % Ramp from 0 at tip to 1 at electrode base
tipxy = (tipx + tipy) / 2;  % mean side area dA
xyw = (xw + yw) / 2;
elec_width_at_z = zf' * (xyw - tipxy) + tipxy;
weight = elec_width_at_z / sum(elec_width_at_z);
cathode_uA = 1000 * sum(currentDensityMagnitude .* weight) * elec_area * sign(TP.stim_size(diffpair)); % microamps
cathode_n = length(index);

% Find points on the boundary of the anode
xw = TP.stim_electrode_base_xy(diffpair,3);   % Elec x width
yw = TP.stim_electrode_base_xy(diffpair,4);   % Elec y width
zh = TP.stim_electrode_tip_length(diffpair,2);% Elec z height
tipx = TP.stim_electrode_tip_xy(diffpair,3);  % Elec tip x width
tipy = TP.stim_electrode_tip_xy(diffpair,4);  % Elec tip y width
index = find( ...
    (R.Mesh.Nodes(1,:) >= TP.stim_electrode_xpos(diffpair,2) - xw/2 - 0.1) & ...
    (R.Mesh.Nodes(1,:) <= TP.stim_electrode_xpos(diffpair,2) + xw/2 + 0.1) & ...
    (R.Mesh.Nodes(2,:) >= TP.stim_electrode_ypos(diffpair,2) - yw/2 - 0.1) & ...
    (R.Mesh.Nodes(2,:) <= TP.stim_electrode_ypos(diffpair,2) + yw/2 + 0.1) & ...
    (R.Mesh.Nodes(3,:) >= TP.stim_electrode_zpos(diffpair,2) - 0.1) & ...
    (R.Mesh.Nodes(3,:) <= TP.stim_electrode_zpos(diffpair,2) + zh + 0.1) );
trapz_height1 = sqrt(zh^2 + ((xw - tipx)/2)^2);
trapz_area1 = trapz_height1 * (xw + tipx) / 2;
trapz_height2 = sqrt(zh^2 + ((yw - tipy)/2)^2);
trapz_area2 = trapz_height2 * (yw + tipy) / 2;
elec_area = 2 * (trapz_area1 + trapz_area2) + tipx * tipy;
currentDensityMagnitude = sqrt(Ex(index).^2 + Ey(index).^2 + Ez(index).^2)  * (TP.tissueConductivity / 1000000); % mA
zf = (R.Mesh.Nodes(3,index) - TP.stim_electrode_zpos(diffpair,2)) / zh;
tipxy = (tipx + tipy) / 2;
xyw = (xw + yw) / 2;
elec_width_at_z = zf' * (xyw - tipxy) + tipxy;
weight = elec_width_at_z / sum(elec_width_at_z);
anode_uA = 1000 * sum(currentDensityMagnitude .* weight) * elec_area * sign(-TP.stim_size(diffpair)); % microamps
anode_n = length(index);

