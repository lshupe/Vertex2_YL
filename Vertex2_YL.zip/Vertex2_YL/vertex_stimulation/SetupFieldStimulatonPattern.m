function [stim_on_ms, stim_off_ms, stim_field] = SetupFieldStimulatonPattern(TP, at_ms)
% Setup the field stimulation pattern to start at time at_ms.  This time
% must be the current time or in the future.

nelectrodes = size(TP.stim_size, 1);
pulse_delays = TP.stim_delay_ms';
if length(pulse_delays) < nelectrodes
    % Use same delay between consecutive electrodes
    pulse_delays = pulse_delays(end) .* (0:nelectrodes-1);
end

stim_on_ms = at_ms + pulse_delays;
stim_off_ms = stim_on_ms + TP.stim_width_ms';
stim_field = 1:nelectrodes;

% Remove any pulses with negative delays
index = find(pulse_delays < 0);
if ~isempty(index)
    stim_on_ms(index) = [];
    stim_off_ms(index) = [];
    stim_field(index) = [];
end

% Sort by stim_on_ms
[stim_on_ms, index] = sort(stim_on_ms);
stim_off_ms = stim_off_ms(index);
stim_field(index) = stim_field(index);

