function [NP] = decreaseCompartmentLength(NP)
%Split the