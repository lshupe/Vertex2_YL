function [model, outfaces, cathodefaces, anodefaces] = buildPDEgeometryBipoloarElectrode(xLimits, yLimits, zLimits, point1, point2, tipWidth)
% Create a bipolar electrode for Vertex2.  This is a rectangluar volume with
% Thin boxes removed that represent electrodes piercing on side of the volume.
% Cathode terminates at point1, anode terminates at point2.

    function n = boxpoints(x1, x2, y1, y2, z1, z2)
        % Order of points in box is very specific to our elements list.
        n = [x2 x1 x1 x2 x2 x1 x1 x2;
             y1 y1 y1 y1 y2 y2 y2 y2;
             z1 z1 z2 z2 z1 z1 z2 z2;];
    end

nodes = zeros(3, 24);
elements = zeros(4, 18);
dw = 0.5 * tipWidth;

n1 = boxpoints(xLimits(1), xLimits(2), yLimits(1), yLimits(2), zLimits(1), zLimits(2)); % bounds
n2 = boxpoints(point1(1)-dw, point1(1)+dw, point1(2), yLimits(2), point1(3)-dw, point1(3)+dw); % elect1 (cathode)
n3 = boxpoints(point2(1)-dw, point2(1)+dw, point2(2), yLimits(2), point2(3)-dw, point2(3)+dw); % elect2 (anode)
nodes = [n1 n2 n3];

elements = [...
    8 24 23; % 14 triangles in surface pierced by electrodes
    8 21 24; % Some of these trianges are very thin and may throw warnings.
    8 5 21;  % Surface normals point outward from bounding volume.
    5 22 21;
    5 13 22;
    5 6 13;
    6 14 13;
    6 15 14;
    6 7 15;
    7 16 15;
    7 23 16;
    7 8 23;
    13 23 22;
    13 16 23;
    1 5 8;   % 10 triangles in remaining 5 outer surface faces.
    8 4 1;   % Surface normals point outward from bounding volume.
    1 4 3;
    3 2 1;
    2 3 7;
    7 6 2;
    3 4 8;
    8 7 3;
    1 2 6;
    6 5 1;
    9 12 16; % 10 triangles in cathode.
    16 13 9; % surface normals point into electrode volume.
    9 10 11;
    11 12 9;
    10 14 15;
    15 11 10;
    11 15 16;
    16 12 11;
    10 9 13;
    13 14 10;    
    17 20 24; % 10 triangles in anode.
    24 21 17; % surface normals point into electrode volume.
    17 18 19;
    19 20 17;
    18 22 23;
    23 19 18;
    19 23 24;
    24 20 19;
    17 21 22;
    22 18 17];

model = createpde();
geometryFromMesh(model,nodes,elements');
pdegplot(model,'FaceAlpha',0.4, 'FaceLabels', 'on');

% Assume that geometryFromMesh() always returns faces in order of
% appearance.  This might need to be verified on toolbox updates.
outfaces = (1:6);
cathodefaces = (7:11);
anodefaces = (12:16);

end

