function [model, outfaces, catfaces, anofaces, catinsul, anoinsul] = ...
    BipoloarElectrodeVerticalGeometry(xLimits, yLimits, zLimits, ...
    point1, point2, electrodeSizesXY)
% xLimits = [minx maxx];    % Outer tissue boundary
% yLimits = [miny maxy];
% zLimits = [minz maxz];
% point1 = [cx cy cz];      % Cathode tip position
% point2 = [ax ay az];      % Anode tip position
% electrodeSizesXY = [crx cry arx ary]; % Cathode,anode X,Y dimensions
% 
% Create a bipolar electrode for Vertex2.  This is a rectangular volume 
% with thin boxes removed that represent vertical electrodes piercing down
% through the top of the volume. The electrode tips are 4 sided pyramids of
% height 0 with the Cathode terminating at point1 and anode at point2.
% This is similar to "Vertical Electrode Topology (pyramid tips).ai"
% except the electrode tip is forced to be flat by setting tiplengths = 0,
% and adjusting the face ids.
%
% Returns the PDE model and the face IDs for the outer bounding volume,
% cathode, anode, and the insulated parts of the cathode and anode.
%
% Electrodes must be contained within the bounding volume and their volumes
% cannot touch each other.  The caller is responsible for ensuring this.

% The surface electrodes are flat
tipLengths = [0 0];

% Cathode tip = nodes 1,2,3,4,5
th1 = tipLengths(1);               % Height of electrode tip pyramid
crx = 0.5 * electrodeSizesXY(1);   % dimensions of cathode
cry = 0.5 * electrodeSizesXY(2);
x1 = point1(1);
y1 = point1(2);
z1 = point1(3);

tip1 = [x1 x1+crx x1-crx x1-crx x1+crx;
        y1 y1-cry y1-cry y1+cry y1+cry;
        z1 z1+th1 z1+th1 z1+th1 z1+th1];

tip1tri = [1 1 1 1;  % 4 triangles for cathode tip
           2 3 4 5;
           5 2 3 4];

tip1ids = 1; % Face identfier for cathode tip

% Anode tip = nodes 6,7,8,9,10
th2 = tipLengths(2);
arx = 0.5 * electrodeSizesXY(3); % dimensions of anode
ary = 0.5 * electrodeSizesXY(4);
x2 = point2(1);
y2 = point2(2);
z2 = point2(3);

tip2 = [x2 x2+arx x2-arx x2-arx x2+arx;
        y2 y2-ary y2-ary y2+ary y2+ary;
        z2 z2+th2 z2+th2 z2+th2 z2+th2];

tip2tri = [6 6 6 6;  % 4 triangles for anode tip
           7 8 9 10;
           10 7 8 9];

tip2ids = 2; % Face identfier anode tip

% Cathode entry at surface = nodes 11,12,13,14
zbot = zLimits(1);       % Deepest tissue limit is near 0
ztop = zLimits(2);       % Tissue surface is near maximum z value

e1 = [x1+crx x1-crx x1-crx x1+crx;
      y1-cry y1-cry y1+cry y1+cry; 
      ztop ztop ztop ztop];

e1tri = [ 2 14  3 11  4 12  5 13; % 8 triangles in cathode insulation
         11  5 12  2 13  3 14  4;
         14  2 11  3 12  4 13  5];

e1ids = [3 3 4 4 5 5 6 6];
     
% Anode entry at surface = nodes 15,16,17,18
e2 = [x2+arx x2-arx x2-arx x2+arx;
      y2-ary y2-ary y2+ary y2+ary;
      ztop ztop ztop ztop];

e2tri = [ 7 18  8 15  9 16 10 17; % 8 triangels in anode insulation
         15 10 16  7 17  8 18  9;
         18  7 15  8 16  9 17 10];
     
e2ids = [7 7 8 8 9 9 10 10];

% Bounding volume = nodes 19,20,21,22 (top surface) and 23,24,25,26 (bottom depth)
xmin = xLimits(1);
xmax = xLimits(2);
ymin = yLimits(1);
ymax = yLimits(2);

top = [xmax xmin xmin xmax;
       ymin ymin ymax ymax;
       ztop ztop ztop ztop];
   
bot = [xmax xmin xmin xmax;
       ymin ymin ymax ymax;
       zbot zbot zbot zbot];

bvtri = [23 22 24 19 25 20 26 21 23 25; % 10 trianges in bounding volume
         26 19 23 20 24 21 25 22 24 26; % sides and bottom
         22 23 19 24 20 25 21 26 25 23];

bvids = [11 11 12 12 13 13 14 14 15 15];

% Create the 2-D geometry of the top tissue surface with holes cut out
% for the electrodes. This is done by tesselating nodes on the top
% surface and then removing triangles that have all three points on an
% electrode.

pts = [e1 e2 top]';                     % All points in top surface.
DT = delaunay(pts(:,1), pts(:,2)) + 10; % Tesselate and adjust for the 10 tip nodes
is1 = ismember(DT, (11:14));            % Nodes that touch electrode1.
is2 = ismember(DT, (15:18));            % Nodes that touch electrode2.
select = (sum(is1, 2) <= 2) & (sum(is2, 2) <= 2); % Triangles with two or fewer points on any one electrode.
toptri = DT(select, :)';                % List of surface triangles
topids = repmat(16, 1, size(toptri, 2));% Top surface is face 16
    
% Construct list of nodes and triangular mesh elements.
nodes = [tip1 tip2 e1 e2 top bot];
elements = [tip1tri tip2tri e1tri e2tri bvtri toptri];
faceIDs = [tip1ids tip2ids e1ids e2ids bvids topids]; 
    
% Create electrode geometry.
%model = createpde("electromagnetic","conduction");
model = createpde();

%model.geometryFromMesh(nodes, elements, faceIDs);
model.geometryFromMesh(nodes, elements);
pdegplot(model,'FaceAlpha',0.4, 'FaceLabels', 'on');

% Return face IDs for each piece of the electrode
catfaces = (1);   % First face is the conductive cathode
anofaces = (2);   % Second face is the conductive anode
catinsul = (3:6);  % Cathode/anode insulation ...
anoinsul = (7:10); %   ... usually combined later with outfaces.
outfaces = (11:16); % Bounding volume
% Warn about some obvious errors
if (z1-th1 >= ztop) || (z2-th2 >= ztop)
    disp('BipoloarElectrodeGeometry: Bad electrode depth or tip length. Electrodes must be below top bound.');
end

if (z1 <= zbot) || (z2 <= zbot)
    disp('BipoloarElectrodeGeometry: Bad electrode depth or tip length. Electrodes must be above bottom bound.');
end
