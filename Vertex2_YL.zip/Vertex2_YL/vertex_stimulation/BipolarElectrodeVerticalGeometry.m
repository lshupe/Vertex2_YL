function [model, outfaces, catfaces, anofaces, catinsul, anoinsul] = ...
    BipolarElectrodeVerticalGeometry(xLimits, yLimits, zLimits, ...
    point1, point2, baseXY, tipXY, tipLengths, tipInsulationThickness)
% xLimits = [minx maxx];    % Outer tissue boundary
% yLimits = [miny maxy];    % All dimensions are typically in microns
% zLimits = [minz maxz];    % Tissue surface at maxz, deepest point at minz
% point1 = [cx cy cz];                  % Cathode tip position
% point2 = [ax ay az];                  % Anode tip position
% baseXY = [bcrx bcry barx bary];       % Cathode,anode base X,Y dimensions
% tipXY = [tcrx tcry tarx tary];        % Cathode,anode tip X,Y dimensions
% tipLengths = [clen alen];             % Cathode,anode tip-lengths >= 40
% tipInsulationThickness = [cdx adx];   % Insulation added to electrode,
%                                           should be >= [1 1]
% Create a bipolar electrode for Vertex2.  This is a rectangular volume 
% with thin boxes removed that represent vertical electrodes piercing down
% through the top of the volume.  See "Vertical Electrode Geometry.ai"
% Illustrator document.  The electrode tips are 4 sided truncated pyramids
% of height tipLength with the Cathode center terminating at point1 and
% anode center at point2.  The base and tip of the pyramid have
% have separate X,Y dimensions for each electrode.
%
% Returns the PDE model and the face IDs for the outer bounding volume,
% cathode, anode, and the insulated parts of the cathode and anode.
%
% Electrodes must be contained within the bounding volume and their areas
% cannot touch each other.  The caller is responsible for ensuring this.

if ~exist('tipInsulationThickness', 'var')
    tipInsulationThickness = [3 3];
end

% Cathode tip = nodes 1..8 with 10 triangles in sides and bottom.
th1 = tipLengths(1);      % Length of cathode tip
bcrx = 0.5 * baseXY(1);   % Radius of cathode at base
bcry = 0.5 * baseXY(2);
tcrx = 0.5 * tipXY(1);    % Radius of cathode at tip
tcry = 0.5 * tipXY(2);
x1 = point1(1);
y1 = point1(2);
z1 = point1(3);

tip1 = [x1+tcrx x1-tcrx x1-tcrx x1+tcrx x1+bcrx x1-bcrx x1-bcrx x1+bcrx;
        y1-tcry y1-tcry y1+tcry y1+tcry y1-bcry y1-bcry y1+bcry y1+bcry;
        z1      z1      z1      z1      z1+th1  z1+th1  z1+th1  z1+th1];

tip1tri = [1     8     2     5     3     6     4     7     1     3;
           5     4     6     1     7     2     8     3     4     2;
           8     1     5     2     6     3     7     4     3     1];

tip1ids = [1 1 2 2 3 3 4 4 5 5]; % Face identfiers for each triangle

% Anode tip = nodes 9..16 with 10 triangles
th2 = tipLengths(2);    % Length of anode tip
barx = 0.5 * baseXY(3); % Radius of anode at base
bary = 0.5 * baseXY(4);
tarx = 0.5 * tipXY(3);  % Radius of anode at tip
tary = 0.5 * tipXY(4);
x2 = point2(1);
y2 = point2(2);
z2 = point2(3);

tip2 = [x2+tarx x2-tarx x2-tarx x2+tarx x2+barx x2-barx x2-barx x2+barx;
        y2-tary y2-tary y2+tary y2+tary y2-bary y2-bary y2+bary y2+bary;
        z2      z2      z2      z2      z2+th2  z2+th2  z2+th2  z2+th2];

tip2tri = [ 9    16    10    13    11    14    12    15     9    11;
           13    12    14     9    15    10    16    11    12    10;
           16     9    13    10    14    11    15    12    11     9];

tip2ids = [6 6 7 7 8 8 9 9 10 10]; % Face identfiers for each triangle

% Insulation makes the shaft thicker. Insulation thickness should be >= 1.
% Platinum iridium electrodes have around 3um insulation.
% Cathode insulation lip above tip = nodes 17..20
bcrx = 0.5 * baseXY(1) + tipInsulationThickness(1);
bcry = 0.5 * baseXY(2) + tipInsulationThickness(1);
zbot = zLimits(1);       % Deepest tissue limit is near 0
ztop = zLimits(2);       % Tissue surface is near maximum z value

ins1 = [x1+bcrx x1-bcrx x1-bcrx x1+bcrx; % Insulation lip at cathode tip
        y1-bcry y1-bcry y1+bcry y1+bcry;
        z1+th1 z1+th1 z1+th1 z1+th1];

ins1tri = [ 5    18     6    19     7    20     8    17;
            6    17     7    18     8    19     5    20;
           18     5    19     6    20     7    17     8];

ins1ids = [11 11 11 11 11 11 11 11]; % Insulation lip is co-planar

% Anode insulation lip above tip = nodes 21..24
barx = 0.5 * baseXY(3) + tipInsulationThickness(2);
bary = 0.5 * baseXY(4) + tipInsulationThickness(2);

ins2 = [x2+barx x2-barx x2-barx x2+barx;
        y2-bary y2-bary y2+bary y2+bary;
        z2+th2 z2+th2 z2+th2 z2+th2];

ins2tri = [13    22    14    23    15    24    16    21;
           14    21    15    22    16    23    13    24;
           22    13    23    14    24    15    21    16];

ins2ids = [12 12 12 12 12 12 12 12]; % Insulation lip is co-planar

% Cathode entry at top boundary = nodes 25..28
e1 = [x1+bcrx x1-bcrx x1-bcrx x1+bcrx; % Insulation at top entry bound
      y1-bcry y1-bcry y1+bcry y1+bcry;
      ztop   ztop   ztop   ztop];

e1tri = [17    26    18    27    19    28    20    25; % Insulated cathode shaft
         18    25    19    26    20    27    17    28;
         26    17    27    18    28    19    25    20];

e1ids = [13 13 14 14 15 15 16 16]; % shaft has 4 sides

% Anode entry at top boundary = nodes 29..32
e2 = [x2+barx x2-barx x2-barx x2+barx;
      y2-bary y2-bary y2+bary y2+bary;
      ztop   ztop   ztop   ztop];

e2tri = [21    30    22    31    23    32    24    29; % Insulated anode shaft
         22    29    23    30    24    31    21    32;
         30    21    31    22    32    23    29    24];

e2ids = [17 17 18 18 19 19 20 20];

% Bounding volume = nodes 33,34,35,36 (top surface) and 37,38,39,40 (bottom depth)
xmin = xLimits(1);
xmax = xLimits(2);
ymin = yLimits(1);
ymax = yLimits(2);

top = [xmax xmin xmin xmax; % Top outer bound
       ymin ymin ymax ymax;
       ztop ztop ztop ztop];
   
bot = [xmax xmin xmin xmax; % Bottom outer bound
       ymin ymin ymax ymax;
       zbot zbot zbot zbot];

bvtri = [37    34    38    35    39    36    40    33    37    39;
         33    38    34    39    35    40    36    37    38    40;
         34    37    35    38    36    39    33    40    39    37];

bvids = [21 21 22 22 23 23 24 24 25 25]; % 4 sides + bottom

% Create the 2-D geometry of the top tissue bound with holes cut out
% for the electrodes. This is done by tesselating nodes on the top
% surface and then removing triangles that have all three points on
% any one electrode.

pts = [e1 e2 top]';                     % All points in top surface.
DT = delaunay(pts(:,1), pts(:,2)) + 24; % Tesselate and adjust for the 24 tip and lip nodes.
is1 = ismember(DT, (25:28));            % Nodes that touch cathode.
is2 = ismember(DT, (29:32));            % Nodes that touch anode.
select = (sum(is1, 2) <= 2) & (sum(is2, 2) <= 2); % Triangles with two or fewer points on any one electrode.
toptri = DT(select, :)';                % List of top surface bound triangles.
topids = repmat(26, 1, size(toptri, 2));% Top surface bound is face 26.
    
% Construct list of nodes and triangular mesh elements.
nodes = [tip1 tip2 ins1 ins2 e1 e2 top bot];
elements = [tip1tri tip2tri ins1tri ins2tri e1tri e2tri bvtri toptri];
faceIDs = [tip1ids tip2ids ins1ids ins2ids e1ids e2ids bvids topids]; 
    
% Create electrode geometry.
model = createpde();
%model = createpde("electromagnetic","conduction");

%model.geometryFromMesh(nodes, elements, faceIDs);
model.geometryFromMesh(nodes, elements);
pdegplot(model,'FaceAlpha',0.4, 'FaceLabels', 'on');

% Return face IDs for each piece of the electrode.
% It seems like geometryFromMesh() ignores faceIDs, so these values
% should be checked whenever the topology or Matlab version changes.
% The pdegplot() should be saved in the results folder for this purpose.
catfaces = (1:5);       % First 4 faces are the conductive cathode
anofaces = (6:10);      % Second 4 faces are the conductive anode
catinsul = [11 13:16];  % Cathode and anode insulation ...
anoinsul = [12 17:20];  %   ... usually combined later with outfaces.
outfaces = (21:26);     % Bounding volume

% Warn about some obvious errors
if (z1-th1 >= ztop) || (z2-th2 >= ztop)
    disp('BipoloarElectrodeGeometry: Bad electrode depth or tip length. Electrodes must be below top bound.');
end

if (z1 <= zbot) || (z2 <= zbot)
    disp('BipoloarElectrodeGeometry: Bad electrode depth or tip length. Electrodes must be above bottom bound.');
end

if any(tipLengths < 40)
    disp('BipoloarElectrodeGeometry: tip lengths < 40 may not generate expected geometry');
end

