function testpsth(results_directory)
% Creates a peri-stimulus time histogram of spikes occuring in a region
% below stimulus sites.

nearness = 100;         % Micron radius around stimulus site origin
peak_window_ms = [0 250]; % Count spikes occuring in this time window after a stimulus is delivered.
baseline_ms = 10;       % Time before stimulus for measuring baseline activity.
pre_ms = 50;            % Histogram time range
post_ms = 1050;
top_layer_boundary = 2; % 1 surface, 2 = top L2/3, 3 = top L4, 4 = top L5, 5 = top L6, 6 = Bottom of L6
bot_layer_boundary = 3;


%%
addpath(genpath(pwd));
if nargin >= 1
    directory = results_directory;
else
    directory = './vertex_results';
end
close_flag = false; % Whether of not to close figures once saved.

%% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

disp('Loading results...');
Results = loadResults(directory);
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(directory, 'synapses_');
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);
sampleRate = Results.params.RecordingSettings.sampleRate;
simulationTime = Results.params.SimulationSettings.simulationTime;
timeStep = Results.params.SimulationSettings.timeStep;
unit_hz = zeros(nUnits,1);
spike_time_ms = Results.spikes(:,2);
spike_maxtime_sec = max(spike_time_ms) / 1000;
spike_time_sec1 = floor((Results.spikes(:,2) / 1000)) + 1;
spike_unit_id = floor(Results.spikes(:,1));
markers = '0+*x^vdsp';
colors =  'krgbcm';
if isempty(Results.events)
    stim_times = [];
    stim_ids = [];
else
    index = find([Results.events.marker] ~= '|');
    events = Results.events(index);
    stim_times = [events.time_ms];
    stim_ids = [events.id];
    color_ind = mod(ceil(stim_ids / length(markers)), length(colors)) + 1;
    stim_marker = mod(stim_ids, length(markers)) + 1;
end

%%
% Calculate which units belong to which groups
TP = Results.params.TissueParams;
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

% Divide slice into cubes
bin_size = 25; % microns
x_bins = (0:bin_size:TP.X);
y_bins = (0:bin_size:TP.Y);
z_bins = (0:bin_size:TP.Z);
x_somas = TP.somaPositionMat(:, 1);
y_somas = TP.somaPositionMat(:, 2);
z_somas = TP.somaPositionMat(:, 3);
ix = floor(x_somas / bin_size) + 1;
iy = floor(y_somas / bin_size) + 1;
iz = floor(z_somas / bin_size) + 1;

%%
% Find somas in a cylinder around Site 1 and Site 2.

if isfield(TP, 'stim_electrode_xpos')
    n_elect = size(TP.stim_electrode_xpos, 1);
elseif isfield(TP, 'opto_source_xpos')
    n_elect = length(TP.opto_source_xpos);
else
    n_elect = 0;
end

for ielect = 1:n_elect
    if isfield(TP, 'stim_electrode_xpos')
        x_elect = mean(TP.stim_electrode_xpos(ielect,1:2));
        y_elect = mean(TP.stim_electrode_ypos(ielect,1:2));
        z_elect = mean(TP.stim_electrode_zpos(ielect,1:2));
        delay = TP.stim_delay_ms(ielect);
    elseif isfield(TP, 'opto_source_xpos')
        x_elect = mean(TP.opto_source_xpos(ielect));
        y_elect = mean(TP.opto_source_ypos(ielect));
        z_elect = mean(TP.opto_source_zpos(ielect));
        delay = TP.opto_train_delay_ms(ielect);
    end

    ztop = TP.layerBoundaryArr(top_layer_boundary); 
    if top_layer_boundary == 2
        ztop = ztop - 50;  % Unit positions start slightly below L2/3 boundary
    end
    zbot = TP.layerBoundaryArr(bot_layer_boundary);

    is_elect = (z_somas < ztop) & (z_somas > zbot) & ...
        (sqrt((x_somas - x_elect).^2 + (y_somas - y_elect).^2) <= nearness);
    n_site_units = length(spike_unit_id(is_elect));

    %%
    % Activity plot for spikes occurring just after a stimulus.
    % Count how many spikes occur for units in each bin.
    % Coincidence window and baseline must fit in the [-50,150) ms data window.
        
    coincidence_ms = peak_window_ms + delay;
    n = length(spike_unit_id);
    psth = zeros(1, pre_ms + post_ms);
    act = zeros(length(z_bins), length(x_bins));    % Activity
    bact = zeros(length(z_bins), length(x_bins));   % Baseline
    base_count = 0;
    peak_count = 0;

    stim_ms = [];
    if ~isempty(stim_times)
        stim_ms = stim_times(stim_ids == 1);
    elseif isfield(TP, 'stim_ms')
        stim_ms = TP.stim_ms;
        stim_delay = TP.stim_delay_ms;
        stim_size = TP.stim_size;
    end
    
    % Calculate unit layers.
    layer_tops = TP.layerBoundaryArr;
    unit2layer = ones(1, nUnits); % Converts unit index to a layer
    nlayers = length(layer_tops) - 1;
    for i = 1:nlayers
        unit2layer( (z_somas <= layer_tops(i)) & (z_somas > layer_tops(i+1)) ) = i;
    end
    layer_names = {'surf', 'L23', 'L4', 'L5', 'L6', 'L6bot'};
    
    end_ms = pre_ms + post_ms;
    costr = [num2str(coincidence_ms(1)) '-' num2str(coincidence_ms(2)) ...
        'ms,' layer_names{top_layer_boundary} '-' layer_names{bot_layer_boundary}];

    if length(stim_ms) > 1
        for i = 1:n % Run through list of spikes
            % count spikes near first stim in the pair
            id = spike_unit_id(i);
            xi = ix(id);
            zi = iz(id);
            deltat_ms = spike_time_ms(i) - stim_ms;
            index = find((deltat_ms >= -pre_ms) & (deltat_ms < post_ms));  % spikes inside PSTH window
            for j = index
                dt = floor(deltat_ms(j)) + pre_ms + 1; % Bin for ith spike
                if is_elect(id)
                    psth(dt) = psth(dt) + 1;
                end
                if (deltat_ms(j) >= coincidence_ms(1)) && (deltat_ms(j) < coincidence_ms(2))
                    % count spike if it occurred upto dt ms after a stimulus
                    act(zi, xi) = act(zi, xi) + 1;
                    if is_elect(id)
                        peak_count = peak_count + 1;  
                    end
                elseif (deltat_ms(j) >= -baseline_ms) && (deltat_ms(j) < 0)
                    % count baseline spikes
                    bact(zi, xi) = bact(zi, xi) + 1;
                    if is_elect(id)
                        base_count = base_count + 1;   
                    end
                end
            end
        end
        hfig = figure;
        hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 550 800];
        subplot(2,1,1);
        histogram('BinEdges', -50:post_ms, 'BinCounts', psth);
        xlim([-50 post_ms]);
        set(gca, 'XTick', [-50, 0, post_ms]);
        set(gca, 'TickDirMode', 'manual')
        set(gca, 'TickDir', 'both')
        ntrials = length(stim_ms);
        base_hz = (1000 / baseline_ms) * base_count / ntrials / n_site_units;
        peak_hz = (1000 / diff(coincidence_ms)) * peak_count / ntrials / n_site_units;
        title(['PSTH Stim1 -> Site' num2str(ielect) ' (trials: ' num2str(ntrials) ', units: ' num2str(n_site_units) ')']);
        xlabel(['ms, Baseline (' num2str(baseline_ms) 'ms) Hz/unit: ' num2str(base_hz) ', Response (' costr ') Hz/unit: ' num2str(peak_hz)]);
        ylabel('Counts');

        % Plot XZ projection of where spikes were correlated with stimulation
        subplot(2,1,2);
        h = pcolor(act);
        set(gca, 'YTick', 0:20:length(x_bins));
        set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
        set(gca, 'YTick', flip(length(z_bins):-20:0));
        set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
        h.LineStyle = 'none'; % Remove grid lines.
        colorbar;
        hold on;
        % plot electrode positions
        plot((x_elect/bin_size)+1, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
        % plot rectangle around electrode area
        x1 = x_elect - nearness;
        x2 = x_elect + nearness;
        line(([x1 x2 x2 x1 x1]/bin_size) + 1, floor([ztop ztop zbot zbot ztop]/bin_size), 'Color', [1 0 0]);
        title(['Stim -> Spike Coincidence Count (' costr ')']);
        xlabel('X');
        ylabel('Depth');

        save_figure(directory, ['PSTH_stim1_to_site' num2str(ielect) '(' costr ')'], hfig, close_flag);
    end
end

return;

%%
% Calculate unit firing frequency progression for each unit group.
% This shows how stable firing rates are over the course of the simulation.

% Calculate which units belong to which groups
nUnits = length(syn_arr); % Number of units
group_names = get_group_names();
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

% Estimate fire rate of each unit by counting the number of times it 
% spikes during each 1 second period.

freq_prog = zeros(nGroups, floor(spike_maxtime_sec)+1, 43);
mean_unit_hz = zeros(1,floor(spike_maxtime_sec)+1);
max_unit_hz = zeros(1,floor(spike_maxtime_sec)+1);
isec = 1;
n = length(spike_unit_id);
for ispike = 1:n
    if spike_time_sec1(ispike) > isec
        % Record the firing rate histogram for this second
        max_unit_hz(isec) = max(unit_hz);
        mean_unit_hz(isec) = mean(unit_hz);
        unit_hz = min(unit_hz, 40) + 1;
        for iunit = 1:nUnits
            group_id = unit2group(iunit);
            ihz = unit_hz(iunit);
            freq_prog(group_id, isec, ihz) = freq_prog(group_id, isec, ihz) + 1;
        end
        unit_hz = zeros(nUnits, 1);
        isec = spike_time_sec1(ispike);
    end
    unit_id = spike_unit_id(ispike);
    unit_hz(unit_id) = unit_hz(unit_id) + 1;
end

if isec > 1
    hfig = figure;
    m = zeros(size(freq_prog,2), size(freq_prog,3));
    for igroup = 1:nGroups
        subplot(4, 4, igroup);
        m(:,:) = freq_prog(igroup,:,:);
        h = pcolor(m');
        h.LineStyle = 'none'; % Remove grid lines.
        if igroup >= 12
            xlabel('Seconds');
        end
        if ismember(igroup, [1 5 9 13])
            ylabel('Hz');
        end
        title(group_names{igroup});
        set(gca, 'XTickLabel', cellstr(num2str(get(gca, 'XTick')' - 1))); % Correct axes to start at 0 sec
    end
    subplot(4,4,16);
    plot([mean_unit_hz(1:end-1)', max_unit_hz(1:end-1)']);
    xlabel('Seconds');
    title('mean, max');
    save_figure(directory, 'firing_rate_progression', hfig, close_flag);
end

% Summary Firing Rate Statisics
aggregate_spike_rate = length(spike_time_ms) * 1000 / simulationTime;
disp(['Aggregate spike rate = ' num2str(aggregate_spike_rate) ' Hz']);
gbid = TP.groupBoundaryIDArr;

ngroups = length(gbid) - 1;
ind = cell(ngroups, 1);
ind2 = cell(ngroups, 1);
nunits = zeros(ngroups, 1);
for i = 1:ngroups
    nunits(i) = gbid(i+1) - gbid(i);
    ind{i} = find(spike_unit_id > gbid(i) & spike_unit_id <= gbid(i+1));
    ind2{i} = find(spike_unit_id > gbid(i) & spike_unit_id <= gbid(i+1) & spike_time_ms >= 0.5*simulationTime);
end

%%
%Calculate spike rate for each unit
nspikes = zeros(1, nUnits);
n = length(spike_unit_id);
for i = 1:n
    id = spike_unit_id(i);
    nspikes(id) = nspikes(id) + 1;
end

% Look at firing rates by soma location
act = zeros(length(z_bins), length(x_bins));
maxact = zeros(length(z_bins), length(x_bins));
nact = zeros(length(z_bins), length(x_bins));
for i = 1:nUnits
    nact(iz(i), ix(i)) = nact(iz(i), ix(i)) + 1; 
    act(iz(i), ix(i)) = act(iz(i), ix(i)) + nspikes(i); 
    maxact(iz(i), ix(i)) = max(maxact(iz(i), ix(i)), nspikes(i));
end
act = (act ./ max(1,nact)) * 1000 / simulationTime; % Activity in spikes per second

hfig = figure;
subplot(2,1,1);
h = pcolor(act);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', 0:20:length(z_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Mean firing frequency map (Hz)');
colorbar;
if ~isempty(x_elect)
    hold on; % plot electrode positions
    plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
end

subplot(2,1,2);
h = pcolor(maxact * 1000 / simulationTime);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', 0:20:length(z_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Maximum firing frequency map (Hz)');
colorbar;
if ~isempty(x_elect)
    hold on; % plot electrode positions
    plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
end
save_figure(directory, 'firing_rate_map', hfig, close_flag);

%%
% Display mean firing rates by group
fname = [directory '\group_firing_rates.txt'];
if exist(fname, 'file')
    delete(fname);
end
diary(fname);
group_spike_rate = zeros(ngroups, 1);
group_mean_spike_rate = zeros(ngroups, 1);
for i = 1:ngroups
    group_spike_rate(i) = length(ind{i}) * (1000 / simulationTime);
    group_mean_spike_rate(i) = group_spike_rate(i) / nunits(i);
    disp(['Group ' num2str(i) ' (' group_names{i} '), n = ' num2str(nunits(i)) ...
        ', mean spike rate (all time) = ' num2str(group_mean_spike_rate(i)) ' Hz']);
end

% only using last half of data
group_spike_rate2 = zeros(ngroups, 1);
group_mean_spike_rate2 = zeros(ngroups, 1);
for i = 1:ngroups
    group_spike_rate2(i) = length(ind2{i}) * 1000 / (0.5 * simulationTime);
    group_mean_spike_rate2(i) = group_spike_rate2(i) / nunits(i);
    disp(['Group ' num2str(i) ' (' group_names{i} '), n = ' num2str(nunits(i)) ...
        ', mean spike rate (2nd half) = ' num2str(group_mean_spike_rate2(i)) ' Hz']);
end
diary off;


