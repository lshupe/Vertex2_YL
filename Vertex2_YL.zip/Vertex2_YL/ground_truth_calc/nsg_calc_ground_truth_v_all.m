addpath(genpath(pwd));
disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);

disp_with_time('loading connections from directory');
% Load connections, params from relative path
%%
% SPECIFY INPUT DIRECTORY HERE
% dir = 'vertex_results';
dir = 'C:\Users\Julien\lab\network_sim\vertex_2\test';
params = load_params_from_dir(dir);
[synapses, weights] = load_randomized_connectivity(params, dir); 
disp_with_time('connections loaded, generating sparse connectivity matrix');

%% Load results and get voltages
if isempty(results)
    results = loadResults(dir);
end

mean_voltages = mean(results.v_m, 2);


%% Generate sparse matrix
e_connectivity_matrix = get_sparse_weighted_connectivity_2(params, synapses, weights, 'e');
i_connectivity_matrix = get_sparse_weighted_connectivity_2(params, synapses, weights, 'i');

%%
%e_neuron_calc_matrix = zeros(size(ground_truth_matrix_i));
% inhibitory calculations
% inhibitory ground truth, post synaptic neurons (columns) * (mean
% voltages - 75)
for i=1:size(mean_voltages,1)
    for j = 1: size(mean_voltages,1)
        i_connectivity_matrix(i,j) = i_connectivity_matrix(i,j) * (mean_voltages(j) - 75);
        %mean_voltages(fix((i-1)/100) + 1);
    end
end

% excitatory calculations
% excitator ground truth, post synaptic neurons (columns) * mean voltages
for i=1:size(mean_voltages,1)
    for j = 1: size(mean_voltages,1)
        e_connectivity_matrix(i,j) = e_connectivity_matrix(i,j) * mean_voltages(j);
        %mean_voltages(fix((i-1)/100) + 1);
    end
end

%% add resultings matrices together
% make excitatory positive
e_connectivity_matrix = e_connectivity_matrix*-1;
ground_truth_matrix = (e_connectivity_matrix + i_connectivity_matrix);

%%
disp_with_time('sparse matrix generated, calculated ground truth');
% Loop through electrodes, calculate ground truth per electrode pair
num_electrodes = length(params.RecordingSettings.meaXpositions);

%%
num_pairs = num_electrodes^2;
ground_truth_matrix_flat = zeros(num_pairs, 1);
indices = zeros(num_pairs, 2);
count = 1;
for i = 1:num_electrodes
    for j = 1:num_electrodes
        indices(count, 1) = i;
        indices(count, 2) = j;
        count = count + 1;
    end
end
parfor idx = 1:num_pairs
    i = indices(idx, 1);
    j = indices(idx, 2);
    disp_with_time(strcat('calculating ground truth for electrodes: ', ...
    num2str(i), ', ', num2str(j)));
    ground_truth = evaluate_ground_truth_connectivity(...
        params, connectivity_matrix, i, j);
    ground_truth_matrix_flat(idx) = ground_truth;
end

%%
ground_truth_matrix = zeros(num_electrodes, num_electrodes);
for idx = 1:num_pairs
    i = indices(idx, 1);
    j = indices(idx, 2);
    ground_truth_matrix(i, j) = ground_truth_matrix_flat(idx);
end

% SPECIFY OUTPUT DIRECTORY HERE
if ~exist('vertex_results', 'dir')
    mkdir('vertex_results');
end

save_path = 'vertex_results/ground_truth_v_all.mat';
save(save_path, 'ground_truth_matrix', '-v7.3');