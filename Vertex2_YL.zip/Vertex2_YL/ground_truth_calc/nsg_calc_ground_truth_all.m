addpath(genpath(pwd));
disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);

disp_with_time('loading connections from directory');
% Load connections, params from relative path
%%
% SPECIFY INPUT DIRECTORY HERE
dir = 'vertex_results';
params = load_params_from_dir(dir);
[synapses, weights] = load_randomized_connectivity(params, dir); 
disp_with_time('connections loaded, generating sparse connectivity matrix');
% Generate sparse matrix
connectivity_matrix = get_sparse_weighted_connectivity_2(params, synapses, weights, 'all');

disp_with_time('sparse matrix generated, calculated ground truth');
% Loop through electrodes, calculate ground truth per electrode pair
num_electrodes = length(params.RecordingSettings.meaXpositions);
%%
num_pairs = num_electrodes^2;
ground_truth_matrix_flat = zeros(num_pairs, 1);
indices = zeros(num_pairs, 2);
count = 1;
for i = 1:num_electrodes
    for j = 1:num_electrodes
        indices(count, 1) = i;
        indices(count, 2) = j;
        count = count + 1;
    end
end
parfor idx = 1:num_pairs
    i = indices(idx, 1);
    j = indices(idx, 2);
    disp_with_time(strcat('calculating ground truth for electrodes: ', ...
    num2str(i), ', ', num2str(j)));
    ground_truth = evaluate_ground_truth_connectivity(...
        params, connectivity_matrix, i, j);
    ground_truth_matrix_flat(idx) = ground_truth;
end

%%
ground_truth_matrix = zeros(num_electrodes, num_electrodes);
for idx = 1:num_pairs
    i = indices(idx, 1);
    j = indices(idx, 2);
    ground_truth_matrix(i, j) = ground_truth_matrix_flat(idx);
end

% SPECIFY OUTPUT DIRECTORY HERE
if ~exist('vertex_results', 'dir')
    mkdir('vertex_results');
end

save_path = 'vertex_results/ground_truth_all.mat';
save(save_path, 'ground_truth_matrix', '-v7.3');        