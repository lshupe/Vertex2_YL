function [matrix] = get_group_weight_matrix(params)
    %GET_GROUP_WEIGHT_MATRIX Summary of this function goes here
    %   Detailed explanation goes here
    len = length(params.ConnectionParams);
    matrix = zeros(len, len, 'uint16');
    for i = 1:len
        for j = 1:len
            if ~isempty(params.ConnectionParams(i).weights{j})
                matrix(i, j) = params.ConnectionParams(i).weights{j};
            end
        end
    end
end

