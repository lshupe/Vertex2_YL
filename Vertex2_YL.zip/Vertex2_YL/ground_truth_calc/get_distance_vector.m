function[distances] = get_distance_vector(params, point)
% Returns a vector of 1 x N (where N is number of neurons) 
% representing the distance between each neuron and the point
% Point passed in as 1 x 3 vector, [x, y, z]
    soma_positions = params.TissueParams.somaPositionMat(:, [1:3]);
    diff = soma_positions - point;
    distances = vecnorm(diff.');
end