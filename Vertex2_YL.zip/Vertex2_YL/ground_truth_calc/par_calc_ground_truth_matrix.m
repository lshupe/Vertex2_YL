function [ground_truth_matrix] = par_calc_ground_truth_matrix(params, connectivity_matrix, radius)
    has_radius = exist('radius', 'var');

    % Loop through electrodes, calculate ground truth per electrode pair
    num_electrodes = length(params.RecordingSettings.meaXpositions);
    %%
    num_pairs = num_electrodes^2;
    ground_truth_matrix_flat = zeros(num_pairs, 1);
    indices = zeros(num_pairs, 2);
    count = 1;
    for i = 1:num_electrodes
        for j = 1:num_electrodes
            indices(count, 1) = i;
            indices(count, 2) = j;
            count = count + 1;
        end
    end
    parfor idx = 1:num_pairs
        i = indices(idx, 1);
        j = indices(idx, 2);
        disp_with_time(strcat('calculating ground truth for electrodes: ', ...
        num2str(i), ', ', num2str(j)));
        if has_radius
            ground_truth = evaluate_ground_truth_connectivity_with_radius(...
                params, connectivity_matrix, i, j, radius);
        else
            ground_truth = evaluate_ground_truth_connectivity(...
                params, connectivity_matrix, i, j);
        end
        ground_truth_matrix_flat(idx) = ground_truth;
    end

    %%
    ground_truth_matrix = zeros(num_electrodes, num_electrodes);
    for idx = 1:num_pairs
        i = indices(idx, 1);
        j = indices(idx, 2);
        ground_truth_matrix(i, j) = ground_truth_matrix_flat(idx);
    end
end



