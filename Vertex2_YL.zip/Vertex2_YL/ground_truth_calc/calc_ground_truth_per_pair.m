function [res] = calc_ground_truth_per_pair(pair, params, ...
    connectivity_matrix)
    i = pair{1}(1);
    j = pair{1}(2);
    res = evaluate_ground_truth_connectivity(...
            params, connectivity_matrix, i, j);
end


