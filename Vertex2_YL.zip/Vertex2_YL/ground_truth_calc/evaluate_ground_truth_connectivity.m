function [res] = evaluate_ground_truth_connectivity(params, ...
    connectivity_matrix, electrode_id_1, electrode_id_2)
    RS = params.RecordingSettings;
    pos_1 = [RS.meaXpositions(electrode_id_1), ...
             RS.meaYpositions(electrode_id_1), ...
             RS.meaZpositions(electrode_id_1)];
    pos_2 = [RS.meaXpositions(electrode_id_2), ...
             RS.meaYpositions(electrode_id_2), ...
             RS.meaZpositions(electrode_id_2)];
    distance_vec_1 = get_distance_vector(params, pos_1);
    distance_vec_2 = get_distance_vector(params, pos_2);
    inverse_1 = 1 ./ (distance_vec_1);
    inverse_2 = 1 ./ (distance_vec_2);
    res = sum(connectivity_matrix .* inverse_1' .* inverse_2, 'all');
end


