function [sparse_weighted_connectivity] = get_sparse_weighted_connectivity(params, connections, mode)
    %GETSPARSECONNECTIVITY Gets the sparse weighted connectivity matrix for the network.
    %   SPARSEWEIGHTEDCONNECTIVITY = GETSPARSECONNECTIVITY(PARAMS, CONNECTIONS)
    %   calculates a sparse matrix representation of the connections between
    %   all the neurons in the model. The first input parameter PARAMS - is the
    %   parameter structure returned by initNetwork(). The second parameter 
    %   CONNECTIONS is the connection cell array (serial mode) or composite 
    %   (parallel mode) returned by initNetwork(). Rows in the returned sparse
    %   matrix represent the IDs of presynaptic neurons and columns the IDs of
    %   postsynaptic neurons. If neuron i synapses onto synapse j, then
    %   SPARSEWEIGHTEDCONNECTIVITY(i,j) will contain the weight of neuron
    %   group i to neuron group j, multiplied by the number of synapses
    %   from i to j. 

    if ~exist('mode', 'var')
        mode = 'all';
    end

    if params.SimulationSettings.parallelSim
      parallelSim = true;
      numLabs = params.SimulationSettings.poolSize;
    else
      parallelSim = false;
      numLabs = 1;
    end

    N = params.TissueParams.N;

    presumedMaxConnections = 6000;
    allpost = zeros(N*presumedMaxConnections, 1, 'uint32');
    allpre = zeros(N*presumedMaxConnections, 1, 'uint32');
    alldel = zeros(N*presumedMaxConnections, 1, 'uint16');

    disp_with_time("Finding neuron to group mapping");
    neuronToGroup = get_neuron_to_group(params);
    groupWeightMatrix = get_group_weight_matrix(params);
    disp_with_time("Neuron to group mapping finished, moving on");
    valid_neurons = get_valid_neurons(params, neuronToGroup, mode);
    count = 0;
    for iLab = 1:numLabs
      if parallelSim
        sa = connections{iLab};
      else
        sa = connections;
      end
      for iN = valid_neurons
        s = sa{iN, 1};
        w = get_post_weights(iN, s, neuronToGroup, groupWeightMatrix);
        allpost(count+1:count+length(s)) = s;
        allpre(count+1:count+length(s)) = iN;
%         alldel(count+1:count+length(s)) = uint16(sa{iN, 2}) .* w;
        alldel(count+1:count+length(s)) = w;
        count = count+length(s);
      end
      if parallelSim
        disp_with_time([ num2str(iLab) ' labs done ...']);
      end
    end

    disp_with_time('Creating sparse matrix...');
    sparse_weighted_connectivity = sparse(double(allpost(1:count)), ...
                                double(allpre(1:count)), ...
                                double(alldel(1:count)), N, N);
    disp_with_time('Done!');
end

function [w] = get_post_weights(preId, postArr, neuronToGroup, groupWeightMatrix)
    w = zeros(1, length(postArr), 'uint16');
    for i = 1:length(postArr)
        preGroup = neuronToGroup(preId);
        postGroup = neuronToGroup(postArr(i));
        w(1, i) = groupWeightMatrix(preGroup, postGroup);
    end
end

function [valid_neurons] = get_valid_neurons(params, neuron_to_group, mode)
    N = params.TissueParams.N;
    if exist('mode', 'var')
        if strcmp(mode, 'i')
            valid_groups = [2 3 7 8 11 12 15];
        elseif strcmp(mode, 'e')
            valid_groups = [1 4 5 6 9 10 13 14];
        elseif strcmp(mode, 'all')
            valid_neurons = 1:N;
            return
        else
            error("Mode must either be 'all', or 'i' or 'e' for excitatory only or inhibitory only'");
        end
        valid_neurons = find(ismember(neuron_to_group, valid_groups))';
    else
        valid_neurons = 1:N;
    end
end