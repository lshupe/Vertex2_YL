function [sparse_weighted_connectivity] = get_sparse_weighted_connectivity_2(params, synapses, weights, mode)
    %GETSPARSECONNECTIVITY Gets the sparse weighted connectivity matrix for the network.
    %   SPARSEWEIGHTEDCONNECTIVITY = GETSPARSECONNECTIVITY(PARAMS, CONNECTIONS)
    %   calculates a sparse matrix representation of the connections between
    %   all the neurons in the model. The first input parameter PARAMS - is the
    %   parameter structure returned by initNetwork(). The second parameter 
    %   CONNECTIONS is the connection cell array (serial mode) or composite 
    %   (parallel mode) returned by initNetwork(). Rows in the returned sparse
    %   matrix represent the IDs of presynaptic neurons and columns the IDs of
    %   postsynaptic neurons. If neuron i synapses onto synapse j, then
    %   SPARSEWEIGHTEDCONNECTIVITY(i,j) will contain the weight of neuron
    %   group i to neuron group j, multiplied by the number of synapses
    %   from i to j. 

    if params.SimulationSettings.parallelSim
      parallelSim = true;
      numLabs = params.SimulationSettings.poolSize;
    else
      parallelSim = false;
      numLabs = 1;
    end

    N = params.TissueParams.N;

    presumedMaxConnections = 6000;
    allpost = zeros(N*presumedMaxConnections, 1, 'uint32');
    allpre = zeros(N*presumedMaxConnections, 1, 'uint32');
    alldel = zeros(N*presumedMaxConnections, 1, 'double');

    disp_with_time("Finding neuron to group mapping");
    neuronToGroup = get_neuron_to_group(params);
    disp_with_time("Neuron to group mapping finished, moving on");
    valid_neurons = get_valid_neurons(params, neuronToGroup, mode);
    fprintf('%d valid neurons found\n', length(valid_neurons));
    count = 0;
    for iLab = 1:numLabs
      if parallelSim
        sa = synapses{iLab};
        wa = weights{iLab};
      else
        sa = synapses.synapses;
        wa = weights.weights;
      end
      for iN = valid_neurons
        s = sa{iN, 1};
        w = wa{iN, 1};
%         if length(s) ~= length(w)
%             fprintf('length mismatch, s has length %d and w has length %d', length(s), length(w));
%         end
%         if nnz(w) ~= length(w)
%             fprintf('There are weights of zero in w');
%         end
%         disp('look at w');
%         disp(w)
        % TODO: check that no weights are zero, 
        % length s = length w
        allpost(count+1:count+length(s)) = s;
        allpre(count+1:count+length(s)) = iN;
        alldel(count+1:count+length(s)) = w;
%         fprintf('start idx is: %d\n', count+1);
%         fprintf('end idx is: %d\n', count+length(s));
%         fprintf('alldel nnz: %d\n', nnz(alldel));
        count = count+length(s);
%         fprintf('count updated to %d\n', count);
%         disp('--------');
      end
      if parallelSim
%         disp_with_time([ num2str(iLab) ' labs done ...']);
      end
    end
%     fprintf('%d total connections found\n', count);
    disp_with_time('Creating sparse matrix...');
    sparse_weighted_connectivity = sparse(double(allpost(1:count)), ...
                                double(allpre(1:count)), ...
                                double(alldel(1:count)), N, N);
%     i = double(allpost(1:count));
%     fprintf('i has length %d\n', length(i));
%     j = double(allpre(1:count));
%     fprintf('j has length %d\n', length(j));
%     k = double(alldel(1:count));
%     fprintf('k has length %d\n', length(k));
    
%     sparse_weighted_connectivity = sparse(i, j, k, N, N);
%     fprintf('matrix has %d non-zero elements\n', nnz(sparse_weighted_connectivity));
    disp_with_time('Done!');
end

function [valid_neurons] = get_valid_neurons(params, neuron_to_group, mode)
    N = params.TissueParams.N;
    fprintf('calling get_valid_neurons with mode %s\n', mode);
    fprintf('%d total neurons\n', N);
    if exist('mode', 'var')
        if strcmp(mode, 'i')
            valid_groups = [2 3 7 8 11 12 15];
        elseif strcmp(mode, 'e')
            disp("got here, our mode is e\n");
            valid_groups = [1 4 5 6 9 10 13 14];
        elseif strcmp(mode, 'all')
            valid_neurons = 1:N;
            return
        else
            error("Mode must either be 'i' or 'e', for excitatory only or inhibitory only'");
        end
        valid_neurons = find(ismember(neuron_to_group, valid_groups))';
    else
        valid_neurons = 1:N;
    end
    fprintf('%d neurons subselected.\n', length(valid_neurons));
end