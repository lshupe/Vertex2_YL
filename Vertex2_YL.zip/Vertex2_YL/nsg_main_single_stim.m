%% Environment Setup for running Spike-Timing Dependant Plasticity with stimulation conditioning
s = []; % Setup parameters are added to this structure

% Run with local (true), or cluster (false) parameters
s.run_local = false;

% Duration of simulation in milliseconds.
s.simulation_time = 30000;

% Record weights at specfic times (other than initial weights at time=0).
% Stimulation is usually delivered between the first two times.
%s.weight_save_time_ms = [5000 25000 s.simulation_time];

% Optionally load weights from a previously saved simulation with the
% exact same topology, random seed, and parallel processor cores.
% Example: s.LoadWeightsFromFile = '.\weights_';
% This will load files 'weights_1.mat', 'weights_2.mat', ... into
% Lab 1,2,... after weights have been initialized runSimulation.m.
s.LoadWeightsFromFile = '';  % Empty string for normal run.

% Subdirectory for saving results
s.results_dir = 'vertex_results';

% Enable or disable Spike-timing Dependant Plasticity
s.stdp_enabled = false; % true to enable, false to disable STDP

% Field Stimulation Types: 'none' to skip the setup script.
% 'open_loop' for pre-defined pattern stimulation.
% 'closed_loop' for closed-loop pattern stimulation determined at run time.
s.field_stim_type = 'open_loop'; 
s.field_stim_setup_script = 'bsf_stim_single_pulse'; % Setup script for field stimulation

% Optogenetic stimulation types: 'none' to skip the setup script.
% 'open_loop' for pre-defined current based pulse-trains delivered through InputModel_i_opto.
% 'closed_loop' for closed-loop optical pattern stimulation determined at run time.
s.opto_stim_type = 'none';
s.opto_stim_setup_script = 'bsf_opto_single_pulse'; % Setup script for optical stimulation

% Standard Deviation scaler for neuronal input current
s.input_std_scaler = 1.75; % 1.75 [JB];

% Mean scaler for neuronal input current
s.input_mean_scaler = 1.125; % 1.125 [JB];

% Mean scaler for B7 Neuron Group
s.b_4_mean_scaler = 1;

% Standard Deviation scaler specifically for B2/3 Neuron Group input current
s.b_2_3_std_scaler = 1.75; % 1.75 [JB];

% Arborisation radius scaler of syaptic connectivity params
% see http://vertexsimulator.org/tutorial-1/#12 
s.arb_radius_scaler = 1;

%%
% X,Y Dimensions of the model, in micrometers
s.xy_length = [1500 1500];

%% Add current sub-folders to path
addpath(genpath(pwd));
disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);

%% Run Model
% Make 3D Grid of Recording sites
% 2.0 x 2.0 mm: starting at [500, 500, 0], with dimensions [1000, 1000, 2500], with 3x3x6 sites.
% 1.5 x 1.5 mm: Starting at [250, 250, 0], with dimensions [1000, 1000, 2500], with 3x3x6 sites.
% 1.5 x 1.0 mm: Starting at [500, 250, 0], with dimensions [500, 500, 2500], with 3x3x6 sites.
s.coords = make_3D_electrode_grid([250, 250, 0], [1000, 1000, 2500], [3, 3, 6]);
s.should_save_model = false;
s.should_save_ground_truth = false;
s.should_save_randomized_connectivity = true;
s.should_save_v = false;

% Run the model
res = run_bsf_model_stdp_sim(s.xy_length, s.simulation_time, s.coords, s.results_dir, s);
