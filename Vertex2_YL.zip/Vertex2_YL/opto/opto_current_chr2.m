function current_pA = opto_current_ChR2(TP, iopto, neuron_set, irradiance)
% Converts irradiance given in mW/mm^2 to input currents in pA to use
% in an InputModel for optogenetic stimulation.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set is the subset of neurons in the InputModel's neuron group for the current Lab.
% irradiance is an array of values previously calculated by
% opto_irradiance_exp.m.
%
% This is very simple estimate.  Future implementations may need values
% from TP, but this one only uses the irradiance values.
%
% This is an estimated fit of Fig 5A from:
% Theoretical principles underlying optical stimulation of a
% channelrhodopsin-2 positive pyramidal neuron
% Thomas J. Foutz, Richard L. Arlow, and Cameron C. McIntyre
% 15 JUN 2012  https://doi.org/10.1152/jn.00501.2011
%
% Fig 5A shows simulated current responses to irradiance values given
% in mW/mm^2.  It was fit with the following code where x values are
% irradiance (mW/mm^2) and y values are resulting current values (pA).
% >> modelfun = @(b,x)(b(1) * x.^b(2));
% >> % x = [0 10 20 50 100 200 500]; y = [0 390 700 1600 2800 4550 7600]; % Peak values
% >> % x = [0 10 20 50 100 200 500]; y = [0 350 650 1250 1850 2750 4650]; % Plateau values
% >> x = [0 10 20 50]; y = [0 390 700 1600]; % First 4 Peak values
% >> beta = nlinfit(x,y,modelfun,[50 0.8]);
% beta: [49.2742    0.8894];

% There is a choice for estimating the Peak or Plateau values.
% Plateau values are probably better for very long pulses, peak values
% are perhaps better for short pulses.  Here we use fit for the
% first four peak values since we typically see iradiance values < 50
% in the simulations, and stimulus pulses are usually short (< 10 ms).
% Temporal dynamics should be implemented in the input model.

current_pA = 49.2742 .* irradiance .^ 0.8894;  % Peak estimate
