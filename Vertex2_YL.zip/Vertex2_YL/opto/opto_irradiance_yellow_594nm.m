function irradiance_for_subset = opto_irradiance_yellow_594nm(TP, iopto, neuron_set)
% Returns column vector for irradiance in mW/mm^2 at the soma locations
% for the subset of affected neurons. This is an exponential fall-off
% for light absorption combined with 1/d^2 fall-off for a light cone.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set holds the indices of neurons in the InputModel's neuron group
% for the current Lab, this is calculated as the input model's subset + its
% groupBoundary.
%
% The fit is for data from Fig 3E in Yizhar O, Fenno LE, Davidson TJ, 
% Mogri M, Deisseroth K. Optogenetics in neural systems.  Neuron. 2011 
% Jul 14;71(1):9-34. doi: 10.1016/j.neuron.2011.06.004. PMID: 21745635. 
% Values measured off Fig 3E (594 nm) for depth at the center line
% mm = [0  0.224  0.466  0.604  0.928]; % mm from light source (594nm)
% irf = [1  0.5  0.1  0.05  0.01];      % Light power fraction remaining
% However we only fit the 100%, 10%, and 1% points.

% Get millimeter light source and neuron positions from Tissue Parameters
xs = 0.001 * (TP.opto_source_xpos(iopto) - TP.somaPositionMat(neuron_set, 1));
ys = 0.001 * (TP.opto_source_ypos(iopto) - TP.somaPositionMat(neuron_set, 2));
zs = 0.001 * (TP.opto_source_zpos(iopto) - TP.somaPositionMat(neuron_set, 3));
r = 0.001 * TP.opto_source_diameter(iopto) / 2;  % Light source radius in microns

% Fit both absorption and conical irradiance fall-off.
% exp(-x/tau) for light absorption, and
% 1/d^2 mechanics for irradiance fall-off with distance along a light cone.

% mm = [0 0.466 0.928]; % mm from light source (100% 10% 1% values)
% irf = [1 0.1 .01];           % Light power fraction remaining
% modelfn = @(b,x)( exp(-x./b(1)) ./ (1 + b(2) .* x.^2) );
% b = nlinfit(mm,irf, modelfn, [.4  90]);
% figure; plot(mm,irf, 'linewidth', 2); hold on;
% plot(mm,modelfn(b, mm), 'linestyle', '--', 'linewidth', 2);
% plot(0:.010:5, modelfn(b, 0:.01:5), 'linewidth', 2);
% plot(0:.010:5, exp((0:0.01:5)./-.200));
% for i=1:2, plot(0,0, 'Color', [1 1 1]); end % Extra legend info
% legend({'Original', 'Fit@points', 'Fit', 'exp(-x/t), t=0.132mm', ['a = ' num2str(b(1)) ' mm'], ['b = ' num2str(b(2))]});
% ylabel('Fraction initial power density');
% xlabel('Distance from light-source (mm)');
% title('Green (594 nm): exp(-x/a) / (1 + b * x^2)');

a = 0.3784; % Taken from the above fit
b = 8.835;

% Estimate numerical aperature based on b.  This can include other 
% geometric spread and may not represent the optic fiber aperature well.
% Construct a cone of light from fiber edges to 1 mm depth
h = 2 * r * sqrt(1 + b); % length of chord intersected at 1 mm depth.
y = h/2 - r;             % right triangle with sides x=1,y, and angle theta between x and the hypotenuse.
NA = y / sqrt(y.^2 + 1); % NA = sin(theta) = y / hypotenuse)

% Calculate the scale factor for the xy distance based on the ratio of 
% height / half-width of the 1% conture in Fig 3E (right side for 594nm)
xyscale = 1.671; % Ratio of the 1% conture height / half-width

% The irradiance will be diminished based on the angle off the
% side of the light beam.  The scale factor for this is based on
% the numerical aperture such that higher NA values will spread light
% more near the surface.
xydist = sqrt(xs.^2 + ys.^2);
xyoffset = max(0, xydist - r); % Distance from edge of beam
angle_off_vertical = atan2(xyoffset, zs);

% Calculate final distance using depth and scaled XY_distance
d = sqrt((xyscale * xydist).^2 + zs.^2);
initial_irradiance = TP.opto_source_power_mW(iopto) / (pi * r.^2);
irradiance_for_subset = initial_irradiance .* cos((1-NA) * angle_off_vertical) .* exp(-d/a) ./ (1 + b * d.^2);

%Code for checking neuron positions and irradiance values
fid = fopen(['irradiance_values' num2str(labindex) '.m'], 'a+');
for i = 1:length(xs)
  fprintf(fid, 'D(end+1,:)=%g;E(end+1,:)=%g;\n', d(i), irradiance_for_subset(i));
end
% for i = 1:length(xs)
%   fprintf(fid, 'nxyzdi(end+1, :) = [%g %g %g %g %g %g %g];\n', neuron_set(i), xs(i), ys(i), zs(i), d(i), irradiance_for_subset(i), angle_off_vertical(i));
% end
fclose(fid);
% disp(['IR ' num2str(labindex()) ' n ' num2str(length(neuron_set)) ' ir ' num2str(mean(irradiance_for_subset)) ' dist ' num2str(mean(d)) ' z ' num2str(mean(zs))]);
