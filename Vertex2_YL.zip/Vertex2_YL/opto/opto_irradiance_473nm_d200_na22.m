function irradiance_for_subset = opto_irradiance_473nm_r100_NA22(TP, iopto, neuron_set)
% Returns column vector for irradiance in mW/mm^2 at the soma locations
% for the subset of affected neurons. This is an inverse polynomial fit
% to data from https://web.stanford.edu/group/dlab/cgi-bin/graph/chart.php
% For 473 nm light, fiber radius 100um, numerical aperture 0.22
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set holds the indices of neurons in the InputModel's neuron group
% for the current Lab, this is caculated as the input model's subset + its
% groupBoundary.

% Get light source and neuron positions (microns) from Tissue Parameters
xs = TP.opto_source_xpos(iopto) - TP.somaPositionMat(neuron_set, 1);
ys = TP.opto_source_ypos(iopto) - TP.somaPositionMat(neuron_set, 2);
zs = TP.opto_source_zpos(iopto) - TP.somaPositionMat(neuron_set, 3);
r = 0.5 * TP.opto_source_diameter(iopto);  % Light source radius in microns

% Calculate the scale factor for the xy distance based on the observation
% that the penetration depth is similar to the width at half-depth for 
% the low percent-remaining irradiance contours.
xyscale = sqrt(3); % Ratio of the 1% conture height / half-width

% Calculate XY distance from light origin
xydist = sqrt(xs.^2 + ys.^2);

% Calculate millimeter distance using depth and scaled XY distance
x = 0.001 * sqrt((xyscale * xydist).^2 + zs.^2);
r = 0.001 * r;  % Convert microns to millimeters

% Light source irradiance falls off with distance.
initial_irradiance = TP.opto_source_power_mW(iopto) / (pi * r.^2);
a = 11.0058; % The fit coefficients
b = 28.8203;
c = 31.5065;
d = 17.7093; % Note this is for x.^5, there is no x.^4 term.
irradiance_for_subset = initial_irradiance ./ (1 + a*x + b*x.^2 + c*x.^3 + d*x.^5);

% Code for checking neuron positions and irradiance values
% fid = fopen(['diary' num2str(labindex) '.m'], 'a+');
% for i = 1:length(xs)
%   fprintf(fid, 'ndi(end+1, :) = [%g %g %g];\n', neuron_set(i), x(i), irradiance_for_subset(i));
% end
% fclose(fid);
% disp(['IR ' num2str(labindex()) ' n ' num2str(length(neuron_set)) ' ir ' num2str(mean(irradiance_for_subset)) ' dist ' num2str(mean(x)) ' z ' num2str(mean(zs))]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code for fitting original data:

% % From https://web.stanford.edu/group/dlab/cgi-bin/graph/chart.php
% % 473 nm, Fiber NA 0.22, 2.3 mW, Fiber core radius 0.1 mm.
% % Depth, Power attenuation, Geometric Loss, Irradiance (mW/mm^2)
% irvals = [0	1	1	73.18
% 0.05	0.72	0.85	45
% 0.1	0.56	0.73	30.23
% 0.15	0.46	0.64	21.48
% 0.2	0.39	0.56	15.87
% 0.25	0.33	0.5	12.07
% 0.3	0.29	0.44	9.4
% 0.35	0.26	0.4	7.45
% 0.4	0.23	0.36	5.99
% 0.45	0.21	0.32	4.88
% 0.5	0.19	0.3	4.02
% 0.55	0.17	0.27	3.34
% 0.6	0.15	0.25	2.79
% 0.65	0.14	0.23	2.36
% 0.7	0.13	0.21	2
% 0.75	0.12	0.2	1.7
% 0.8	0.11	0.18	1.46
% 0.85	0.1	0.17	1.25
% 0.9	0.09	0.16	1.08
% 0.95	0.09	0.15	0.94
% 1	0.08	0.14	0.82
% 1.05	0.07	0.13	0.71
% 1.1	0.07	0.12	0.62
% 1.15	0.06	0.12	0.54
% 1.2	0.06	0.11	0.48
% 1.25	0.06	0.1	0.42
% 1.3	0.05	0.1	0.37
% 1.35	0.05	0.09	0.33
% 1.4	0.04	0.09	0.29
% 1.45	0.04	0.08	0.26
% 1.5	0.04	0.08	0.23
% 1.55	0.04	0.08	0.2
% 1.6	0.03	0.07	0.18
% 1.65	0.03	0.07	0.16
% 1.7	0.03	0.07	0.14
% 1.75	0.03	0.06	0.13
% 1.8	0.03	0.06	0.11
% 1.85	0.02	0.06	0.1
% 1.9	0.02	0.06	0.09
% 1.95	0.02	0.05	0.08
% 2	0.02	0.05	0.07
% 2.05	0.02	0.05	0.07
% 2.1	0.02	0.05	0.06
% 2.15	0.02	0.05	0.05
% 2.2	0.01	0.05	0.05
% 2.25	0.01	0.04	0.04
% 2.3	0.01	0.04	0.04
% 2.35	0.01	0.04	0.03
% 2.4	0.01	0.04	0.03
% 2.45	0.01	0.04	0.03
% 2.5	0.01	0.04	0.03
% 2.55	0.01	0.04	0.02
% 2.6	0.01	0.03	0.02
% 2.65	0.01	0.03	0.02
% 2.7	0.01	0.03	0.02
% 2.75	0.01	0.03	0.02
% 2.8	0.01	0.03	0.01
% 2.85	0.01	0.03	0.01
% 2.9	0.01	0.03	0.01
% 2.95	0.01	0.03	0.01];
% 
% mm = irvals(:,1)';   % Distance (mm) from light source.
% irf = irvals(:,4)';  % Irradiance (mW/mm^2) at Distance.
% irf = irf / irf(1);  % Normalize to maximmm of 1 since everything is porportional to inital irradiance.
% 
% modelfn = @(b,x)( 1 ./ (b(1) * x + b(2) .* x.^2 + b(3) * x.^3 +  b(4) * x.^5 + 1) );
% b = nlinfit(mm,irf, modelfn, [10 20, 30, 20]);
% 
% figure; plot(mm,irf, 'linewidth', 2); hold on;
% fitblue = modelfn(b, mm);
% err = sum((irf - fitblue).^2) / length(fitblue);
% plot(mm, fitblue, 'linestyle', '--', 'linewidth', 2);
% testmm = 0:0.010:3;
% testblue = modelfn(b, testmm);
% plot(testmm, testblue, 'linewidth', 1);
% for i=1:5, plot(0,0, 'Color', [1 1 1]); end % Extra lengend info
% legend({'Original', 'Fit', 'Interp', ['a = ' num2str(b(1))], ['b = ' num2str(b(2))], ['c = ' num2str(b(3))], ['d = ' num2str(b(4))], ['mse = ' num2str(err)]} );
% ylabel('Irradiance% (mW/mm2)');
% xlabel('Distance from fiber (mm)');
% title('Blue laser (473 nm, r 100 mm, NA .22): 1 / (1 + ax + bx^2 + cx^3 + dx^5)');
% disp(['[a b c d] = ' num2str(b)]);
