function current_pA = opto_current_vfChrimson(TP, iopto, neuron_set, irradiance)
% Converts irradiance given in mW/mm^2 to input currents in pA to use
% in an InputModel for optogenetic stimulation.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set is the subset of neurons in the InputModel's neuron group for the current Lab.
% irradiance is an array of values previously calculated by
% opto_irradiance_exp.m.
%
% This is very simple estimate.  Future implementations may need values
% from TP, but this one only uses the irradiance values.
%
% The Chrimson Irradiance to current function is derived from Fig 3ab of
% "Neha Gupta, Himanshu Bansal, Sukhdev Roy, "Theoretical optimization of 
% high-frequency optogenetic spiking of red-shifted very fast-Chrimson-
% expressing neurons," Neurophoton. 6(2), 025002 (2019),
% doi: 10.1117/1.NPh.6.2.025002."
%
% The data from this figure used 574 nm wavelength light, so this module
% should be paired with opto_irradiance_yellow_594nm.m in the setup script.
% 
% %Photocurrent values were measured off the graph by hand.
% ir = [0.05, 0.2, 0.4, 0.7, 1.2, 2, 4, 10, 30];
% pa = [104, 330, 519, 697, 852, 980, 1114, 1209, 1259]; % photocurrent
% modelfn = @(b,x)(b(1) * (1 - 1 ./ (1 + b(2) .* x) ) );
% b = nlinfit(ir, pa, modelfn, [2000 1]);
% figure; plot(ir, pa, 'linewidth', 2); hold on;
% plot(ir, modelfn(b, ir), 'linestyle', '--', 'linewidth', 2);
% plot(0:0.01:30, modelfn(b, 0:0.01:30), 'linewidth', 2);
% for i=1:2, plot(0,0, 'Color', [1 1 1]); end % Extra legend info
% legend({'Original', 'Fit', 'Fn',  ['a = ' num2str(b(1))], ['b = ' num2str(b(2))]}, 'Location','southeast');
% ylabel('Photocurrent (pA)');
% xlabel('Irradiance (mW/mm^2)');
% title('vfCrimson Photocurrent fit: a * (1 - 1/(1 + bx))');

% There is a choice for estimating the Peak or Plateau values.
% Plateau values are probably better for very long pulses, peak values
% are perhaps better for short pulses.  Here we use fit for the
% peak values since stimulus pulses are usually short (< 10 ms).
% For longer pulses, the data should be refit for plateau values.
% Temporal dynamics should be implemented in the input model, but currently
% this is only tau_on and tau_off for on and off exponential rise/fall.

a = 1278.7;   
b = 1.6977;
current_pA = a * (1 - 1./(1 + b .* irradiance));  % Peak estimate
