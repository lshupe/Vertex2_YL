function irradiance_for_subset = opto_irradiance_exp(TP, iopto, neuron_set)
% Returns column vector for irradiance in mW/mm^2 at the soma locations
% for the subset of affected neurons. This is a simple exponential fall-off
% for points directly under the light cylinder.  XY distance from the
% cylinder edge is factored in for points outside the cylinder.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set holds the indices of neurons in the InputModel's neuron group
% for the current Lab, this is caculated as the input model's subset + its
% groupBoundary.

% Get light source and neuron positions from Tissue Parameters
xs = TP.opto_source_xpos(iopto) - TP.somaPositionMat(neuron_set, 1);
ys = TP.opto_source_ypos(iopto) - TP.somaPositionMat(neuron_set, 2);
zs = TP.opto_source_zpos(iopto) - TP.somaPositionMat(neuron_set, 3);
r = TP.opto_source_diameter(iopto) / 2;  % Light source radius in microns

% Calculate micron distance from light cylinder
xydist = max(zeros(size(xs)), sqrt(xs.^2 + ys.^2) - r);
distance = sqrt(xydist.^2 + zs.^2);

% Light source irradiance falls off exponentially with distance.
r = r / 1000;  % Convert microns to millimeters
tau = TP.opto_source_tau(iopto);
initial_irradiance = TP.opto_source_power_mW(iopto) ./ (pi * r.^2);
irradiance_for_subset = initial_irradiance .* exp(-distance/tau);

% Code for checking neuron positions and irradiance values
% fid = fopen(['diary' num2str(labindex)], 'a+');
% for i = 1:length(xs)
%   fprintf(fid, 'nxyzl(end+1, :) = [%g %g %g %g %g];\n', neuron_set(i), xs(i)+ xpos, ys(i) + ypos, zs(i) + zpos, irradiance_for_subset(i));
% end
% fclose(fid);
% disp(['IR ' num2str(labindex()) ' n ' num2str(length(neuron_set)) ' ir ' num2str(mean(irradiance_for_subset)) ' dist ' num2str(mean(distance)) ' z ' num2str(mean(zs))]);