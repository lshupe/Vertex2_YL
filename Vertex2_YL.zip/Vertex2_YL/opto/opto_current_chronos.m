function current_pA = opto_current_Chronos(TP, iopto, neuron_set, irradiance)
% Converts irradiance given in mW/mm^2 to input currents in pA to use
% in an InputModel for optogenetic stimulation.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set is the subset of neurons in the InputModel's neuron group for the current Lab.
% irradiance is an array of values previously calculated by
% opto_irradiance_exp.m.
%
% This is very simple peak current estimate.  Future implementations may
% need values from TP, but this one only uses the irradiance values.
%
% The Chronos Irradiance to current function is derived from Fig.7 
% (Irradiance vs Peak photocurrent) in Saran S, Gupta N, Roy S. Theoretical
% analysis of low-power fast optogenetic control of firing of 
% Chronos-expressing neurons. Neurophotonics. 2018 Apr;5(2):025009. 
% doi: 10.1117/1.NPh.5.2.025009. Epub 2018 May 24. PMID: 29845088; 
% PMCID: PMC5966744. 
% 
% %Photocurrent values were measured off the graph by hand.
% ir = [0.0  0.10    1.0    3.0    5.0   10.0]; % irradiance mW/mm^2
% pa = [0    192     989    1535   1777  2050]; % picoamps
% modelfn = @(b,x)(b(1) * (1 - 1 ./ (1 + b(2) .* x) ) );
% b = nlinfit(ir, pa, modelfn, [2000 1]);
% figure; plot(ir, pa, 'linewidth', 2); hold on;
% plot(ir, modelfn(b, ir), 'linestyle', '--', 'linewidth', 2);
% plot(0:0.01:20, modelfn(b, 0:0.01:20), 'linewidth', 2);
% for i=1:2, plot(0,0, 'Color', [1 1 1]); end % Extra legend info
% legend({'Original', 'Fit', 'Fn',  ['a = ' num2str(b(1))], ['b = ' num2str(b(2))]}, 'Location','southeast');
% ylabel('Photocurrent (pA)');
% xlabel('Irradiance (mW/mm^2)');
% title('Chronos Photocurrent fit: a * (1 - 1/(1 + bx))');

% There is a choice for estimating the Peak or Plateau values.
% Plateau values are probably better for very long pulses, peak values
% are perhaps better for short pulses. This module uses peak values and
% Chronos has a very short peak response so pulses should be <= 5ms and
% probably closer to 2ms.
% Temporal dynamics should be implemented in the input model.

a = 2293.0;
b = 0.72727;
current_pA = a * (1 - 1./(1 + b .* irradiance));  % Peak estimate
