function current_pA = opto_current_jaws(TP, iopto, neuron_set, irradiance)
% Converts irradiance given in mW/mm^2 to input currents in pA to use
% in an InputModel for optogenetic stimulation.
% This is a fit for the Jaws red-shifted opsin response to 632 nm light.
% This is an inhibitory opsin, returned values are negative.
%
% TP is the set of tissue parameters.
% iopto is the light source index for light sources defined in TP.
% neuron_set is the subset of neurons in the InputModel's neuron group for the current Lab.
% irradiance is an array of values previously calculated by
% opto_irradiance_exp.m.
%
% This is very simple estimate.  Future implementations may need values
% from TP, but this one only uses the irradiance values.
%
% This is an estimated fit of Fig 4C from:
% Noninvasive optical inhibition with a red-shifted microbial rhodopsin
% Chuong AS, Miri ML, Boyden ES, et. al.
% Nature Neuroscience Vol 17:8, Aug 2014, pp 1123-1129
%
% Fig 4C shows current responses to irradiance values given in mW/mm^2.  
% It was fit with the following code where x values are irradiance in
% mW/mm^2 and y values are resulting current values in picoamps.
% Photocurrent values were measured off the graph by hand using Adobe
% Illustrator.
%
% ir = [0  0.1   1   5  10  20]; % irradiance mW/mm^2
% pa = [0  15  125 410 650 835]; % picoamps
% modelfn = @(b,x)(b(1) * (1 - 1 ./ (1 + b(2) .* x) ) );
% b = nlinfit(ir, pa, modelfn, [1250 0.1]);
% figure; plot(ir, pa, 'linewidth', 2); hold on;
% plot(ir, modelfn(b, ir), 'linestyle', '--', 'linewidth', 2);
% plot(0:0.01:20, modelfn(b, 0:0.01:20), 'linewidth', 2);
% for i=1:2, plot(0,0, 'Color', [1 1 1]); end % Extra legend info
% legend({'Original', 'Fit', 'Fn',  ['a = ' num2str(b(1))], ['b = ' num2str(b(2))]}, 'Location','southeast');
% ylabel('Photocurrent (pA)');
% xlabel('Irradiance (mW/mm^2)');
% title('Jaws Photocurrent fit: a * (1 - 1/(1 + bx))');
%
% Supplemental figure 7c shows on/off kinetics tau_on = 3.2 ms,
% tau_off = 4.6 ms in ex-vivo acute motor cortex slice
% These are set in the main parameter script for optical stimulation.

a = -1244.158;
b = 0.10398;
current_pA = a * (1 - 1./(1 + b .* irradiance));

