%%
dir = '~/vertex_results/random_con_long';
params = load_params_from_dir(dir);
[synapses, weights] = load_randomized_connectivity(params, dir); 

%%
soma_positions = params.TissueParams.somaPositionMat(:, [1:3]);

borders = zeros(size(soma_positions));
borders(:, 1) = params.TissueParams.X;
borders(:, 2) = params.TissueParams.Y;
borders(:, 3) = params.TissueParams.Z;

dist_to_far_borders = borders - soma_positions;

dist_to_borders = min(dist_to_far_borders, soma_positions);
min_dist_to_borders = min(dist_to_borders, [], 2);

%%
num_synapses = zeros(size(min_dist_to_borders));

if params.SimulationSettings.parallelSim
  parallelSim = true;
  numLabs = params.SimulationSettings.poolSize;
else
  parallelSim = false;
  numLabs = 1;
end

for iLab = 1:numLabs
  if parallelSim
    sa = synapses{iLab};
  else
    sa = synapses;
  end
  
  for iN = 1:length(sa)
      num_synapses(iN, 1) = num_synapses(iN, 1) + length(sa{iN, 1});
  end
  
end

%%
neuron_to_group = get_neuron_to_group(params);
neuron_to_name = strings(length(neuron_to_group), 1);
group_names = get_group_names();
for i = 1:length(neuron_to_group)
    neuron_to_name(i) = group_names(neuron_to_group(i));
end
%%
gscatter(min_dist_to_borders, num_synapses, neuron_to_name)
hold on
title("Number of Synapses of Neuron by Closest Border Distance to Soma");
ylabel("Number of Synapses");
xlabel("Closest Border Distance (micrometers)");

