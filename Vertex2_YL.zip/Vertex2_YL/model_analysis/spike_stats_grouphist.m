function [] = spike_stats_grouphist(Results, input_dir, should_save)
    %PLOT_LFP_SIGNALS Function that reads the result of a vertex simulation
    % and generates plots for LFP data
    %%
    % Load the simulation results
    num_neurons = Results.params.TissueParams.N;
    neuron_fires = Results.spikes(:, 1);
    time = Results.params.SimulationSettings.simulationTime;
    disp("Average Overall Firing Rate:");
    disp(length(neuron_fires) / num_neurons / time * 1000);
    % calculate firing rate per neuron
    total_fires_by_neuron = zeros(num_neurons, 1);
    
    for i = 1:length(neuron_fires)
        firing_neuron = neuron_fires(i);
        total_fires_by_neuron(firing_neuron) = total_fires_by_neuron(firing_neuron) + 1;
    end
    
    avg_firing_by_neuron = total_fires_by_neuron / time * 1000;
    
    
    [~,edges] = histcounts(log10(avg_firing_by_neuron));
    histogram(avg_firing_by_neuron, 10.^edges)
    set(gca, 'xscale','log')
    file_name = strcat(input_dir, '/firing_rate_hist_log');
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    disp(strcat("Firing rate histogram log scale image path: ", file_name, '.png'));
    
    histogram(avg_firing_by_neuron)
    file_name = strcat(input_dir, '/firing_rate_hist_norm');
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    disp(strcat("Firing rate histogram image path: ", file_name, '.png'));
    %% 
    % figure out per-layer firing rates
    % array of neuron id boundaries per group
    group_arr = Results.params.TissueParams.groupBoundaryIDArr;
    total_fires_by_group = zeros(length(group_arr) - 1, 1);
    num_neurons_by_group = zeros(length(group_arr) - 1, 1);
    for i = 1:length(group_arr) - 1
        low_idx = group_arr(i) + 1;
        high_idx = group_arr(i + 1);
        group_fires_by_neuron = total_fires_by_neuron(low_idx:high_idx) / time * 1000;
        
        figure
        [~,edges] = histcounts(log10(group_fires_by_neuron));
        histogram(group_fires_by_neuron, 10.^edges)
        set(gca, 'xscale','log')
        
        total_fires_by_group(i) = sum(group_fires_by_neuron);
        num_neurons_by_group(i) = high_idx + 1 - low_idx;
    end