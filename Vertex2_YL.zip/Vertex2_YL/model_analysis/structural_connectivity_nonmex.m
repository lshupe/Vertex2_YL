function connectivity = structural_connectivity(saveDir, synapses_file_prefix, weights_file_prefix, synapse_type)
% connectivity = structural_connectivity(saveDir, synapses_file_prefix, weights_file_prefix [, synapse_type])
%   saveDir: directory containing Vertex-2 results ('./vertex_results')
%   synapses_file_prefix: For example 'synapses_'
%   weights_file_prefix: For example 'weights1_'
%   synapse_type: Optional, 'e' for excitatory, 'i' for inhibitory,
%       otherwise 'all' for all synapses is the default.
%
% Returns connectivity_matrix(toLFPm, fromLFPn) with values of relative
% connectivity strength from one LFP recording site to another.
%
% Examples:
% con1 = structural_connectivity('./vertex_results', 'synapses_', 'weights1_');
% con2 = structural_connectivity('./vertex_results', 'synapses_', 'weights2_', 'e'); % Only excitatory connections
%
% Calculates structural connectivity between all the LFP recording sites.
% For each LPF recording site pair (toLFPm,fromLFPn),
% with Units Ui, Weights Wij from Ui to Uj, and 
% dist(k,i) = distance between Ui soma_xyz and LFPk electrode_xyz:
% connectivity(m,n) = sum_i(sum_j((Wij * (1/dist(n,i)) * (1/dist(m,j)))
%
% Note that there may be more than one Wij if Ui and Uj have multiple
% connections between them.  These will be counted as individual weights.

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

if ~exist('synapse_type', 'var') ||  isempty(synapse_type)
    synapse_type = 'all';
else
    synapse_type = lower(synapse_type);
    if (synapse_type(1) ~= 'e') && (synapse_type(1) ~= 'i')
        synapse_type = 'all';
    end
end

%%
% Get simulation parameters.
% Order of cells in parameterCell:  TissueParams, NeuronParams, 
% ConnectionParams, RecordingSettings, SimulationSettings

tic;
disp('Loading parameters...');
params = load([saveDir 'parameters.mat']);
pFields = fields(params);
TP = params.(pFields{1}){1};
% NP = params.(pFields{1}){2};
% CP = params.(pFields{1}){3};
RS = params.(pFields{1}){4};
% SS = params.(pFields{1}){5};

%%
% Get synapse and weight arrays
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(saveDir, synapses_file_prefix);
disp('Loading weights1 array...');
weights_arr = loadResultsWeightFile(saveDir, weights_file_prefix);
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);

%%
% Calculate which units belong to which groups, and which units should be
% used in the connectivity calculation.
excite_group = [1 4 5 6 9 10 13 14];
inhib_group = [2 3 7 8 11 12 15];
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
unit_docalc = zeros(1, nUnits); % 1 if unit should be calculated in connectivity
st = synapse_type(1);
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
    if (st == 'a') || ((st == 'i') && ismember(iGroup, inhib_group)) || ((st == 'e') && ismember(iGroup, excite_group))
        unit_docalc(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = 1;
    end
end

%%
% Unit and LFP electrode positions:
soma_xyz = TP.somaPositionMat(:,1:3)';
lfp_xyz = [RS.meaXpositions; RS.meaYpositions; RS.meaZpositions]; 

%%
% Calculate inverse of distances = 1/distance(Ui, LFPk)
nLFP = length(RS.meaXpositions);
idist = zeros(nLFP, nUnits);
for i=1:nUnits
    idist(:,i) = 1./vecnorm(lfp_xyz - soma_xyz(:,i));
end

%%
% Calculate connectivity matrix with a single pass through the
% weights array. (TODO? This could be made parallel by separating the
% calculation for sets of units and their respective synapses and weights
% between workers, but would require 32Gb RAM for full density models)
connectivity = zeros(nLFP, nLFP);
for i = 1:nUnits % Pre-synaptic unit index
    if unit_docalc(i)
        postIDs = syn_arr{i,1}; % Post-synaptic unit indexes
        Wi = weights_arr{i};    % Weights from Ui to post-synaptic units
        idistUi = idist(:, i)';
        for j = 1:length(postIDs)
            connectivity = connectivity + (Wi(j) .* idist(:, postIDs(j))) * idistUi;
        end
        
        if toc > 10 % Give user an update every 10 seconds
            tic;
            disp_with_time(['calculating ground truth (' synapse_type '): ', num2str(floor(100 * i / nUnits)) '%']);
        end  
    end
end

%%
% Figure for connectivity matrix
hfig = figure;
connx = connectivity;
connx(:, end+1) = connx(:, end); % extra row and col for pcolor()
connx(end+1, :) = connx(end, :);
pcolor(connx);
colorbar;
axis ij;
axis square;
title(['Structural Connectivity (' synapse_type ') ' weights_file_prefix(weights_file_prefix~='_')]);
ylabel('To LFP Electrode');
xlabel('From LFP Electrode');

%%
% Save figure and connectivity matrix to results folder.
filename = ['StructuralConnectivity_' synapse_type '_' weights_file_prefix];
save_figure(saveDir, filename, hfig);
ground_truth_matrix = connectivity;
pathname = [saveDir filename];
save(pathname, 'ground_truth_matrix', '-v7.3');
disp_with_time(['Saved ground_truth_matrix in: ' pathname '.mat']);
