function [unit2nsite2, unit2group, unit2Hz] = find_units(saveDir, synapses_file_prefix)
% [unit2nsite2, unit2group, unit2Hz] = find_units(saveDir, synapses_file_prefix)
%   saveDir: directory containing Vertex-2 results ('./vertex_results')
%   synapses_file_prefix: For example 'synapses_'
% [unit2nsite2, unit2group, unit2Hz] = find_Units('./vertex_results', 'synapses_');
%
% finds units with connections between two stimulation sites:
% unit2nsite2 converts a unit index to the number of connections from this
%   unit to Site2.
% unit2group converts a nunit index to it's neuron group index.
% unit2Hz is the number of spikes/second elicited by each unit.

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

%% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

disp('Loading parameters...');
Results = loadResults(saveDir);
TP = Results.params.TissueParams; % Get Tissue parameters.

% Get synapse and weight arrays
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(saveDir, synapses_file_prefix);
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);

%%
% Calculate which units belong to which groups
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

%%
% Find somas in a cylinder around Site 1 and Site 2.
nearness = 100; % Micron radius around site
if isfield(TP, 'stim_electrode_xpos')
    x_elect1 = mean(TP.stim_electrode_xpos(1,1:2));
    y_elect1 = mean(TP.stim_electrode_ypos(1,1:2));
    z_elect1 = mean(TP.stim_electrode_zpos(1,1:2));
    ztop1 = max(TP.stim_electrode_zpos(1,:) + TP.stim_electrode_tip_length(1,:)) + nearness;
    zbot1 = min(TP.stim_electrode_zpos(1,:)) - nearness;
    
    x_elect2 = mean(TP.stim_electrode_xpos(2,1:2));
    y_elect2 = mean(TP.stim_electrode_ypos(2,1:2));
    z_elect2 = mean(TP.stim_electrode_zpos(2,1:2));    
    ztop2 = max(TP.stim_electrode_zpos(2,:) + TP.stim_electrode_tip_length(2,:)) + nearness;
    zbot2 = min(TP.stim_electrode_zpos(2,:)) - nearness;
elseif isfield(TP, 'opto_source_xpos')
    x_elect1 = mean(TP.opto_source_xpos(1));
    y_elect1 = mean(TP.opto_source_ypos(1));
    z_elect1 = mean(TP.opto_source_zpos(1));
    ztop1 = TP.opto_source_zpos(1);
    zbot1 = min(TP.opto_source_zpos(1) - 500, TP.layerBoundaryArr(3));
    
    x_elect2 = mean(TP.opto_source_xpos(2));
    y_elect2 = mean(TP.opto_source_ypos(2));
    z_elect2 = mean(TP.opto_source_zpos(2));    
    ztop2 = TP.opto_source_zpos(2);
    zbot2 = min(TP.opto_source_zpos(2) - 500, TP.layerBoundaryArr(3));    
else
    x_elect1 = TP.X / 3;
    y_elect1 = TP.Y / 2;
    z_elect1 = TP.Z;
    ztop1 = TP.layerBoundaryArr(2);
    zbot1 = TP.layerBoundaryArr(3);
    
    x_elect2 = 2 * TP.X / 3;
    y_elect2 = TP.Y / 2;
    z_elect2 = TP.Z;    
    ztop2 = TP.layerBoundaryArr(2);
    zbot2 = TP.layerBoundaryArr(3);      
end

% Using Layer 2/3 slice for everything to normalize the test area
% between field and optical stimulation.
ztop1 = TP.layerBoundaryArr(2); % Use units in Layer2/3
zbot1 = TP.layerBoundaryArr(3);    
ztop2 = ztop1;
zbot2 = zbot1;

x_somas = TP.somaPositionMat(:, 1);
y_somas = TP.somaPositionMat(:, 2);
z_somas = TP.somaPositionMat(:, 3);

% units near Site1
is_elect1 = (z_somas < ztop1) & (z_somas > zbot1) & ...
    (sqrt((x_somas - x_elect1).^2 + (y_somas - y_elect1).^2) < nearness);

% untis near Site2
is_elect2 = (z_somas < ztop2) & (z_somas > zbot2) & ...
    (sqrt((x_somas - x_elect2).^2 + (y_somas - y_elect2).^2) < nearness);

%%
% Count number of weights involving Site1/2
nWeights = 0;    
nSite = 0; % Number of weights that connect with Site1 or Site2
for pre_unit = 1:nUnits
    postIDs = syn_arr{pre_unit,1};
    nWeights = nWeights + length(postIDs);
    if is_elect1(pre_unit) || is_elect2(pre_unit)
        nSite = nSite + length(postIDs);
    else      
        nSite = nSite + sum(is_elect1(postIDs) | is_elect2(postIDs));
    end
end
disp(['Total number of wconnections involving Site1 and/or Site2: ' num2str(nSite)]);

%%
% Sum weight changes between groups and build a distribution of weight changes
% Here we only look at weights that change.
pyramidal_groups = [1 6 9 10 13 14];
excitatory_groups = [1 4 5 6 9 10 13 14];
inhibitory_groups = [2 3 7 8 11 12 15];
do_postgroup = zeros(1,15);  % Which neuron groups to count connections.
do_postgroup(pyramidal_groups) = 1; % only do pyramidal groups for now.
unit2nsite2 = zeros(1, nUnits);
for pre_unit = 1:nUnits
    postIDs = syn_arr{pre_unit,1};
    postGroups = unit2group(postIDs);
    nPost = length(postIDs);
    for iPost = 1:nPost
        post_group = postGroups(iPost);
        if do_postgroup(post_group)
            post_unit = postIDs(iPost);
            if is_elect2(post_unit)
                unit2nsite2(pre_unit) = unit2nsite2(pre_unit) + 1;
            end
        end
    end % for iPost
end % for pre_unit

% count number of spikes from each unit

unit2Hz = zeros(1, nUnits);
spike_time_ms = Results.spikes(:,2);
spike_unit_id = floor(Results.spikes(:,1));
nspikes = length(spike_unit_id);
for ispike = 1:nspikes
    unit_id = spike_unit_id(ispike);
    unit2Hz(unit_id) = unit2Hz(unit_id) + 1;
end

sampleRate = Results.params.RecordingSettings.sampleRate;
simulationTime = Results.params.SimulationSettings.simulationTime;
timeStep = Results.params.SimulationSettings.timeStep;
unit2Hz = unit2Hz * 1000 / simulationTime;

% Print top units in Site1 that are connected with units in Site2 and
% have reasonable firing rates.

disp('UnitID, GroupID, nPost, Hz')
score = unit2Hz .* unit2nsite2 .* (unit2group == 1);
[topscore, id] = sort(score, 'descend');
for i = 1:50
    unitid = id(i);
    disp([num2str(unitid) ',' num2str(unit2group(unitid)) ',' num2str(unit2nsite2(unitid)) ',' num2str(unit2Hz(unitid))]);
end


