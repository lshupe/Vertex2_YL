function [] = plot_spike_raster_by_group(input_dir, should_save)
    % Load the simulation results
    disp(strcat("Loading results from ", input_dir));
    Results = loadResults(input_dir);    
    rasterParams.colors = {'k','m','k','m','k','m', 'k','m','k','m','k','m', 'k','m','k'};
    rasterParams.groupBoundaryLines = 'c';
    rasterParams.title = 'Spike Raster By Group';
    rasterParams.xlabel = 'Time (ms)';
    rasterParams.ylabel = 'Neuron ID';
    rasterParams.figureID = 1;
    plotSpikeRaster(Results, rasterParams);
    file_name = strcat(input_dir, '/spike_raster_by_group');
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
end