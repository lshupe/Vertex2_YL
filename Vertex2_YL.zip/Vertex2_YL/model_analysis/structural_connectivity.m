function [conn_all conn_ex conn_in] = structural_connectivity(resultsDir, synapses_file_prefix, weights_file_prefix)
% [conn_all conn_ex conn_in] = structural_connectivity(resultsDir, synapses_file_prefix, weights_file_prefix)
% Returns connectivity_matrix(toLFPm, fromLFPn) with values of relative
% connectivity strength from one LFP recording site to another.
%
% conn_all: structural connectivity considering all connections
% conn_ex: for only excitatory connections
% conn_in: for only inhibitory connections
%
% resultsDir: directory containing Vertex-2 results ('./vertex_results')
% synapses_file_prefix: For example 'synapses_'
% weights_file_prefix: For example 'weights1_'
%
% Example:
% [sca1 sce1 sci1] = structural_connectivity('./vertex_results', 'synapses_', 'weights1_');
% [sca2 sce2 sci2] = structural_connectivity('./vertex_results', 'synapses_', 'weights2_');
%
% Calculates structural connectivity between all the LFP recording sites.
% For each LPF recording site pair (toLFPm,fromLFPn),
% with Units Ui, Weights Wij from Ui to Uj, and 
% dist(k,i) = distance between Ui soma_xyz and LFPk electrode_xyz:
% connectivity(m,n) = sum_i(sum_j((Wij * (1/dist(n,i)) * (1/dist(m,j)))
%
% Note that there may be more than one Wij if Ui and Uj have multiple
% connections between them.  These will be counted as individual weights.

if ~strcmpi(resultsDir(end), '/')
    resultsDir = [resultsDir '/'];
end

%%
% Get simulation parameters.
% Order of cells in parameterCell:  TissueParams, NeuronParams, 
% ConnectionParams, RecordingSettings, SimulationSettings

tic;
disp_with_time('Loading parameters...');
params = load([resultsDir 'parameters.mat']);
pFields = fields(params);
TP = params.(pFields{1}){1};
% NP = params.(pFields{1}){2};
% CP = params.(pFields{1}){3};
RS = params.(pFields{1}){4};
% SS = params.(pFields{1}){5};

%%
% Get synapse and weight arrays
disp_with_time('Loading synapse array...');
syn_arr = loadResultsSynapseFile(resultsDir, synapses_file_prefix);
disp_with_time('Loading weights1 array...');
weights_arr = loadResultsWeightFile(resultsDir, weights_file_prefix);
nUnits = length(syn_arr); % Number of units

%%
% Calculate which units belong to an excitatory neuron group.
excitatory_groups = [1 4 5 6 9 10 13 14];
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit_is_excitatory = zeros(1, nUnits); % 1 if unit projects excitatory synapses
nExcitatory = 0;
for iGroup = 1:nGroups
    if ismember(iGroup, excitatory_groups)
        unit_is_excitatory(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = 1;
        nExcitatory = nExcitatory + group_bounds(iGroup+1) - group_bounds(iGroup);
    end
end
disp_with_time([num2str(nUnits) ' Units, ' num2str(nExcitatory) ' Excitatory, ' num2str(nUnits - nExcitatory) ' Inhibitory']);

%%
% Unit and LFP electrode positions
soma_xyz = TP.somaPositionMat(:,1:3)';
lfp_xyz = [RS.meaXpositions; RS.meaYpositions; RS.meaZpositions]; 

%%
% Calculate inverse of distances = 1/distance(Ui, LFPk)
nLFP = length(RS.meaXpositions);
idist = zeros(nLFP, nUnits);
for i=1:nUnits
    idist(:,i) = 1./vecnorm(lfp_xyz - soma_xyz(:,i));
end

%%
% Calculate connectivity matrix with a single pass through the weight list.
conn_all = zeros(nLFP, nLFP);
conn_ex = zeros(nLFP, nLFP);
conn_in = zeros(nLFP, nLFP);
structural_connectivity_helper([], [], idist); % Give helper copy of idist()
for i = 1:nUnits % Pre-synaptic unit index
    conn_Ui = structural_connectivity_helper(uint32(i), uint32(syn_arr{i,1}), weights_arr{i});
    conn_all = conn_all + conn_Ui; 
    if unit_is_excitatory(i)
        conn_ex = conn_ex + conn_Ui; 
    else
        conn_in = conn_in + conn_Ui; 
    end
    if toc > 10 % Give user an update every 10 seconds
        tic;
        disp_with_time(['calculating ground truth: ', num2str(floor(100 * i / nUnits)) '%']);
    end 
end
structural_connectivity_helper([], [], []); % Release helper copy of idist()

%%
% Figures for conn_all, conn_ex, and conn_in

for synapse_type = {'all', 'e', 'i'}
    if synapse_type{1} == 'e'
        ground_truth_matrix = conn_ex;
    elseif synapse_type{1} == 'i'
        ground_truth_matrix = conn_in;
    else
        ground_truth_matrix = conn_all;
    end
    
    hfig = figure;
    connx = ground_truth_matrix;
    connx(:, end+1) = connx(:, end); %#ok<AGROW> % extra row and col for pcolor()
    connx(end+1, :) = connx(end, :); %#ok<AGROW>
    pcolor(connx);
    colorbar;
    axis ij;
    axis square;
    title(['Structural Connectivity (' synapse_type{1} ') ' weights_file_prefix(weights_file_prefix~='_')]);
    ylabel('To LFP Electrode');
    xlabel('From LFP Electrode');
    
    % Save figure and connectivity matrix to results folder.
    filename = ['StructuralConnectivity_' synapse_type{1} '_' weights_file_prefix];
    save_figure(resultsDir, filename, hfig);
    pathname = [resultsDir filename];
    save(pathname, 'ground_truth_matrix', '-v7.3');
    disp_with_time(['Saved ground_truth_matrix: ' pathname '.mat']);
end
