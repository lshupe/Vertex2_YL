function [] = spike_stats(Results, input_dir, should_save)
    %PLOT_LFP_SIGNALS Function that reads the result of a vertex simulation
    % and generates plots for LFP data
    %%
    % Load the simulation results
    num_neurons = Results.params.TissueParams.N;
    neuron_fires = Results.spikes(:, 1);
    time = Results.params.SimulationSettings.simulationTime;
    disp("Average Overall Firing Rate:");
    disp(length(neuron_fires) / num_neurons / time * 1000);
    % calculate firing rate per neuron
    total_fires_by_neuron = zeros(num_neurons, 1);
    
    for i = 1:length(neuron_fires)
        firing_neuron = neuron_fires(i);
        total_fires_by_neuron(firing_neuron) = total_fires_by_neuron(firing_neuron) + 1;
    end
    
    avg_firing_by_neuron = total_fires_by_neuron / time * 1000;
    
    
    [~,edges] = histcounts(log10(avg_firing_by_neuron));
    histogram(avg_firing_by_neuron, 10.^edges)
    set(gca, 'xscale','log')
    file_name = strcat(input_dir, '/firing_rate_hist_log');
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    disp(strcat("Firing rate histogram log scale image path: ", file_name, '.png'));
    
    histogram(avg_firing_by_neuron)
    file_name = strcat(input_dir, '/firing_rate_hist_norm');
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    disp(strcat("Firing rate histogram image path: ", file_name, '.png'));
    %% 
    % figure out per-layer firing rates
    % array of neuron id boundaries per group
    group_arr = Results.params.TissueParams.groupBoundaryIDArr;
    total_fires_by_group = zeros(length(group_arr) - 1, 1);
    num_neurons_by_group = zeros(length(group_arr) - 1, 1);
    for i = 1:length(group_arr) - 1
        low_idx = group_arr(i) + 1;
        high_idx = group_arr(i + 1);
        group_fires_by_neuron = total_fires_by_neuron(low_idx:high_idx);
        total_fires_by_group(i) = sum(group_fires_by_neuron);
        num_neurons_by_group(i) = high_idx + 1 - low_idx;
    end
    avg_firing_rate_by_group = total_fires_by_group ./ num_neurons_by_group / time * 1000;
    disp("Average firing rate by Neuron Group");
    for i = 1:length(avg_firing_rate_by_group)
        disp(strcat("Group ", string(i), ": ", string(avg_firing_rate_by_group(i))));
    end
    disp("\n");
    total_fires_by_layer = zeros(5, 1);
    num_neurons_by_layer = zeros(5, 1);
    for i = 1:length(total_fires_by_group)
        layer = Results.params.NeuronParams(i).somaLayer;
        total_fires_by_layer(layer) = total_fires_by_layer(layer) + total_fires_by_group(i);
        num_neurons_by_layer(layer) = num_neurons_by_layer(layer) + num_neurons_by_group(i);
    end
    
    avg_firing_rate_by_layer = total_fires_by_layer ./ num_neurons_by_layer / time * 1000;
    disp("Average firing rate by layer");
    for i = 2:length(avg_firing_rate_by_layer)
        disp(strcat("Layer ", string(i), ": ", string(avg_firing_rate_by_layer(i))));
    end
end