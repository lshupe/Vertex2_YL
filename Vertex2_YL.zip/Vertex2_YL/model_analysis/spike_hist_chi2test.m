function [chi2stat, p, mpi] = spike_hist_chi2test(Output1, Output2)
% Peformes a Chi2 test comparing the Test/Base proportion between
% Output1 and Output2 as the outputs from spike_hist() taken before and
% after an intervention.
%
% mpi = percent increase in Test_count / (Base_count + Test_count) of
% Output2 over Output1
%
% This can answer the question of if there is a significant increase (over 
% baseline activity) in the peri-time histogram test range after stimulus
% conditioning.  It should account for mean firing rate changes since we
% are comparing the Test/Base proportions
%
% This test depends on the base and test ranges being identical between the
% two calls to spike_hist.  The neuron groups tested should likely be
% the same as well, although it's also possilbe to test for platicity
% effect differences between different neuron groups.
%
% Example: For a simulation that had an intervention between [10000 15000]
% milliseconds and there was peak in the peri-time histogram at [30 40] ms
% for Neuron-group1 -> Neuron-group2:
% >> base_range_ms = [-60 -50];
% >> test_range_ms = [30 40];
% >> [Output1, Results] = spike_hist(1, [], 2, [], [5000 10000], [-100 100], 1, base_range_ms, test_range_ms);
% >> Output2 = spike_hist(1, [], 2, [], [15000 20000], [-100 100], 1, base_range_ms, test_range_ms, Results);
% >> [chi2stat, p, mpi] = spike_hist_chi2test(Output1, Output2);

n1 = Output1.test_spike_count; % Number of observations falling into the test range.
N1 = Output1.base_spike_count + Output1.test_spike_count; % Number of observations for Output1
n2 = Output2.test_spike_count; % Same for Output2
N2 = Output2.base_spike_count + Output2.test_spike_count; % Number of observations for Output2
% Pooled estimate of proportion
p0 = (n1+n2) / (N1+N2);
% Expected counts under H0 (null hypothesis)
n10 = N1 * p0;
n20 = N2 * p0;
% Chi-square matrix
observed = [n1 N1-n1 n2 N2-n2];
expected = [n10 N1-n10 n20 N2-n20];
chi2stat = sum((observed-expected).^2 ./ expected);
p = 1 - chi2cdf(chi2stat,1);

% Mean percent increase over baseline for test range spiking activity
ratio1 = n1 / N1;
ratio2 = n2 / N2;
mpi = 100 * (ratio2 - ratio1) / ratio1;