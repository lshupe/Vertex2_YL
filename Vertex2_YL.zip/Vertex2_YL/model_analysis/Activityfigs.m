function activityfigs(results_directory)
addpath(genpath(pwd));
if nargin >= 1
    directory = results_directory;
else
    directory = './vertex_results';
end
close_flag = false; % Whether of not to close figures once saved.

%% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

Results = loadResults(directory);

%% Plot the results

sampleRate = Results.params.RecordingSettings.sampleRate;
simulationTime = Results.params.SimulationSettings.simulationTime;
timeStep = Results.params.SimulationSettings.timeStep;
markers = '0+*x^vdsp';
colors =  'krgbcm';
if isempty(Results.events)
    stim_times = [];
    stim_ids = [];
else
    index = find([Results.events.marker] ~= '|');
    events = Results.events(index);
    stim_times = [events.time_ms];
    stim_ids = [events.id];
    color_ind = mod(ceil(stim_ids / length(markers)), length(colors)) + 1;
    stim_marker = mod(stim_ids, length(markers)) + 1;
end

disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(directory, 'synapses_');

%%
% Calculate unit firing frequency progression for each unit group.
% This shows how stable firing rates are over the course of the simulation.

% Calculate which units belong to which groups
nUnits = length(syn_arr); % Number of units
group_names = get_group_names();
group_bounds = Results.params.TissueParams.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end


% Calculate density maps by binning units by soma position in a XZ grid.

spike_time_ms = Results.spikes(:,2);
spike_unit_id = floor(Results.spikes(:,1));

bin_size = 25; % microns
x_bins = (0:bin_size:Results.params.TissueParams.X);
y_bins = (0:bin_size:Results.params.TissueParams.Y);
z_bins = (0:bin_size:Results.params.TissueParams.Z);
x_somas = Results.params.TissueParams.somaPositionMat(:, 1);
y_somas = Results.params.TissueParams.somaPositionMat(:, 2);
z_somas = Results.params.TissueParams.somaPositionMat(:, 3);
ix = floor(x_somas / bin_size) + 1;
iy = floor(y_somas / bin_size) + 1;
iz = floor(z_somas / bin_size) + 1;

%%
% Activity plot for spikes occurring just after a stimulus.
% Count how many spikes occur for units in each bin.

stim_ms = [];
if ~isempty(stim_times)
    stim_ms = stim_times(stim_ids == 1);
elseif isfield(Results.params.TissueParams, 'stim_ms')
    stim_ms = Results.params.TissueParams.stim_ms;
end
if length(stim_ms) < 1
    return;
end

coincidence_start_ms = -2;
coincidence_end_ms = 8;
coincidence_ms = 2;  % Count spikes occuring in this time after a stimulus is delivered.

maxz1 = 0;
maxz2 = 0;
nfig = 0;
for start_ms = coincidence_start_ms:coincidence_ms:coincidence_end_ms
    act = zeros(length(z_bins), length(x_bins));
    actxy = zeros(length(y_bins), length(x_bins));
    x_elect = [];
    y_elect = [];
    z_elect = [];

    for stim_time = stim_ms % Run through list of spikes
        % count spikes within window near stimuli
        deltat_ms = spike_time_ms - stim_time;
        index = spike_unit_id((deltat_ms >= start_ms) & (deltat_ms < start_ms + coincidence_ms))';  % matching stimuli
        for id = index
            act(iz(id), ix(id)) = act(iz(id), ix(id)) + 1;
            actxy(iy(id), ix(id)) = actxy(iy(id), ix(id)) + 1;
        end
    end
    maxz1 = max(maxz1, max(max(act)));
    maxz2 = max(maxz2, max(max(actxy)));

    % Plot XZ projection of where spikes were correlated with stimulation
    nfig = nfig + 1;
    hfig(nfig) = figure;
    h = pcolor(act);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', 0:20:length(z_bins));
    set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            z_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_zpos(ielec,1:2));
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            z_elect(ielec) = Results.params.TissueParams.opto_source_zpos(ielec);
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike Coincidence within [' num2str(start_ms) ', ' num2str(start_ms+coincidence_ms) ') ms window']);
    xlabel('X');
    ylabel('Depth');

    % Plot XY projection of where spikes were correlated with stimulation
    nfig = nfig + 1;
    hfig(nfig) = figure;
    h = pcolor(actxy);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', 0:20:length(y_bins));
    set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            y_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_ypos(ielec,1:2));
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            y_elect(ielec) = Results.params.TissueParams.opto_source_ypos(ielec);
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike Coincidence within [' num2str(start_ms) ', ' num2str(start_ms+coincidence_ms) ') ms window']);
    xlabel('X');
    ylabel('Y');
end

% Set a common scale for all figures and save them.
nfig = 0;
for start_ms = coincidence_start_ms:coincidence_ms:coincidence_end_ms
    nfig = nfig + 1;
    %zlim(hfig(nfig), [0 maxz1]);
    save_figure(directory, ['Stim2Spike_coincidence_xz_' num2str(start_ms)], hfig(nfig), close_flag);
    nfig = nfig + 1;
    %zlim(hfig(nfig), [0 maxz2]);
    save_figure(directory, ['Stim2Spike_coincidence_xy_' num2str(start_ms)], hfig(nfig), close_flag);
end


