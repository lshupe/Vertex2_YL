function [] = spike_raster(input_dir, dosave)
    if nargin < 2
        dosave = 0;
    end

    % Load the simulation results
    disp(strcat("Loading results from ", input_dir));
    Results = loadResults(input_dir);    
    TP = Results.params.TissueParams;

    % Select which unit groups to plot
    plot_groups = 'all'; % one of 'all', 'excitatory', 'inhibitory'

    % Select units with an XY distance to fiber center < nearness
    pars.nearness = 200;

    % Select groups to plot
    if strcmp(plot_groups, 'excitatory')
        pars.groups = [1 4 5 6 9 10 13 14];   % Excitatory group indices
    elseif strcmp(plot_groups, 'inhibitory')
        pars.groups = [2 3 7 8 11 12 15];
    else
        plot_groups = 'all';
        pars.groups = 1:15;
    end
    % group colors
    pars.colors = {'k','m','m','k','k','k', 'm','m','k','k','m','m', 'k','k','m'};

    pars.groupBoundaryLines = 'c';
    pars.title = ['Spike times for ' plot_groups ' units within ' num2str(pars.nearness) ' um of stimulus centerline'];
    pars.xlabel = 'Time (ms)';
    pars.ylabel = 'Depth (um)';
    pars.FontSize = 12;
    pars.tmin = 1500;
    pars.tmax = 3400;
    pars.markerSize = 2;
    nUnits = TP.N;
    pars.neuronsToPlot = 1:nUnits;
    
    group_bounds = TP.groupBoundaryIDArr;
    nGroups = length(group_bounds) - 1;
    neuronInGroup = createGroupsFromBoundaries(TP.groupBoundaryIDArr);

    ielect = 1;
    if isfield(TP, 'stim_electrode_xpos')
        x_elect = mean(TP.stim_electrode_xpos(ielect,1:2));
        y_elect = mean(TP.stim_electrode_ypos(ielect,1:2));
        z_elect = mean(TP.stim_electrode_zpos(ielect,1:2));
        delay = TP.stim_delay_ms(ielect);
    elseif isfield(TP, 'opto_source_xpos')
        x_elect = mean(TP.opto_source_xpos(ielect));
        y_elect = mean(TP.opto_source_ypos(ielect));
        z_elect = mean(TP.opto_source_zpos(ielect));
        delay = TP.opto_train_delay_ms(ielect);
    end
    x_somas = TP.somaPositionMat(:, 1);
    y_somas = TP.somaPositionMat(:, 2);
    z_somas = TP.somaPositionMat(:, 3);

    % Select units near stimulus center line
    is_near = (sqrt((x_somas - x_elect).^2 + (y_somas - y_elect).^2) <= pars.nearness);
    pars.neuronsToPlot = pars.neuronsToPlot(is_near);

    % Select spikes within given time range
    is_time = (Results.spikes(:,2) >= pars.tmin) & (Results.spikes(:,2) < pars.tmax);
    spike_time_ms = Results.spikes(is_time,2);
    spike_unit_id = floor(Results.spikes(is_time,1));
    spike_unit_depth = 2600 - z_somas(spike_unit_id);

    hfig = figure;
    hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 800 800];

    hold on;
    for iGroup = 1:TP.numGroups
        if ismember(iGroup, pars.groups)
            toPlot = ismember(spike_unit_id, pars.neuronsToPlot) & ...
                neuronInGroup(spike_unit_id)==iGroup;
            plot(spike_time_ms(toPlot), spike_unit_depth(toPlot), ...
                '.', 'Color', pars.colors{iGroup}, 'MarkerSize', ...
                pars.markerSize);
        end
    end

    layer_depth = TP.layerBoundaryArr(1) - TP.layerBoundaryArr;
    layer_names = {' L1', ' L2/3', ' L4', ' L5', ' L6'};
    for iLayer = 2:length(layer_names)
        y = layer_depth(iLayer);
        line([pars.tmin, pars.tmax], [y, y], 'Color', 'k');
        y = 0.5 * (layer_depth(iLayer) + layer_depth(iLayer + 1));
        text(pars.tmax, y, layer_names{iLayer});
    end
    hold off;

    axis([pars.tmin pars.tmax 300 2600]);

    set(gcf,'color','w');
    set(gca,'YDir','reverse');
    set(gca,'TickDir','out');

    if isfield(pars, 'FontSize')
        fsize = pars.FontSize;
    else
        fsize = 16;
    end

    if isfield(pars, 'title')
        title(pars.title, 'FontSize', fsize);
    end
    if isfield(pars, 'xlabel')
        xlabel(pars.xlabel, 'FontSize', fsize);
    end
    if isfield(pars, 'ylabel')
        ylabel(pars.ylabel, 'FontSize', fsize);
    end

    set(gca, 'FontSize', fsize);

    file_name = strcat(input_dir, ['/spike_raster_by_depth_' plot_groups '_nearness_' num2str(pars.nearness)]);
    if dosave
        savefig(strcat(file_name, '.fig'));
        saveas(gcf, strcat(file_name, '.png'));
        saveas(gcf, strcat(file_name, '.pdf'));
    end
end