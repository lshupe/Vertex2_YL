function [Output, Results] = spike_hist(source_neuron_groups, source_area, ...
    target_neuron_groups, target_area, time_window_ms, x_limits_ms, ...
    bin_width_ms, base_range_ms, test_range_ms, Results)
% Create a Peri-time histogram for spikes in the source-groups to spikes
% in the target-groups. Times are in milliseconds.  Ranges relative to 
% source spike times.  Spikes are selected so that no spike is included
% more than once in the analysis.  This means that each Source unit is
% paired with a randomly selected unique Target unit.
%
% Performs a Chi2 test between spike counts in base range
% compared to spike counts in the test range.  This requires that the
% base and test ranges have the same duration.
%
% source_neuron_groups -- list of neuron groups to use for source spikes.
% source_area -- [x, y, z, radius] (microns) sphere surrounding source area. [] to use all neurons.
% target_neuron_groups -- list of target groups to use for target spikes.
% target_area -- [x, y, z, radius] (microns) sphere surrounding source area. [] to use all neurons.
% time_window_ms -- The time window to use for analysis.  Empty to use the full all time.
% x_limits_ms -- The peri-time range around source spike times.
% bin_width_ms -- Bin width to use for the peri-time histogram.
% base_range_ms -- Define base-line range for analysis.
% test_range_ms -- Define test range for analysis.  Duration must be same as for base_range_ms for Chi2 test.
% Results -- returned by loadResults, if empty they will be reloaded here.
%
% Output.xaxis -- (in ms) Used to plot rawCounts, MeanTargetUnitFiringRate.
% Output.meanTargetUnitFiringRate --  rawCounts converted to spikes per second.
% Output.n_trials -- Number of source spikes used from the source unit pool
% Output.n_target_spikes -- Number of potential target spikes, not all of which may show up in the histogram.
% Output.base_range -- Saved base_range_ms
% Output.test_range -- Saved test_range_ms
% Output.base_index -- Array indices of bins in the base range.
% Output.test_index -- Array indices of bins in the test range.
% Output.base_spike_count -- Number of target spikes in the base range
% Output.test_spike_count -- Number of target spikes in the test range.
% Output.p_chi2 -- Chi2 test p-value (when base and test range have same duration)
% Output.error -- Error string if an error occurred.
%
% Examples:
% >> [Output, Results] = spike_hist(1, [], 1, [], [0 10000], [-100 100], 1, [-60 -50], [30 40]);
% >> Output = spike_hist(1, [], 1, [], [0 10000], [-100 100], 1, [-60 -50], [50 60], Results);

directory = './vertex_results';
close_flag = false; % Whether of not to close figures once saved.

Output.xaxis = [0 0];
Output.rawCounts = [0 0];
Output.meanTargetUnitFiringRate = [0 0];
Output.base_range = [0 0];
Output.base_index = [];
Output.test_range = [0 0];
Output.test_index = [];
Output.base_spike_count = 0;
Output.test_spike_count = 0;
Output.p_chi2 = 0;
Output.error = '';

% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

if (nargin <= 9) || isempty(Results)
    Results = loadResults(directory);
end

% Calculate which units belong to which neuron groups, and which units
% are potential spike sources and targets.

TP = Results.params.TissueParams;
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
nUnits = length(TP.somaPositionMat(:, 1));
unit2group = zeros(1, nUnits, 'int8'); % Converts unit index to group index
is_source_unit = zeros(1, nUnits, 'int8'); % 1 iff a unit is a source unit
is_target_unit = zeros(1, nUnits, 'int8'); % 1 iff a unit is a target unit
for iGroup = 1:nGroups
    group_range = group_bounds(iGroup)+1:group_bounds(iGroup+1);
    unit2group(group_range) = iGroup;
    if ismember(iGroup, source_neuron_groups)
        is_source_unit(group_range) = 1;
    end
    if ismember(iGroup, target_neuron_groups)
        is_target_unit(group_range) = 1;
    end
end

% Get spikes within time window, sort by ascending spike time.

if length(time_window_ms) < 2
    time_window_ms = [0 inf];
end
spike_time_ms = Results.spikes(:,2);
index = find((spike_time_ms > time_window_ms(1)) & (spike_time_ms < time_window_ms(2)));
spike_time_ms = spike_time_ms(index);
spike_unit_id = floor(Results.spikes(index,1));
[spike_time_ms, index] = sort(spike_time_ms);
spike_unit_id = spike_unit_id(index);

% Limit spikes to source and target areas

if (length(source_area) < 4) ||  (length(target_area) < 4)
    xpos = TP.somaPositionMat(:, 1);
    ypos = TP.somaPositionMat(:, 2);
    zpos = TP.somaPositionMat(:, 3);
end

is_unit_in_source_area = ones(1, nUnits, 'int8');
if length(source_area) >= 4
    source_distances = sqrt((xpos - source_area(1)).^2 + (ypos - source_area(2)).^2 + (zpos - source_area(3)).^2);
    is_unit_in_source_area = (source_distances <= source_area(4));
end

is_unit_in_target_area = ones(1, nUnits, 'int8');
if length(target_area) >= 4
    target_distances = sqrt((xpos - source_area(1)).^2 + (ypos - source_area(2)).^2 + (zpos - source_area(3)).^2);
    is_unit_in_target_area = (target_distances <= target_area(4));
end

%%
% Pair source units with a target unit randomly to reduce selection bias
% and prevent using a spike more than once in the resulting histogram.

source_units = find(is_unit_in_source_area & is_source_unit);
target_units = find(is_unit_in_target_area & is_target_unit);
n_pairs = min(length(source_units), length(target_units));
if n_pairs < 2
    disp('Error, not enough source or target units found.')
    return; % Require at least 2 source-target pairs to continue
end
n_source_units = length(source_units);
n_target_units = length(target_units);
source_units = source_units(randperm(n_source_units, n_pairs));
target_units = target_units(randperm(n_target_units, n_pairs));

% Prevent self pairing
is_self_paired = (source_units == target_units);
while any(is_self_paired)
    for i = find(is_self_paired)
        % Swap self-paired target unit with another random target unit
        j = randperm(n_pairs, 1);
        temp = target_units(i);
        target_units(i) = target_units(j);
        target_units(j) = temp;     
    end
    is_self_paired = (source_units == target_units);
end

% Final source-target pairing
target_for_source_unit = zeros(1, nUnits);
target_for_source_unit(source_units) = target_units;

%%
% Get source and target spike-times

is_source_unit = zeros(1, nUnits, 'int8'); % Flag for actual source units
is_source_unit(source_units) = 1; % 1 iff a unit is a source unit

is_target_unit = zeros(1, nUnits, 'int8'); % Flag for actual target units
is_target_unit(target_units) = 1; % 1 iff a unit is a target unit

index = is_source_unit(spike_unit_id);
source_time_ms = spike_time_ms(index > 0);
source_unit_id = spike_unit_id(index > 0);
n_source_spikes = length(source_unit_id);

index = is_target_unit(spike_unit_id);
target_time_ms = spike_time_ms(index > 0);
target_unit_id = spike_unit_id(index > 0);
n_target_spikes = length(target_unit_id);

%%
% Make histogram

% Calculate histogram bin edges and base/test time ranges
bin_edges = x_limits_ms(1):bin_width_ms:x_limits_ms(2);
base_index = find((bin_edges >= base_range_ms(1)) & (bin_edges < base_range_ms(2)));
test_index = find((bin_edges >= test_range_ms(1)) & (bin_edges < test_range_ms(2)));
base1 = bin_edges(base_index(1));
base2 = bin_edges(base_index(end)+1);
test1 = bin_edges(test_index(1));
test2 = bin_edges(test_index(end)+1);
 
ycounts = zeros(size(bin_edges));
target_start_index = 1;
base_counts = zeros(1, n_source_spikes);
test_counts = zeros(1, n_source_spikes);
for source_index = 1:n_source_spikes
    source_id = source_unit_id(source_index);
    target_id = target_for_source_unit(source_id);
    if target_id % If source unit is paired with a target unit
        source_time = source_time_ms(source_index);
        % find first target time inside of the xaxis for this source spike.
        while (target_start_index <= n_target_spikes) && (target_time_ms(target_start_index) < source_time + bin_edges(1))
            target_start_index = target_start_index + 1;
        end

        % Add a count for each target time inside xaxis
        for target_index = target_start_index:n_target_spikes
            peri_time = target_time_ms(target_index) - source_time;
            if peri_time >= bin_edges(end)
                break;
            end
            if target_id == target_unit_id(target_index)
                bin = floor( (peri_time - bin_edges(1)) / bin_width_ms ) + 1;
                ycounts(bin) = ycounts(bin) + 1;
                if (peri_time >= base1) && (peri_time < base2)
                    base_counts(source_index) = base_counts(source_index) + 1;
                end
                if (peri_time >= test1) && (peri_time < test2)
                    test_counts(source_index) = test_counts(source_index) + 1;
                end
            end
        end
    else
        disp('Error, Source-Target mismatch: There is a bug in the code');
        return;
    end
end

%%%
% save output values

Output.n_trials = n_source_spikes;
Output.n_target_spikes = n_target_spikes;
Output.xaxis = bin_edges(1:end-1);
Output.rawCounts = ycounts(1:end-1);
Output.meanTargetUnitFiringRate = (ycounts(1:end-1) / Output.n_trials) / (0.001 * bin_width_ms);

Output.time_window_ms = time_window_ms;
Output.base_range_ms = base_range_ms;
Output.test_range_ms = test_range_ms;
Output.base_index = find((Output.xaxis >= base_range_ms(1)) & (Output.xaxis < base_range_ms(2)));
Output.test_index = find((Output.xaxis >= test_range_ms(1)) & (Output.xaxis < test_range_ms(2)));
Output.base_spike_count = sum(Output.rawCounts(Output.base_index));
Output.test_spike_count = sum(Output.rawCounts(Output.test_index));

% %%
% % Ranksum test may not be appropriate but seems to give comparable
% % results to the Chi2 test.
% if length(Output.base_index) == length(Output.test_index)
%     % Base and Test range need to have same duration for ranksum test
%     Output.p_ranksum = ranksum(base_counts > 0, test_counts > 0); 
% else
%     Output.p_ranksum = NaN;
%     Output.error = 'Ranksum test requires Base and Test ranges with same duration';
% end

%%
% Chi squared test. This test assumes that the bins are small enough that
% we can only have 1 spike per unit per sweep per bin.   
% At the large number of spikes produced by the simulation, this may become
% very sensitive and may not yield useful results.
if length(Output.base_index) == length(Output.test_index)
    n1 = sum(base_counts > 0); % Number of trials with at least one spike in the base range
    N1 = Output.n_trials; % Number of observations for base range
    n2 = sum(test_counts > 0); % Number of trials with at least one spike in the test range
    N2 = Output.n_trials; % Number of observations for test range
    % Pooled estimate of proportion
    p0 = (n1+n2) / (N1+N2);
    % Expected counts under H0 (null hypothesis)
    n10 = N1 * p0;
    n20 = N2 * p0;
    % Chi-square matrix
    observed = [n1 N1-n1 n2 N2-n2];
    expected = [n10 N1-n10 n20 N2-n20];
    chi2stat = sum((observed-expected).^2 ./ expected);
    Output.p_chi2 = 1 - chi2cdf(chi2stat,1);
else
    Output.p_chi2 = NaN;
    Output.error = 'Chi2 test requires Base and Test ranges with same duration';
end


%%
% plot results

hfig = figure;
histogram('BinEdges', bin_edges, 'BinCounts', Output.meanTargetUnitFiringRate);
hold on;
basevals = zeros(size(Output.meanTargetUnitFiringRate));
basevals(Output.base_index) = Output.meanTargetUnitFiringRate(Output.base_index);
histogram('BinEdges', bin_edges, 'BinCounts', basevals);
testvals = zeros(size(Output.meanTargetUnitFiringRate));
testvals(Output.test_index) = Output.meanTargetUnitFiringRate(Output.test_index);
histogram('BinEdges', bin_edges, 'BinCounts', testvals);
xlim([bin_edges(1) bin_edges(end)]);
title(['PTH G(' num2str(source_neuron_groups) ') to G(' num2str(target_neuron_groups) ...
    '), Trials  ' num2str(Output.n_trials) ', Chi2 p = ' num2str(Output.p_chi2)]);
xlabel('ms');
ylabel('spikes/second');
fname = ['PTH All G(' num2str(source_neuron_groups) ') to G(' num2str(target_neuron_groups) '), time(' num2str(time_window_ms) ')'];
save_figure(directory, fname, hfig, close_flag);

