// Matlab mex file to perform the inner matrix multiply and acculumlate
// loop for structural_connectivity_mex.m
//
// structural_connectivity_helper([], [], idist)
//   Sets the idist(LFPk, Ui) matrix.  This is a nLFP x nUnits matrix of
//   inverse distances between somas and LFP electrodes.  This must be done
//   before calling with regular Unit indexes.
//
// partial_connectivity_Ui = structural_connectivity_helper(Ui, Uj, Wi)
//   Returns partial connectivity matrix for unit Ui (uint32 value)
//   Wi and Uj are row vectors of the same length.
//   Uj is the list of post-synaptic units from Ui. (uint32 array)
//   Wi is the associated list of post-synaptic weights from Ui to Uj[..]
//
// structural_connectivity_helper([], [], [])
//   Deallocates any reserved memory.  Must be called after normal calls
//   are completed.
//
// Note that Wij is the weight from unit Ui to unit Uj, all Ui and Uj > 0.
//
// The full structurallconnectivity is:
// connectivity(m,n) = sum_i(sum_j((Wij * (1/dist(n,i)) * (1/dist(m,j))))
//
// This routine calculates the partial connectivity for just unit Ui
// pconnectivity(i,m,n) = sum_j((Wij * (1/dist(n,i)) * (1/dist(m,j)))
//
// The caller must sum the partial matrices together to calculate the
// full connectivity.

#include <windows.h>
#include "mex.h"
#include "matrix.h"
#include "math.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include <stdio.h>
#include <string.h>

/* Input Arguments */
/* UI is pre-synaptic unit index */
/* UJ is 0 or a row vector of post-synaptic unit indexes */
/* WI is a a list of matching post-synaptic weights */
/* if UJ is [0], then WI is the IDIST matrix */

#define	UI_ARG	prhs[0]
#define	UJ_ARG	prhs[1]
#define WI_ARG  prhs[2]

/* Output Arguments */
/* PCONN is the Partial connectivity matrix for unit Ui */
#define	PCONN 	plhs[0]

static mxArray *IDIST = NULL; // inverse distance matrix idist[LFPk][Ui]
static double *idist = NULL;  // pointer to actual values

// Release memory used by the IDIST array.  This is called as an
// exit function which gets run when the MEX-file is cleared or when
// MATLAB exits.
static void release_idist_array(void)
{
    if (IDIST)
    {
        mxDestroyArray(IDIST);
        IDIST = NULL;
        idist = NULL;
        mexPrintf("structural_connectivity_helper: released inverse distance array\n");                    
    }
}

// Main entry point
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])    
{ 
    static unsigned int nLFP = 0;      // Number of LFP electrodes
    static unsigned int nUnits = 0;    // Number of Units
    
    double *pconn;       // Return values array
    double *Wi;          // Pointer to weight list for unit Ui
    unsigned int *Ui;    // Pointer to current unit index Ui
    unsigned int *Uj;    // List of units post-synaptic to unit Ui
    unsigned int nUj;    // Number of values in Uj array

    // Check for correct number of input arguments.
    if (nrhs < 3)
    {
		mexErrMsgTxt("Reserve inverse distance matrix: structural_connectivity_helper([], [], inverse_distance(nLFP, nUnits)"); 
		mexErrMsgTxt("Calculate for unit Ui: connectivity_Ui = structural_connectivity_helper(Ui, Ujs, Wis)"); 
		mexErrMsgTxt("Release inverse distance matrix: structural_connectivity_helper([], [], [])"); 
        return;
    }

    // Get parameters
    Ui = mxGetPr(UI_ARG);
    Uj = mxGetPr(UJ_ARG); 
    nUj = (unsigned int)mxGetN(UJ_ARG);
    Wi = mxGetPr(WI_ARG);  
    
    if (mxGetN(UI_ARG) == 0)
    { // Special case used to initialize or release the idist array.
        nLFP = (unsigned int)mxGetM(WI_ARG);
        nUnits = (unsigned int)mxGetN(WI_ARG);
        release_idist_array(); // Release any previously allocated array.
        if (nLFP * nUnits > 0)
        { // Create IDIST array if not empty
            IDIST = mxCreateDoubleMatrix(nLFP, nUnits, mxREAL); 
            mexMakeArrayPersistent(IDIST); // So Matlab won't move it.
            idist = mxGetPr(IDIST);
            // Register an exit function. so that the IDIST array will be 
	        // destroyed when the mex-file is released or Matlab closes.
	        mexAtExit(release_idist_array);
            for (int k=0; k < nLFP * nUnits; k++)
                idist[k] = Wi[k]; // Make copy of IDIST array sent in the WI parameter.
            mexPrintf("structural_connectivity_helper: reserved memory for inverse distance array\n");                    
        }
        return;
    }

    // Sanity check that caller initialized IDIST
    if (!IDIST)
    {
		mexErrMsgTxt("ERROR not correctly initialized: structural_connectivity_helper(0, idist)"); 
        return;
    }

    // Setup return value
    PCONN = mxCreateDoubleMatrix(nLFP,nLFP,mxREAL);
    pconn = mxGetPr(PCONN);

    // Loop over post-synaptic units j for the current unit i.
    double *idistUi = idist + (Ui[0] - 1) * nLFP; // idist column for current unit
    for (int j=0; j<nUj; j++)
    {
        double Wij = Wi[j];
        double *idistUj = idist + (Uj[j] - 1) * nLFP; // idist column for Uj
        double *p = pconn; // Run through output array columns in order
        for (int n=0; n<nLFP; n++) 
        { // For each output column
            double Wij_x_idistUIn = Wij * idistUi[n];
            for (int m=0; m<nLFP; m++)
            { // For each output row
                *p++ += Wij_x_idistUIn * idistUj[m];
            }
        }
    }
}