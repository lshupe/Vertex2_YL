function psth_layers(results_directory)
% Creates a peri-stimulus time histograms of spikes occuring in a regions
% below stimulus sites.

nearness = 200;         % Micron radius around stimulus site origin
peak_window_ms = [0 250]; % Count spikes occuring in this time window after a stimulus is delivered.
baseline_ms = 10;       % Time before stimulus for measuring baseline activity.
pre_ms = 500;            % Histogram time range
post_ms = 1400;
top_layer_boundary = 2; % 1 surface, 2 = top L2/3, 3 = top L4, 4 = top L5, 5 = top L6, 6 = Bottom of L6
bot_layer_boundary = 6;
layer_names = {'Layer 1', 'Layer 2/3', 'Layer 4', 'Layer 5', 'Layer 6'};
inhibitory_unit_groups = [2 3 7 8 11 12 15];

%%
addpath(genpath(pwd));
if nargin >= 1
    directory = results_directory;
else
    directory = './vertex_results';
end
close_flag = false; % Whether of not to close figures once saved.

%% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

disp('Loading results...');
Results = loadResults(directory);
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(directory, 'synapses_');
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);
sampleRate = Results.params.RecordingSettings.sampleRate;
simulationTime = Results.params.SimulationSettings.simulationTime;
timeStep = Results.params.SimulationSettings.timeStep;
unit_hz = zeros(nUnits,1);
spike_time_ms = Results.spikes(:,2);
spike_maxtime_sec = max(spike_time_ms) / 1000;
spike_time_sec1 = floor((Results.spikes(:,2) / 1000)) + 1;
spike_unit_id = floor(Results.spikes(:,1));
markers = '0+*x^vdsp';
colors =  'krgbcm';
if isempty(Results.events)
    stim_times = [];
    stim_ids = [];
else
    index = find([Results.events.marker] ~= '|');
    events = Results.events(index);
    stim_times = [events.time_ms];
    stim_ids = [events.id];
    color_ind = mod(ceil(stim_ids / length(markers)), length(colors)) + 1;
    stim_marker = mod(stim_ids, length(markers)) + 1;
end

%%
% Calculate which units belong to which groups
TP = Results.params.TissueParams;
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

% Divide slice into cubes
bin_size = 25; % microns
x_bins = (0:bin_size:TP.X);
y_bins = (0:bin_size:TP.Y);
z_bins = (0:bin_size:TP.Z);
x_somas = TP.somaPositionMat(:, 1);
y_somas = TP.somaPositionMat(:, 2);
z_somas = TP.somaPositionMat(:, 3);
ix = floor(x_somas / bin_size) + 1;
iy = floor(y_somas / bin_size) + 1;
iz = floor(z_somas / bin_size) + 1;

%%
% Find somas in a cylinder around Site 1 and Site 2.

if isfield(TP, 'stim_electrode_xpos')
    n_elect = size(TP.stim_electrode_xpos, 1);
elseif isfield(TP, 'opto_source_xpos')
    n_elect = length(TP.opto_source_xpos);
else
    n_elect = 0;
end

for ielect = 1:n_elect
    if isfield(TP, 'stim_electrode_xpos')
        x_elect = mean(TP.stim_electrode_xpos(ielect,1:2));
        y_elect = mean(TP.stim_electrode_ypos(ielect,1:2));
        z_elect = mean(TP.stim_electrode_zpos(ielect,1:2));
        delay = TP.stim_delay_ms(ielect);
    elseif isfield(TP, 'opto_source_xpos')
        x_elect = mean(TP.opto_source_xpos(ielect));
        y_elect = mean(TP.opto_source_ypos(ielect));
        z_elect = mean(TP.opto_source_zpos(ielect));
        delay = TP.opto_train_delay_ms(ielect);
    end

    ztop = TP.layerBoundaryArr(top_layer_boundary); 
    if top_layer_boundary == 2
        ztop = ztop - 50;  % Unit positions start slightly below L2/3 boundary
    end
    zbot = TP.layerBoundaryArr(bot_layer_boundary);

    is_elect = (z_somas < ztop) & (z_somas > zbot) & ...
        (sqrt((x_somas - x_elect).^2 + (y_somas - y_elect).^2) <= nearness);
    n_site_units = length(spike_unit_id(is_elect));

    % Calculate unit layers.
    layer_tops = TP.layerBoundaryArr;
    unit2layer = ones(1, nUnits); % Converts unit index to a layer
    nlayers = length(layer_tops) - 1;
    for i = 1:nlayers
        unit2layer( (z_somas <= layer_tops(i)) & (z_somas > layer_tops(i+1)) ) = i;
    end
    %layer_names = {'surf', 'L23', 'L4', 'L5', 'L6', 'L6bot'};

    %%
    % Activity plot for spikes occurring just after a stimulus.
    % Count how many spikes occur for units in each bin.
    % Coincidence window and baseline must fit in the [-pre,post) ms data window.
        
    coincidence_ms = peak_window_ms + delay;
    n = length(spike_unit_id);
    bin_size_ms = 20;
    maxbin = floor((pre_ms + post_ms) / bin_size_ms);
    psth = zeros(nlayers, maxbin);  % All units by layer
    psthe = zeros(nlayers, maxbin); %  excitatory units only
    psthi = zeros(nlayers, maxbin); %  inhibitory units only
    units_used = ones(1, nUnits);  % flag for units used in psth
    eunits_used = ones(1, nUnits);  % flag for units used in psthe
    iunits_used = ones(1, nUnits);  % flag for units used in psthi
    act = zeros(length(z_bins), length(x_bins));    % Activity
    bact = zeros(length(z_bins), length(x_bins));   % Baseline
    base_count = 0;
    peak_count = 0;

    stim_ms = [];
    if ~isempty(stim_times)
        stim_ms = stim_times(stim_ids == 1);
    elseif isfield(TP, 'stim_ms')
        stim_ms = TP.stim_ms;
        stim_delay = TP.stim_delay_ms;
        stim_size = TP.stim_size;
    end

    end_ms = pre_ms + post_ms;
    costr = [num2str(coincidence_ms(1)) '-' num2str(coincidence_ms(2)) ...
        'ms,' layer_names{top_layer_boundary} '-' layer_names{bot_layer_boundary-1}];

    if length(stim_ms) > 1
        for i = 1:n % Run through list of spikes
            % count spikes near first stim in the pair
            id = spike_unit_id(i);
            xi = ix(id);
            zi = iz(id);
            deltat_ms = spike_time_ms(i) - stim_ms;
            index = find((deltat_ms >= -pre_ms) & (deltat_ms < post_ms));  % spikes inside PSTH window
            for j = index
                dt = floor((deltat_ms(j) + pre_ms)/bin_size_ms) + 1; % 10 ms bin for ith spike
                if is_elect(id)
                    layer = unit2layer(id);
                    psth(layer,dt) = psth(layer,dt) + 1;
                    units_used(id) = layer;
                    group = unit2group(id);
                    if ismember(group, inhibitory_unit_groups)
                        psthi(layer,dt) = psthi(layer,dt) + 1;
                        iunits_used(id) = layer;
                    else
                        psthe(layer,dt) = psthe(layer,dt) + 1;
                        eunits_used(id) = layer;
                    end
                end
                if (deltat_ms(j) >= coincidence_ms(1)) && (deltat_ms(j) < coincidence_ms(2))
                    % count spike if it occurred upto dt ms after a stimulus
                    act(zi, xi) = act(zi, xi) + 1;
                    if is_elect(id)
                        peak_count = peak_count + 1;  
                    end
                elseif (deltat_ms(j) >= -baseline_ms) && (deltat_ms(j) < 0)
                    % count baseline spikes
                    bact(zi, xi) = bact(zi, xi) + 1;
                    if is_elect(id)
                        base_count = base_count + 1;   
                    end
                end
            end
        end
        ntrials = length(stim_ms); % Normalize by number of stimulus trials
        psth = psth ./ ntrials;
        psthe = psthe ./ ntrials;
        psthi = psthi ./ ntrials;
        
        hfig = figure;
        hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 800 500];
        %subplot(2,1,1);
        hold on;
        legend_text = {};
        xaxis = -pre_ms:bin_size_ms:post_ms-bin_size_ms;
        layer_color{1} = 'k';
        fprintf('%s\t%s\t%s\t%s\t%s\t%s\n', 'Unit category', 'Pre-stim Hz', 'Pre-stim SD', 'Post-stim Hz', 'Post-stim SD', 'p-ranksum');
        binvals = zeros(2, 2, length(layer_names), pre_ms / bin_size_ms);
        for iLayer = 2:5
            % Convert spike counts to spikes_per_second.
            Hz = (1000 / bin_size_ms) * psthe(iLayer, :) / sum(eunits_used == iLayer);
            h = stairs(xaxis, Hz, 'LineWidth', 1.5');
            layer_color{iLayer} = get(h, 'Color');
            legend_text{end+1} = ['Excite ' layer_names{iLayer}];
            prebins = Hz(1 : pre_ms / bin_size_ms);
            postbins = Hz((1400 - pre_ms) / bin_size_ms + 1 : 1400 / bin_size_ms);
            fprintf('%s\t%g\t%g\t%g\t%g\t%g\n', legend_text{end}, mean(prebins), ...
                std(prebins), mean(postbins), std(postbins), ranksum(prebins, postbins));
            binvals(1,1, iLayer, :) = prebins;
            binvals(1,2, iLayer, :) = postbins;
        end
        for iLayer = 2:5
            Hz = (1000 / bin_size_ms) * psthi(iLayer, :) / sum(iunits_used == iLayer);
            h = stairs(xaxis, Hz, ...
                'Color', layer_color{iLayer}, 'LineStyle', ':', 'LineWidth', 1.5);
            legend_text{end+1} = ['Inhib ' layer_names{iLayer}];
            prebins = Hz(1 : pre_ms / bin_size_ms);
            postbins = Hz((1400 - pre_ms) / bin_size_ms + 1 : 1400 / bin_size_ms);
            fprintf('%s\t%g\t%g\t%g\t%g\t%g\n', legend_text{end}, mean(prebins), ...
                std(prebins), mean(postbins), std(postbins), ranksum(prebins, postbins));
            binvals(2,1, iLayer, :) = prebins;
            binvals(2,2, iLayer, :) = postbins;
        end
        hold off;
        xlim([-pre_ms post_ms]);
        set(gca, 'XTick', [-pre_ms, 0, 900, post_ms]);
        set(gca, 'TickDirMode', 'manual');
        %set(gca, 'TickDir', 'both');
        title(['Stimulus aligned average unit firing rate (nstim = ' num2str(ntrials) ')']);
        xlabel('Time (ms)');
        ylabel('Firing rate (Hz)');
        legend(legend_text, 'Location','NorthWest');

%         % Plot XZ projection of where spikes were correlated with stimulation
%         subplot(2,1,2);
%         h = pcolor(act);
%         set(gca, 'YTick', 0:20:length(x_bins));
%         set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
%         set(gca, 'YTick', flip(length(z_bins):-20:0));
%         set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
%         h.LineStyle = 'none'; % Remove grid lines.
%         colorbar;
%         hold on;
%         % plot electrode positions
%         plot((x_elect/bin_size)+1, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
%         % plot rectangle around electrode area
%         x1 = x_elect - nearness;
%         x2 = x_elect + nearness;
%         line(([x1 x2 x2 x1 x1]/bin_size) + 1, floor([ztop ztop zbot zbot ztop]/bin_size), 'Color', [1 0 0]);
%         title(['Stim -> Spike Coincidence Count (' costr ')']);
%         xlabel('X');
%         ylabel('Depth');

        save_figure(directory, ['Firing_rates_stim1_to_layers' num2str(ielect)], hfig, close_flag);
        file_name = strcat(directory,  ['/Firing_rates_stim1_to_layers' num2str(ielect)]);
        saveas(gcf, strcat(file_name, '.pdf'));

        % Compact Box plot for each category.  This shows outliers.
        hfig = figure;
        hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 800 500];
        unitsign = [1 1 1 1 2 2 2 2];
        sign_names = {'Excite', 'Inhib'};
        unitlayer = [2 3 4 5 2 3 4 5];
        plotvals = zeros(pre_ms / bin_size_ms, 2);
        for iplot = 1:8
            subplot(2,4, iplot);
            plotvals(:,1) = binvals(unitsign(iplot), 1, unitlayer(iplot), :);
            plotvals(:,2) = binvals(unitsign(iplot), 2, unitlayer(iplot), :);
            boxplot(plotvals, 'Labels', {'Pre', 'Post'});
            ylabel('Hz');
            if unitsign(iplot) == 1
                ylim([0 6]);
            else
                ylim([0 40])
            end
            title([sign_names{unitsign(iplot)} ' ' layer_names{unitlayer(iplot)}]);    
        end
        save_figure(directory, ['Firing_rates_stim1_to_layers_summary' num2str(ielect)], hfig, close_flag);
        file_name = strcat(directory,  ['/Firing_rates_stim1_to_layers_summary' num2str(ielect)]);
        saveas(gcf, strcat(file_name, '.pdf'));

    end
end
