function groupwWeightChangeMat = compare_weights_excit(saveDir, synapses_file_prefix, weights1_file_prefix, weights2_file_prefix)
% groupwWeightChangeMat = compare_weights_excit(saveDir, synapses_file_prefix, weights1_file_prefix, weights2_file_prefix)
%   saveDir: directory containing Vertex-2 results ('./vertex_results')
%   synapses_file_prefix: For example 'synapses_'
%   weights1_file_prefix: For example 'weights1_'
%   weights2_file_prefix: For example 'weights2_'
% groupwWeightChangeMat = compare_weights_excit('./vertex_results', 'synapses_', 'weights_', 'weights1_');
% groupwWeightChangeMat = compare_weights_excit('./vertex_results', 'synapses_', 'weights1_', 'weights2_');
% groupwWeightChangeMat = compare_weights_excit('./vertex_results', 'synapses_', 'weights1_', 'weights3_');
% groupwWeightChangeMat = compare_weights_excit('./vertex_results', 'synapses_', 'weights2_', 'weights3_');
%
% Same as compare_weights() but only looks at weights from excitatory units.
%
% Creates figures comparing two sets of synaptic weights from the same simulation run.
% The figures show mean weight changes between stimulation sites and unit groups.
% Returns groupwWeightChangeMat(post, pre) as the difference of the two group mean
% weight sets. This has the same dimensions as the groupWeightMat() array used
% to initialize weights in bsf_connectivity.m

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

%%
% Get simulation parameters.
% Order of cells in parameterCell:  TissueParams, NeuronParams, 
% ConnectionParams, RecordingSettings, SimulationSettings

disp('Loading parameters...');
params = load([saveDir 'parameters.mat']);
pFields = fields(params);
TP = params.(pFields{1}){1};
% NP = params.(pFields{1}){2};
% CP = params.(pFields{1}){3};
% RS = params.(pFields{1}){4};
% SS = params.(pFields{1}){5};

%%
% Get synapse and weight arrays
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(saveDir, synapses_file_prefix);
disp('Loading weights1 array...');
weights_arr = loadResultsWeightFile(saveDir, weights1_file_prefix);
disp('Loading weights2 array...');
weights2_arr = loadResultsWeightFile(saveDir, weights2_file_prefix);
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);

%%
% Calculate which units belong to which groups
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

%%
% Find somas in a cylinder around Site 1 and Site 2.
nearness = 150; % Micron radius around site
if isfield(TP, 'stim_electrode_xpos')
    x_elect1 = mean(TP.stim_electrode_xpos(1,1:2));
    y_elect1 = mean(TP.stim_electrode_ypos(1,1:2));
    z_elect1 = mean(TP.stim_electrode_zpos(1,1:2));
    ztop1 = max(TP.stim_electrode_zpos(1,:) + TP.stim_electrode_tip_length(1,:)) + nearness;
    zbot1 = min(TP.stim_electrode_zpos(1,:)) - nearness;
    
    x_elect2 = mean(TP.stim_electrode_xpos(2,1:2));
    y_elect2 = mean(TP.stim_electrode_ypos(2,1:2));
    z_elect2 = mean(TP.stim_electrode_zpos(2,1:2));    
    ztop2 = max(TP.stim_electrode_zpos(2,:) + TP.stim_electrode_tip_length(2,:)) + nearness;
    zbot2 = min(TP.stim_electrode_zpos(2,:)) - nearness;
elseif isfield(TP, 'opto_source_xpos')
    x_elect1 = mean(TP.opto_source_xpos(1));
    y_elect1 = mean(TP.opto_source_ypos(1));
    z_elect1 = mean(TP.opto_source_zpos(1));
    ztop1 = TP.opto_source_zpos(1);
    zbot1 = min(TP.opto_source_zpos(1) - 500, TP.layerBoundaryArr(3));
    
    x_elect2 = mean(TP.opto_source_xpos(2));
    y_elect2 = mean(TP.opto_source_ypos(2));
    z_elect2 = mean(TP.opto_source_zpos(2));    
    ztop2 = TP.opto_source_zpos(2);
    zbot2 = min(TP.opto_source_zpos(2) - 500, TP.layerBoundaryArr(3));    
else
    x_elect1 = TP.X / 3;
    y_elect1 = TP.Y / 2;
    z_elect1 = TP.Z;
    ztop1 = TP.layerBoundaryArr(2);
    zbot1 = TP.layerBoundaryArr(3);
    
    x_elect2 = 2 * TP.X / 3;
    y_elect2 = TP.Y / 2;
    z_elect2 = TP.Z;    
    ztop2 = TP.layerBoundaryArr(2);
    zbot2 = TP.layerBoundaryArr(3);      
end

x_somas = TP.somaPositionMat(:, 1);
y_somas = TP.somaPositionMat(:, 2);
z_somas = TP.somaPositionMat(:, 3);

is_elect1 = (z_somas < ztop1) & (z_somas > zbot1) & ...
    (sqrt((x_somas - x_elect1).^2 + (y_somas - y_elect1).^2) < nearness);

is_elect2 = (z_somas < ztop2) & (z_somas > zbot2) & ...
    (sqrt((x_somas - x_elect2).^2 + (y_somas - y_elect2).^2) < nearness);

% Find somas in a tissue slice near the Y_electrode positions presented 
% from the XZ side.
in_sideXZ_slice =  (abs(y_somas - y_elect1) < nearness) | (abs(y_somas - y_elect2) < nearness);

% Find somas in a tissue slice near the Z_electrode positions presented from
% the XY surfact top.
in_topdownXY_slice = (z_somas < max(ztop1, ztop2)) & (z_somas > min(zbot1, zbot2));

%%
% Compute weight differences and count number of weights involving Site1/2
nWeights = 0;    
nSite = 0; % Number of weights that connect with Site1 or Site2
for pre_unit = 1:nUnits
    postIDs = syn_arr{pre_unit,1};
    nWeights = nWeights + length(postIDs);
    weights_arr{pre_unit} = weights2_arr{pre_unit} - weights_arr{pre_unit};
    if is_elect1(pre_unit) || is_elect2(pre_unit)
        nSite = nSite + length(postIDs);
    else      
        nSite = nSite + sum(is_elect1(postIDs) | is_elect2(postIDs));
    end
end
clear weights2_arr; % Free memory

%%
% Keep track of weight changes for each of our categories.
% We exclude the Other->Other category because the 500 million of these
% weights will cause memory issues on computers with only 16 GB Ram.
dweight = zeros(nSite, 1); % Change in each weight
categories = {'S1->S2'; 'S2->S1'; 'O->S2'; 'O->S1'; 'S2->O'; 'S1->O'};
category = zeros(nSite, 1, 'int8'); % Category 1 = S1->S2, 2 = S2->S1, etc.
iw = 0; % index for current element of dweight and category.

%%
% Keep track of mean weight changes between the two sites.
% Also track the mean change for the Other->Other category.
dw1to2_sum = 0;    % Sum of weight changes for connections Site1 -> Site2.
dw1to2_sumsqr = 0; % Sum square of weight changes (for variance)
dw1to2_count = 0;  % Number of weight changes (for mean)

dw2to1_sum = 0;    % Sum of weight changes for connections Site2 -> Site1.
dw2to1_sumsqr = 0;
dw2to1_count = 0;

dw2_sum = 0;       % Others to Site2.
dw2_sumsqr = 0; 
dw2_count = 0;

dw1_sum = 0;       % Others to Site1.
dw1_sumsqr = 0; 
dw1_count = 0;

dwf2_sum = 0;      % Others from Site2.
dwf2_sumsqr = 0; 
dwf2_count = 0;

dwf1_sum = 0;      % Others from Site1
dwf1_sumsqr = 0;
dwf1_count = 0;

dw0_sum = 0;       % Other -> Other
dw0_sumsqr = 0;
dw0_count = 0;

%%
% Track pre and post locations of weight changes.  Do both the XZ side
% view and the XY top view.
bin_size = 25; % microns
x_bins = (0:bin_size:TP.X);
y_bins = (0:bin_size:TP.Y);
z_bins = (0:bin_size:TP.Z);

ix = floor(x_somas / bin_size) + 1;
iy = floor(y_somas / bin_size) + 1;
iz = floor(z_somas / bin_size) + 1;

dwpre = zeros(length(z_bins), length(x_bins)); % On XZ plane
dwpost = zeros(length(z_bins), length(x_bins));
ndwpre = zeros(length(z_bins), length(x_bins));
ndwpost = zeros(length(z_bins), length(x_bins));

dwprey = zeros(length(y_bins), length(x_bins)); % On XY plane
dwposty = zeros(length(y_bins), length(x_bins));
ndwprey = zeros(length(y_bins), length(x_bins));
ndwposty = zeros(length(y_bins), length(x_bins));

%%
% Sum weight changes between groups and build a distribution of weight changes
% Here we only look at weights that change.
w_sum = zeros(nGroups, nGroups);
w_count = zeros(nGroups, nGroups);
w_hist = zeros(nGroups, nGroups, 201);
excitatory_groups = [1 4 5 6 9 10 13 14]; 
do_pregroup = zeros(1,15);
do_pregroup(excitatory_groups) = 1; % Only do connections from excitatory neuron groups
for pre_unit = 1:nUnits
  pre_group = unit2group(pre_unit);
  if do_pregroup(pre_group)
    postIDs = syn_arr{pre_unit,1};
    dwts = weights_arr{pre_unit};
    postGroups = unit2group(postIDs);
    dbin = max(1, min(201, floor(1000 * dwts) + 101)); % Clip to bin limits
    nPost = length(postIDs);
    ixpre = ix(pre_unit);
    iypre = iy(pre_unit);
    izpre = iz(pre_unit);
    sumdwts = sum(dwts);
    nNonZero = sum(dwts ~= 0);

%     if in_sideXZ_slice(pre_unit)
        dwpre(izpre, ixpre) = dwpre(izpre, ixpre) + sumdwts; % Track where presynaptic weight changes occur
        ndwpre(izpre, ixpre) = ndwpre(izpre, ixpre) + nNonZero;
%     end
%     if in_topdownXY_slice(pre_unit)
        dwprey(iypre, ixpre) = dwprey(iypre, ixpre) + sumdwts;
        ndwprey(iypre, ixpre) = ndwprey(iypre, ixpre) + nNonZero;
%     end
    for iPost = 1:nPost
      post_group = postGroups(iPost);
      dw = dwts(iPost);
      if dw ~= 0
        w_sum(post_group, pre_group) = w_sum(post_group, pre_group) + dw;
        w_count(post_group, pre_group) = w_count(post_group, pre_group) + 1;
        ibin = dbin(iPost);
        w_hist(post_group, pre_group, ibin) = w_hist(post_group, pre_group, ibin) + 1;
        
        % Track where post-synaptic weight changes occur
        post_unit = postIDs(iPost);
        ixpost = ix(post_unit);
        iypost = iy(post_unit);
        izpost = iz(post_unit);
%         if in_sideXZ_slice(post_unit)
            dwpost(izpost, ixpost) = dwpost(izpost, ixpost) + dw;
            ndwpost(izpost, ixpost) = ndwpost(izpost, ixpost) + 1;
%         end
%         if in_topdownXY_slice(post_unit)
            dwposty(iypost, ixpost) = dwposty(iypost, ixpost) + dw;
            ndwposty(iypost, ixpost) = ndwposty(iypost, ixpost) + 1;
%         end
        
        % Track weight changes for each connection category
        if is_elect1(pre_unit) && is_elect2(post_unit)
            iw = iw + 1; % Index for this weight
            dweight(iw) = dw;
            category(iw) = 1;               % Site1 -> Site2.
            dw1to2_sum = dw1to2_sum + dw;
            dw1to2_sumsqr = dw1to2_sumsqr + dw*dw;
            dw1to2_count = dw1to2_count + 1;
        elseif is_elect1(post_unit) && is_elect2(pre_unit)
            iw = iw + 1;
            dweight(iw) = dw;
            category(iw) = 2;               % Site2 -> Site1.
            dw2to1_sum = dw2to1_sum + dw; 
            dw2to1_sumsqr = dw2to1_sumsqr + dw*dw;
            dw2to1_count = dw2to1_count + 1;
       elseif is_elect2(post_unit)
            iw = iw + 1;
            dweight(iw) = dw;
            category(iw) = 3;              % Other to Site2
            dw2_sum = dw2_sum + dw;
            dw2_sumsqr = dw2_sumsqr + dw*dw;
            dw2_count = dw2_count + 1;
        elseif is_elect1(post_unit)
            iw = iw + 1;
            dweight(iw) = dw;
            category(iw) = 4;              % Other to Site1
            dw1_sum = dw1_sum + dw; 
            dw1_sumsqr = dw1_sumsqr + dw*dw;
            dw1_count = dw1_count + 1;
        elseif is_elect2(pre_unit)
            iw = iw + 1;
            dweight(iw) = dw;
            category(iw) = 5;              % Site2 to Other
            dwf2_sum = dwf2_sum + dw;
            dwf2_sumsqr = dwf2_sumsqr + dw*dw;
            dwf2_count = dwf2_count + 1;
        elseif is_elect1(pre_unit)
            iw = iw + 1;
            dweight(iw) = dw;
            category(iw) = 6;              % Site1 to Other
            dwf1_sum = dwf1_sum + dw; 
            dwf1_sumsqr = dwf1_sumsqr + dw*dw;
            dwf1_count = dwf1_count + 1;
        else
            dw0_sum = dw0_sum + dw;   % Not to Site1 or Site2
            dw0_sumsqr = dw0_sumsqr + dw*dw;
            dw0_count = dw0_count + 1;
        end
      end
    end % for iPost
  end % if do_pregroup
end % for pre_unit
clear weights_arr; % Free memory
dweight = dweight(1:iw);
category = category(1:iw);

%%
% Sanity checks
disp(['Weights = ' num2str(nWeights) ' -> ' num2str(sum(w_count, 'all')) ' Excitatory weights that changed']);
disp(['Weights involving Site1 or Site2 = ' num2str(nSite) ' -> ' num2str(iw) ' Excitatory weights that changed']);

%%
% Compute stats.  Box plots will show median and quartiles so here we show
% means and standard deviations.  The data is very non-normal, so z-scores 
% are probably not relavant. 
dw1to2_mean = 0;
dw1to2_std = 0;
dw1to2_zscore = 0;
if dw1to2_count > 0
    dw1to2_mean = dw1to2_sum / dw1to2_count;
    dw1to2_std = sqrt((dw1to2_sumsqr/dw1to2_count) - (dw1to2_sum/dw1to2_count)^2);
    dw1to2_zscore = dw1to2_mean / (dw1to2_std / sqrt(dw1to2_count));
end

dw2to1_mean = 0;
dw2to1_std = 0;
dw2to1_zscore = 0;
if dw2to1_count > 0
    dw2to1_mean = dw2to1_sum / dw2to1_count;
    dw2to1_std = sqrt((dw2to1_sumsqr/dw2to1_count) - (dw2to1_sum/dw2to1_count)^2);
    dw2to1_zscore = dw2to1_mean / (dw2to1_std / sqrt(dw2to1_count));
end

dw2_mean = 0;
dw2_std = 0;
dw2_zscore = 0;
if dw2_count > 0
    dw2_mean = dw2_sum / dw2_count;
    dw2_std = sqrt((dw2_sumsqr/dw2_count) - (dw2_sum/dw2_count)^2);
    dw2_zscore = dw2_mean / (dw2_std / sqrt(dw2_count));
end

dw1_mean = 0;
dw1_std = 0;
dw1_zscore = 0;
if dw1_count > 0
    dw1_mean = dw1_sum / dw1_count;
    dw1_std = sqrt((dw1_sumsqr/dw1_count) - (dw1_sum/dw1_count)^2);
    dw1_zscore = dw1_mean / (dw1_std / sqrt(dw1_count));
end

dwf2_mean = 0;
dwf2_std = 0;
dwf2_zscore = 0;
if dwf2_count > 0
    dwf2_mean = dwf2_sum / dwf2_count;
    dwf2_std = sqrt((dwf2_sumsqr/dwf2_count) - (dwf2_sum/dwf2_count)^2);
    dwf2_zscore = dwf2_mean / (dwf2_std / sqrt(dwf2_count));
end

dwf1_mean = 0;
dwf1_std = 0;
dwf1_zscore = 0;
if dwf1_count > 0
    dwf1_mean = dwf1_sum / dwf1_count;
    dwf1_std = sqrt((dwf1_sumsqr/dwf1_count) - (dwf1_sum/dwf1_count)^2);
    dwf1_zscore = dwf1_mean / (dwf1_std / sqrt(dwf1_count));
end

dw0_mean = 0;
dw0_std = 0;
dw0_zscore = 0;
if dw0_count > 0
    dw0_mean = dw0_sum / dw0_count;
    dw0_std = sqrt((dw0_sumsqr/dw0_count) - (dw0_sum/dw0_count)^2);
    dw0_zscore = dw0_mean / (dw0_std / sqrt(dw0_count));
end

diary([saveDir 'Mean_Weight_Change_excit.txt']);
disp(datetime);
disp([weights2_file_prefix ' -  ' weights1_file_prefix ' (for excitatory weights that changed)']);
disp(['Mean weight change Site1 -> Site2: ' num2str(dw1to2_mean) ', sd: ' num2str(dw1to2_std) ', n: ' num2str(dw1to2_count) ', z: ' num2str(dw1to2_zscore)]);
disp(['Mean weight change Site2 -> Site1: ' num2str(dw2to1_mean) ', sd: ' num2str(dw2to1_std) ', n: ' num2str(dw2to1_count) ', z: ' num2str(dw2to1_zscore)]);
disp(['Mean weight change Other to Site2: ' num2str(dw2_mean) ', sd: ' num2str(dw2_std) ', n: ' num2str(dw2_count) ', z: ' num2str(dw2_zscore)]);
disp(['Mean weight change Other to Site1: ' num2str(dw1_mean) ', sd: ' num2str(dw1_std) ', n: ' num2str(dw1_count) ', z: ' num2str(dw1_zscore)]);
disp(['Mean weight change Site2 to Other: ' num2str(dwf2_mean) ', sd: ' num2str(dwf2_std) ', n: ' num2str(dwf2_count) ', z: ' num2str(dwf2_zscore)]);
disp(['Mean weight change Site1 to Other: ' num2str(dwf1_mean) ', sd: ' num2str(dwf1_std) ', n: ' num2str(dwf1_count) ', z: ' num2str(dwf1_zscore)]);
disp(['Mean weight changes outside Sites: ' num2str(dw0_mean) ', sd: ' num2str(dw0_std) ', n: ' num2str(dw0_count) ', z: ' num2str(dw0_zscore)]);
disp('-----------------------------------');
diary off

%%
% Compact Box plot for each category.  This shows outliers.
hfig = figure;
boxplot(dweight, category, 'Labels', categories, 'PlotStyle','compact');
weights1_file_prefix(weights1_file_prefix == '_') = ' ';
weights2_file_prefix(weights2_file_prefix == '_') = ' ';
title([weights2_file_prefix ' -  ' weights1_file_prefix]);
ylabel('Weight Change (Excitatory only)');
save_figure(saveDir, [weights2_file_prefix weights1_file_prefix 'Boxplots excitatory weight changes (outliers)'], hfig);

%%
% Box plot for each category zoomed into whiskers (no outliers)
hfig = figure;
h = boxplot(dweight, category, 'Labels', categories, 'Symbol', '');
objs = findobj(h, 'Tag', 'Upper Adjacent Value');
ymax = max([objs.YData]);
ymax = ceil(ymax * 100) / 100;
objs = findobj(h, 'Tag', 'Lower Adjacent Value');
ymin = max([objs.YData]);
ymin = floor(ymin * 100) / 100;
if ymax > ymin
    ylim([ymin ymax]);
end
title([weights2_file_prefix ' -  ' weights1_file_prefix]);
ylabel('Weight Change (Excitatory only)');
save_figure(saveDir, [weights2_file_prefix weights1_file_prefix 'Boxplots excitatory weight changes'], hfig);

%%
% Return mean weight difference
groupwWeightChangeMat = w_sum ./ w_count;

%%
% Figure for mean weight difference
hfig = figure;
wdiff = groupwWeightChangeMat;
wdiff(:, end+1) = wdiff(:, end); % extra row and col for pcolor()
wdiff(end+1, :) = wdiff(end, :);
pcolor(wdiff);
colorbar;
set(gca, 'YTick', (1:nGroups)+0.5);
labels = cellstr(num2str((1:nGroups)'))';
set(gca, 'YTickLabel', labels);
set(gca, 'XTick', (1:nGroups)+0.5);
set(gca, 'XTickLabel', labels);
axis ij;
axis square;
title([weights2_file_prefix ' -  ' weights1_file_prefix]);
ylabel('Post Group');
xlabel('Pre Group');
save_figure(saveDir, [weights2_file_prefix weights1_file_prefix 'Difference_ExcitatoryOnly'], hfig);

%%
% Weight change distributions by group
% Look at changes between -0.1 to 0.1.
hfig = figure;
set(hfig, 'Position', get(hfig, 'Position') .* [0.5 0.25 2 2]);
for iPost = 1:nGroups
    for iPre = 1:nGroups
        w(1:201) = w_hist(iPost, iPre, :);
        n = sum(w, 'all');
        if n > 0
            w = w / sum(w, 'all');
            h = subplot(nGroups, nGroups, (iPost - 1) * nGroups + iPre);
            bar((-100:100) * 0.001, w);
            xlim([-0.1 0.1]);
            ylim([0 0.1]);
            if (iPost < nGroups)
                h.XTick = [];
            else
                h.XTick = [-0.1 0 0.1];
                xlabel(['G' num2str(iPre)]);
            end
            if (iPre > 1)
                h.YTick = [];
            else
                h.YTick = [0 0.1];
                ylabel(['G' num2str(iPost)]);
            end
        end
    end
end
hfig.Name = 'Neuron Group_x to Group_y Weight Change Distributions';
save_figure(saveDir, [weights2_file_prefix weights1_file_prefix 'WeightChangeDistributions_ExcitatoryOnly'], hfig);

%%
% Plot where weight changes occurred

% ndwpost(ndwpost == 0) = 1; % Fix divide by zeros to give zero instead of NaN
% ndwposty(ndwposty == 0) = 1;
% ndwpre(ndwpre == 0) = 1;
% ndwprey(ndwprey == 0) = 1;

dwpost = dwpost ./ ndwpost;  % Calculate mean weight changes
dwposty = dwposty ./ ndwposty;
dwpre = dwpre ./ ndwpre;
dwprey = dwprey ./ ndwprey;

dwmin = min(min([dwpost, dwpre], [], 'all'), min([dwposty, dwprey], [], 'all'));
dwmax = max(max([dwpost, dwpre], [], 'all'), max([dwposty, dwprey], [], 'all'));
dwpost(1,end) = dwmin;      % Include a min and max point in each figure
dwpost(end,end) = dwmax;    % so they will all be scaled the same.
dwposty(1,end) = dwmin;
dwposty(end,end) = dwmax;
dwpre(1,end) = dwmin;
dwpre(end,end) = dwmax;
dwprey(1,end) = dwmin;
dwprey(end,end) = dwmax;

hfig = figure;
set(hfig, 'Position', get(hfig, 'Position') .* [0.5 0.25 2 2]);
subplot(2,2,1);
h = pcolor(dwpost);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', flip(length(z_bins):-20:0));
set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Exitatory Mean Weight Changes to Post-synaptic units (side view)');
xlabel('X (Y slice near electrodes)');
ylabel('Z (depth)');
colorbar;

subplot(2,2,2);
h = pcolor(dwposty);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', flip(length(z_bins):-20:0));
set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none';
title('Excitatory Mean Weight Changes to Post-synaptic units (top view)');
xlabel('X (Z slice near electrodes)');
ylabel('Y');
colorbar;

subplot(2,2,3);
h = pcolor(dwpre);
set(gca, 'XTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')')));
set(gca, 'YTick', 0:20:length(z_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none';
title('Excitatory Mean Weight Changes from Presynaptic units (side view)');
xlabel('X (Y slice near electrodes)');
ylabel('Z (depth)');
colorbar;

subplot(2,2,4);
h = pcolor(dwprey);
set(gca, 'XTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')')));
set(gca, 'YTick', 0:20:length(y_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Excitatory Mean Weight Changes from Presynaptic units (top view)');
xlabel('X (Z slice near electrodes)');
ylabel('Y');
colorbar;
save_figure(saveDir, [weights2_file_prefix weights1_file_prefix 'MeanChange LocationMap (excitatory weights only)'], hfig);


