function h = plot_group_connection_dist(saveDir, synapses_file_prefix, weights_file_prefix)
% h = plot_group_connection_dist(saveDir, synapses_file_prefix, weights_file_prefix)
%   saveDir: directory containing Vertex-2 results ('./vertex_results')
%   synapses_file_prefix: For example 'synapses_'
%   weights_file_prefix: For example 'weights1_'
%
% plot_group_connection_dist('./vertex_results', 'synapses_', 'weights_');
% plot_group_connection_dist('./vertex_results', 'synapses_', 'weights1_');
% plot_group_connection_dist('./vertex_results', 'synapses_', 'weights2_');
% plot_group_connection_dist('./vertex_results', 'synapses_', 'weights3_');
%
% Creates and returns a figure with distributions of weights from and to
% all unit groups.
%
% Prints a group weight matrix with standard deviations to use
% in bsf_connectivity_dist.m
%
% This is a figure to summarize network connectivity.  It is used mostly to
% confirm that connections between neuron groups are distributed as expected.
% There are 15 neuron groups defined.  The top to figures count the total 
% number of connections from/to each neuron group.  The second row shows the
% mean weight values for those connections.  The "mean weight From" graph 
% shows that 3 neuron groups project connections with extremely low weights.  
% Values can be checked agains the variable groupWeightMat defined in 
% bsf_connections_dist.m.  That array defines the weight value for each 
% connection based on the pre and post synaptic neuron group.  The bottom 
% two graphs show the distribution of the weights from/to neuron groups.  
% This is a 3d histogram with counts coded in color.

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

% Get simulation parameters.
% Order of cells in parameterCell:  TissueParams, NeuronParams, 
% ConnectionParams, RecordingSettings, SimulationSettings

params = load([saveDir 'parameters.mat']);
pFields = fields(params);
TP = params.(pFields{1}){1};
NP = params.(pFields{1}){2};
CP = params.(pFields{1}){3};
RS = params.(pFields{1}){4};
SS = params.(pFields{1}){5};

% Get synapse and weight arrays
disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(saveDir, synapses_file_prefix);
disp('Loading weights array...');
weights_arr = loadResultsWeightFile(saveDir, weights_file_prefix);
nUnits = length(syn_arr); % Number of units
disp(['nUnits = ' num2str(nUnits)]);

% Calculate which units belong to which groups
group_bounds = TP.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

pre_count = zeros(1, nGroups);
post_count = zeros(1, nGroups);
pre_wsum = zeros(1, nGroups);
post_wsum = zeros(1, nGroups);
pre_wcount = zeros(nGroups+1, 42);
post_wcount = zeros(nGroups+1, 42);
post_pre_wsum = zeros(nGroups, nGroups);
post_pre_wsum2 = zeros(nGroups, nGroups);
post_pre_count = zeros(nGroups, nGroups);
for iPre = 1:nUnits
    pre_group = unit2group(iPre);
    pre_count(pre_group) = pre_count(pre_group) + length(weights_arr{iPre});
    pre_wsum(pre_group) = pre_wsum(pre_group) + sum(weights_arr{iPre});
    for iPost = 1:length(syn_arr{iPre,1})
        post_group = unit2group(syn_arr{iPre,1}(iPost));
        post_count(post_group) = post_count(post_group) + 1;
        w = weights_arr{iPre}(iPost);
        post_wsum(post_group) = post_wsum(post_group) + w;
        wbin = min(41, floor(w * 10) + 1);
        post_wcount(post_group, wbin) = post_wcount(post_group, wbin) + 1;
        pre_wcount(pre_group, wbin) = pre_wcount(pre_group, wbin) + 1;
        post_pre_wsum(post_group, pre_group) = post_pre_wsum(post_group, pre_group) + w;
        post_pre_wsum2(post_group, pre_group) = post_pre_wsum2(post_group, pre_group) + (w*w);
        post_pre_count(post_group, pre_group) = post_pre_count(post_group, pre_group) + 1;
    end
end

disp(['nWeights = ' num2str(sum(pre_count)) ' = ' num2str(sum(post_count))]);

pre_wmean = pre_wsum ./ pre_count;
post_wmean = post_wsum ./ pre_count;

hfig = figure;
subplot(3,2,1);
bar(pre_count);
ylim([0 max(max(pre_count, post_count))]);
title('Connections from group');

subplot(3,2,2);
bar(post_count);
ylim([0 max(max(pre_count, post_count))]);
title('Connections to group');

subplot(3,2,3);
bar(pre_wmean);
title('Mean weight from group');
ylim([0 max(max(pre_wmean, post_wmean))]);

subplot(3,2,4);
bar(post_wmean);
title('Mean weight to group');
ylim([0 max(max(pre_wmean, post_wmean))]);

subplot(3, 2, 5);
for i = 1:nGroups
    pre_wcount(i, :) = 100 * pre_wcount(i, :) / sum(pre_wcount(i, :));
end
h = pcolor(pre_wcount');
h.LineStyle = 'none'; % Remove grid lines.
xlabel('Group');
wlabel = weights_file_prefix;
wlabel(wlabel == '_') = ' ';
ylabel(wlabel);
title('Weight Distribution from Group');
set(gca, 'YTickLabel', cellstr(num2str(0.1 * (get(gca, 'YTick')' - 1))));

subplot(3, 2, 6);
for i = 1:nGroups
    post_wcount(i, :) = 100 * post_wcount(i, :) / sum(post_wcount(i, :));
end
h = pcolor(post_wcount');
h.LineStyle = 'none'; % Remove grid lines.
xlabel('Group');
title('Weight Distribution to Group');
set(gca, 'YTickLabel', cellstr(num2str(0.1 * (get(gca, 'YTick')' - 1))));

save_figure(saveDir, [weights_file_prefix 'Distribution'], hfig);

% mean weight group to group matrix
post_pre_count(post_pre_count == 0) = 1;
groupWeightMat = post_pre_wsum ./ post_pre_count;
groupWeightSDMat = ((post_pre_wsum2 ./ post_pre_count) - ((post_pre_wsum ./ post_pre_count).^2)) .^ 0.5;
%groupWeightMat(isnan(groupWeightMat)) = 0.0;
%disp(num2str(0.001 * ceil(groupWeightMat .* 1000),3));

if SS.stdp
    % Weights could change during simulation.
    % Eliminate outliers past 3 standard deviations
    post_pre_wsum = zeros(nGroups, nGroups);
    post_pre_wsum2 = zeros(nGroups, nGroups);
    post_pre_count = zeros(nGroups, nGroups);
    for iPre = 1:nUnits
        pre_group = unit2group(iPre);
        pre_count(pre_group) = pre_count(pre_group) + length(weights_arr{iPre});
        pre_wsum(pre_group) = pre_wsum(pre_group) + sum(weights_arr{iPre});
        for iPost = 1:length(syn_arr{iPre,1})
            post_group = unit2group(syn_arr{iPre,1}(iPost));
            w = weights_arr{iPre}(iPost);
            cw = groupWeightMat(post_group, pre_group) + [-3 3] .* groupWeightSDMat(post_group, pre_group);
            if (w > cw(1)) && (w < cw(2))
                post_pre_wsum(post_group, pre_group) = post_pre_wsum(post_group, pre_group) + w;
                post_pre_wsum2(post_group, pre_group) = post_pre_wsum2(post_group, pre_group) + (w*w);
                post_pre_count(post_group, pre_group) = post_pre_count(post_group, pre_group) + 1;
            end
        end
    end

    % print the mean weight group to group matrix
    post_pre_count(post_pre_count == 0) = 1;
    groupWeightMat = post_pre_wsum ./ post_pre_count;
    groupWeightSDMat = ((post_pre_wsum2 ./ post_pre_count) - ((post_pre_wsum ./ post_pre_count).^2)) .^ 0.5;
end

printvar(groupWeightMat, 'groupWeightMat_mu');
printvar(groupWeightSDMat, 'groupWeightMat_sd');

function printvar(A, Name)
    disp([Name ' = [ ...']);
    nrows = size(A, 1);
    ncols = size(A, 2);
    for r = 1:nrows
        for c = 1:ncols
            v = A(r,c);
            if v < 0.000001
                fprintf('      0');
            elseif v <= 0.0001
                fprintf(' 0.0001');
            else
                fprintf(' %1.4f', v)
            end
        end
        if r < nrows
            disp('; ...');
        else
            disp('];');
        end
    end
end

end