function [] = isi_hist_for_neuron(neuron_id, input_dir, Results, should_save)
    spikes = Results.spikes;
    % find all rows of spikes where 1st column is neuron_id
    neuron_res = spikes(ismember(spikes(:, 1), neuron_id), :);
    disp(strcat(...
        "Neuron ", num2str(neuron_id), " fired ", ...
        num2str(length(neuron_res)), " times"));
    % find time intervals
    intervals = diff(neuron_res(:, 2));
    histogram(intervals)
    title(strcat( ...
        "Interspike Interval Histogram for Neuron ID ", ...
        num2str(neuron_id) ...
    ), 'FontSize', 16);
    file_name = strcat(input_dir, '/isi_hist_', num2str(neuron_id));
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
end


