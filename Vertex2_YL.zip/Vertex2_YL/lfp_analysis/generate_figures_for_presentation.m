% res = loadResults('~/vertex_results/random_con_scale_1_40s');
res = loadResults('C:\Users\Julien\Downloads\f\_\vertex_2\vertex_results');

%%
% Generate LFP PSD
z_poses = res.params.RecordingSettings.meaZpositions;
sample_rate = res.params.RecordingSettings.sampleRate;
pwelch(res.LFP(5, :), [], [], [], sample_rate);
title("PSD LFP recording of center electrode on surface");
xlabel("Frequency (Hz)");
ylabel("Power/frequency (dB/Hz)");
xlim([0, 300])
grid off
set(gca, 'FontSize', 14)
set(gca,'box','off')


%%
% Generate Raster Plot
rasterParams.colors = {'k','m','k','m','k','m', 'k','m','k','m','k','m', 'k','m','k'};
rasterParams.groupBoundaryLines = 'c';
rasterParams.title = 'Spike Raster By Neuron Group';
rasterParams.xlabel = 'Time (ms)';
rasterParams.ylabel = 'Neuron ID';
rasterParams.tmin = 20000;
rasterParams.tmax = 20050;
rasterParams.figureID = 1;
rasterParams.FontSize = 14;
plotSpikeRaster(res, rasterParams);
ax = gca;
ax.XRuler.Exponent = 0;
ax.YRuler.Exponent = 0;

%%
% Generate isi histogram
isi_hist_for_neuron(156000, '~/vertex_results/random_connectivity_model_with_con', res, false);
title("ISI Histogram of Pyrmidal Neuron in L5 projecting to L2/3");
xlabel("Time between fires (ms)");
ylabel("Number of Intervals")
grid off
set(gca,'box','off')
set(gca, 'FontSize', 14)


%%
% Generate Firing rate histogram for Neuron Group

% Load the simulation results
num_neurons = res.params.TissueParams.N;
neuron_fires = res.spikes(:, 1);
time = res.params.SimulationSettings.simulationTime;
disp("Average Overall Firing Rate:");
disp(length(neuron_fires) / num_neurons / time * 1000);
% calculate firing rate per neuron
total_fires_by_neuron = zeros(num_neurons, 1);

for i = 1:length(neuron_fires)
    firing_neuron = neuron_fires(i);
    total_fires_by_neuron(firing_neuron) = total_fires_by_neuron(firing_neuron) + 1;
end

% figure out per-layer firing rates
% array of neuron id boundaries per group
group_arr = res.params.TissueParams.groupBoundaryIDArr;
total_fires_by_group = zeros(length(group_arr) - 1, 1);
num_neurons_by_group = zeros(length(group_arr) - 1, 1);

low_idx = group_arr(9) + 1;
high_idx = group_arr(9 + 1);
group_fires_by_neuron = total_fires_by_neuron(low_idx:high_idx) / time * 1000;

figure
[~,edges] = histcounts(log10(group_fires_by_neuron));
histogram(group_fires_by_neuron, 10.^edges)
% histogram(group_fires_by_neuron);
set(gca, 'xscale','log')
set(gca,'box','off')
title("Firing Rate Histogram of Pyrmidal Neurons in L5 projecting to L2/3");
xlabel("Firing Rate Bins");
ylabel("Number of Neurons");
set(gca, 'FontSize', 14)
