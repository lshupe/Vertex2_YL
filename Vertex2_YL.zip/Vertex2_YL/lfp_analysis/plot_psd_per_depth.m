%% 
res = loadResults('~/vertex_results/random_con_scale_1');

%%
% TP = Results.params.TissueParams;
% time = Results.params.SimulationSettings.simulationTime;
% 
% x_poses = Results.params.RecordingSettings.meaXpositions;
% y_poses = Results.params.RecordingSettings.meaYpositions;
z_poses = res.params.RecordingSettings.meaZpositions;
sample_rate = res.params.RecordingSettings.sampleRate;
% num_electrodes = Results.params.RecordingSettings.numElectrodes;

% Get the middle record of each
record_indexes = 5:9:54;
t = tiledlayout(2,3);
title(t, "PSD of center electrode at different depths Z");
xlabel(t, "Frequency (Hz)");
ylabel(t, "Power/frequency (dB/Hz)");

for i = record_indexes
    nexttile
    z = z_poses(i);
    pwelch(res.LFP(i, :), [], [], [], sample_rate);
    xlabel('')
    ylabel('')
    title(sprintf('z = %d', z))
end
hold off