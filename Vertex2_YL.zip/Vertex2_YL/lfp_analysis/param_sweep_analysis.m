
% Set driving current scaling of default params
std_scalars = 1:0.25:2;
mean_scalars = 0.5:0.25:1.5;
[x, y] = meshgrid(std_scalars, mean_scalars);
scalar_coords = [x(:), y(:)];
for idx = 1:24
    std_scalar = scalar_coords(idx, 1);
    mean_scalar = scalar_coords(idx, 2);
    std_str = num2str(std_scalar);
    mean_str = num2str(mean_scalar);
    disp(strcat("Analysis for std: ", std_str, " mean: ", mean_str));
    std_file = strrep(std_str, '.', 'p');
    mean_file = strrep(mean_str, '.', 'p');
    dir = strcat('~/vertex_results/', std_file, 'std_', ...
        mean_file, 'mean_2500');
    disp(strcat("Loading results from ", dir));
    Results = loadResults(dir);
    spike_stats(Results, dir, true);
    %%
    % Compute PSD curve
    pwelch(Results.LFP(5, :), [], [], [], 1000)
    file_name = strcat(dir, '/lfp_power_dens_1250_1250');
    savefig(strcat(file_name, '.fig'))
    saveas(gcf, strcat(file_name, '.png'))
end
