function [] = plot_lfp_signals(input_dir, output_dir, should_save)
%PLOT_LFP_SIGNALS Function that reads the result of a vertex simulation
% and generates plots for LFP data
%%
% Load the simulation results
disp(strcat("Loading results from ", input_dir));
Results = loadResults(input_dir);

TP = Results.params.TissueParams;
time = Results.params.SimulationSettings.simulationTime;
%%
figure(1)
plot(Results.spikes(:, 2), Results.spikes(:, 1), 'k.')
top_axis = ceil(TP.X * TP.Y * TP.Z * TP.neuronDensity / (500 * 1e9)) * 500; 
axis([0 time -50 top_axis])
set(gcf,'color','w');
set(gca,'YDir','reverse');
set(gca,'FontSize',16)
title('Spike raster for Small BSF Simulation', 'FontSize', 16)
xlabel('Time (ms)', 'FontSize', 16)
ylabel('Neuron ID', 'FontSize', 16)
if should_save  
    savefig(strcat(output_dir, '/raster.fig'))
    saveas(gcf, strcat(output_dir, '/raster.png'))
end

x_poses = Results.params.RecordingSettings.meaXpositions;
y_poses = Results.params.RecordingSettings.meaYpositions;
sample_rate = Results.params.RecordingSettings.sampleRate;
num_electrodes = Results.params.RecordingSettings.numElectrodes;
%%
for i = 1:num_electrodes
    x_str = num2str(x_poses(i));
    y_str = num2str(y_poses(i));
    %%
    % Plot and save LFP signal
    % first figure index
    figure(3 * i)
    title_str = strcat('LFP at electrode ', i, ': (', x_str, ', ', y_str, ')');
    plot(Results.LFP(i, :), 'LineWidth', 2)
    set(gcf,'color','w');
    set(gca,'FontSize',16)
    title(title_str, 'FontSize', 16)
    xlabel('Frequency (Hz)', 'FontSize', 16)
    ylabel('LFP (mV)', 'FontSize', 16)
    file_name = strcat(output_dir, '/lfp_', x_str, '_', y_str);
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    %%
    % Plot and save Average Power vs. Frequency
    figure(3 * i + 1)
    pwelch(Results.LFP(i, :), [], [], [], sample_rate)
    file_name = strcat(output_dir, '/lfp_power_dens_', x_str, '_', y_str);
    if should_save
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
    %%
    % Plot and save LFP Spectrogram
    figure(3 * i + 2)
    spectrogram(Results.LFP(i, :), [], [], [], sample_rate,'yaxis')
    xlabel('Time (ms)', 'FontSize', 16)
    title_str = strcat('Spectrogram of LFP at electrode ', i, ': (', x_str, ', ', y_str, ')');
    title(title_str, 'FontSize', 16)
    file_name = strcat(output_dir, '/lfp_spectro_', x_str, '_', y_str);
    if should_save 
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
end
end

