classdef GroundTruthType
   enumeration
      All, AllVoltageCalculated, E, I
   end
end