function [ground_truth_matrix] = voltage_calc_ground_truths(results)
    % Ensure results has voltage values, calculated with nsg_main
    ground_truth_matrix_i = load('./vertex_results/ground_truth_i.mat').ground_truth_matrix;
    ground_truth_matrix_e = load('./vertex_results/ground_truth_e.mat').ground_truth_matrix;

    if isempty(results)
        results = loadResults('./vertex_results');
    end

    mean_voltages = mean(results.v_m, 2);

    %e_neuron_calc_matrix = zeros(size(ground_truth_matrix_i));
    % inhibitory calculations
    % inhibitory ground truth, post synaptic neurons (columns) * (mean
    % voltages - 75)
    for i=1:size(ground_truth_matrix_i,1)
        for j = 1: size(ground_truth_matrix_i,2)
            ground_truth_matrix_i(i,j) = ground_truth_matrix_i(i,j) * (mean_voltages(j) - 75);
            %mean_voltages(fix((i-1)/100) + 1);
        end
    end

    % excitatory calculations
    % excitator ground truth, post synaptic neurons (columns) * mean voltages
    for i=1:size(ground_truth_matrix_e,1)
        for j = 1: size(ground_truth_matrix_e,2)
            ground_truth_matrix_e(i,j) = ground_truth_matrix_e(i,j) * mean_voltages(j);
            %mean_voltages(fix((i-1)/100) + 1);
        end
    end

    % add resultings matrices together
    % make excitatory positive
    ground_truth_matrix_e = ground_truth_matrix_e*-1;
    ground_truth_matrix = (ground_truth_matrix_e + ground_truth_matrix_i);

    % get coherence metrics values and plots using properly calculated ground
    % truth matrix (use other functions, saving here for use there)
    % SPECIFY OUTPUT DIRECTORY HERE
    if ~exist('vertex_results', 'dir')
        mkdir('vertex_results');
    end
    save_path = 'vertex_results/ground_truth_all_voltage_calculated.mat';
    save(save_path, 'ground_truth_matrix', '-v7.3');
end