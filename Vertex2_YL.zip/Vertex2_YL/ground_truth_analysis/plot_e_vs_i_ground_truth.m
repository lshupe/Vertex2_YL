% plot relationship betweek excitatory and inhibitory ground truth

ground_truth_i = load('./vertex_results/ground_truth_i.mat').ground_truth_matrix;
ground_truth_e = load('./vertex_results/ground_truth_e.mat').ground_truth_matrix;
ground_truth_ei = load('./vertex_results/ground_truth_all_voltage_calculated.mat').ground_truth_matrix;

ground_truth_i(logical(eye(size(ground_truth_i)))) = [];
ground_truth_i = rmmissing(ground_truth_i);

ground_truth_e(logical(eye(size(ground_truth_e)))) = [];
ground_truth_e = rmmissing(ground_truth_e);

ground_truth_ei(logical(eye(size(ground_truth_ei)))) = [];
ground_truth_ei = rmmissing(ground_truth_ei);

scatter(ground_truth_e, ground_truth_i)