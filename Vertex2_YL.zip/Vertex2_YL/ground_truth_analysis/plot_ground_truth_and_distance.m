% if distance matrix exists, use it, otherwise calculate it 
% groud truth matrix will need to be calculated using
% nsg_calc_ground_truth_(all/e/i).m in NSG
distance_matrix = struct([]);

if isfile('./vertex_results/distance_matrix.mat')
    distance_matrix = load('./vertex_results/distance_matrix.mat').distance_matrix;
end

if isempty(distance_matrix)
    create_distance_matrix();
    distance_matrix = load('./vertex_results/distance_matrix.mat').distance_matrix;
end
ground_truth_matrix = load('./vertex_results/ground_truth_all.mat').ground_truth_matrix;

% Flatten matrices, distance is symetric (two trianlges - only need one),
% ground truth is not
% TODO: potentially remove 0's from resulting triu matrix (not needed),
% leave 1 maybe
top_distance_matrix = triu(distance_matrix);
distance_vector = reshape(top_distance_matrix, [1,54*54]);
ground_truth_vector = reshape(ground_truth_matrix, [1,54*54]);

scatter(distance_vector, ground_truth_vector);
grid on
set(gca,'box','on')
title("Ground truth vs distance");
xlabel("Distance");
ylabel("Ground Truth (anatomical connectivity)");

