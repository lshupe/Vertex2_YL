for radius = [100 500 900 1300 3000]
    for neuron_type = ["i" "e" "all"]
        var_name = sprintf('ground_truth_%s_%i', neuron_type, radius);
        path = sprintf('~/vertex_results/random_con_scale_1_40s/%s', var_name);
        eval([var_name, ' = load(path)']);
    end
end