%params = load_params_from_dir('~/vertex_results/random_con_long');
params = load_params_from_dir('./vertex_results');

rs = params.RecordingSettings;
len = length(rs.meaXpositions);
distance_matrix = zeros(len, len);
for i = 1:len
    for j = 1:len
        distance_matrix(i, j) = sqrt(...
            (rs.meaXpositions(i) - rs.meaXpositions(j)) ^ 2 + ...
            (rs.meaYpositions(i) - rs.meaYpositions(j)) ^ 2 + ...
            (rs.meaZpositions(i) - rs.meaZpositions(j)) ^ 2);
    end
end

save_path = './vertex_results/distance_matrix.mat';
save(save_path, 'distance_matrix', '-v7.3');