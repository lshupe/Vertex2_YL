function [] = plot_conn_coh_per_freq(freq, groundTruthType)
    % Plot ground truth (anatomical connectivity vs coherence correlation
    % per frequency band, grouped by connectivity layers 1 - 6 (per coords
    % matrix in nsg main)
    % best fit line
    % accuracy of best fit line
    % per frequency band
    
    % if mean coherence matrix exists, use it, otherwise calculate it 
    % groud truth matrix will need to be calculated using
    % nsg_calc_ground_truth_(all/e/i).m in NSG
    mean_connectivity = struct([]);

    % Set to remove first layer connection (when first layer considered
    % more noise than good data)
    remove_layer_one = true;
    
    % Set cnnectivity type here. see ConnectivityType.m in lfp_connectivity
    % Ensure this matches connectivity type in
    connectivityType = ConnectivityType.PGranger;

    switch connectivityType
        case ConnectivityType.Coherence
            if isfile('./vertex_results/mean_coherence.mat')
                mean_connectivity = load('./vertex_results/mean_coherence.mat').mean_connectivity;
            end
            if isempty(mean_connectivity)
                evaluate_connectivity_frequency_bands(connectivityType);
                mean_connectivity = load('./vertex_results/mean_coherence.mat').mean_connectivity;
            end
        % case ConnectivityType.PCoherence
        case ConnectivityType.Granger
            if isfile('./vertex_results/mean_granger.mat')
                mean_connectivity = load('./vertex_results/mean_granger.mat').mean_connectivity;
            end
            if isempty(mean_connectivity)
                evaluate_connectivity_frequency_bands(connectivityType);
                mean_connectivity = load('./vertex_results/mean_granger.mat').mean_connectivity;
            end
        case ConnectivityType.PGranger
            if isfile('./vertex_results/mean_pgranger.mat')
                mean_connectivity = load('./vertex_results/mean_pgranger.mat').mean_connectivity;
            end
            if isempty(mean_connectivity)
                evaluate_connectivity_frequency_bands(connectivityType);
                mean_connectivity = load('./vertex_results/mean_pgranger.mat').mean_connectivity;
            end
    end

    if (groundTruthType == GroundTruthType.All)
        ground_truth = load('./vertex_results/ground_truth_all.mat').ground_truth_matrix;
    end
    if (groundTruthType == GroundTruthType.I)
        ground_truth = load('./vertex_results/ground_truth_i.mat').ground_truth_matrix;
    end
    if (groundTruthType == GroundTruthType.E)
        ground_truth = load('./vertex_results/ground_truth_e.mat').ground_truth_matrix;
    end
    if (groundTruthType == GroundTruthType.AllVoltageCalculated)
        ground_truth = load('./vertex_results/ground_truth_all_voltage_calculated.mat').ground_truth_matrix;
    end
    % In accordance with coords in NSG_main, make matrix of z values
    % 0-9=layer 1 ... 45-54=layer n, ensure this matches coords matrix
    row_layers_matrix = zeros(size(mean_connectivity.delta));
    col_layers_matrix = zeros(size(mean_connectivity.delta));
    for i = 1:size(mean_connectivity.delta, 1)
        for j = 1:size(mean_connectivity.delta, 2)
            % indexing needs to start at 1 but division needs to be at 0
            row_layers_matrix(i,j) = fix((i-1)/9) + 1;
            col_layers_matrix(i,j) = fix((j-1)/9) + 1;
            if remove_layer_one && (i <= 10 || j <= 10)
                mean_connectivity.delta(i,j) = nan;
                mean_connectivity.theta(i,j) = nan;
                mean_connectivity.alpha(i,j) = nan;
                mean_connectivity.beta(i,j) = nan;
                mean_connectivity.gamma(i,j) = nan;
                mean_connectivity.highGamma(i,j) = nan;
                ground_truth(i,j) = nan;
                %if row_layers_matrix(i,j) == 1
                row_layers_matrix(i,j) = nan;
                %end
                %if col_layers_matrix(i,j) == 1
                col_layers_matrix(i,j) = nan;
                %end
                continue;
            end
        end
    end
    
    
    % Flatten matrices and remove diagnol values
    ground_truth(logical(eye(size(ground_truth)))) = [];
    mean_connectivity.delta(logical(eye(size(mean_connectivity.delta)))) = [];
    mean_connectivity.theta(logical(eye(size(mean_connectivity.theta)))) = [];
    mean_connectivity.alpha(logical(eye(size(mean_connectivity.alpha)))) = [];
    mean_connectivity.beta(logical(eye(size(mean_connectivity.beta)))) = [];
    mean_connectivity.gamma(logical(eye(size(mean_connectivity.gamma)))) = [];
    mean_connectivity.highGamma(logical(eye(size(mean_connectivity.highGamma)))) = [];
    % Flatten layer matrices
    row_layers_matrix(logical(eye(size(row_layers_matrix)))) = [];
    col_layers_matrix(logical(eye(size(col_layers_matrix)))) = [];
    
    % remove nan values set above once matrix converted to array
    mean_connectivity.delta = rmmissing(mean_connectivity.delta);
    mean_connectivity.theta = rmmissing(mean_connectivity.theta);
    mean_connectivity.alpha = rmmissing(mean_connectivity.alpha);
    mean_connectivity.beta = rmmissing(mean_connectivity.beta);
    mean_connectivity.gamma = rmmissing(mean_connectivity.gamma);
    mean_connectivity.highGamma = rmmissing(mean_connectivity.highGamma);
    ground_truth = rmmissing(ground_truth);
    row_layers_matrix = rmmissing(row_layers_matrix);
    col_layers_matrix = rmmissing(col_layers_matrix);

    % Delta
    if freq == "delta" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.delta,ground_truth, 1);
        f = polyval(p,mean_connectivity.delta); 
        plot(mean_connectivity.delta,ground_truth,'.',mean_connectivity.delta,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.delta,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("Delta Frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");

        figure();
        gscatter(mean_connectivity.delta, ground_truth, row_layers_matrix, 'rgbkmy', '.',10);
        grid on;
        title("Delta Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.delta, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Delta Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
    
    % Theta
    if freq == "theta" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.theta,ground_truth, 1);
        f = polyval(p,mean_connectivity.theta); 
        plot(mean_connectivity.theta,ground_truth,'.',mean_connectivity.theta,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.theta,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("Theta frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");

        figure();
        gscatter(mean_connectivity.theta, ground_truth, row_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Theta Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.theta, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Theta Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
    
    % Alpha
    if freq == "alpha" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.alpha,ground_truth, 1);
        f = polyval(p,mean_connectivity.alpha); 
        plot(mean_connectivity.alpha,ground_truth,'.',mean_connectivity.alpha,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.alpha,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("Alpha frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");

        figure();
        gscatter(mean_connectivity.alpha, ground_truth, row_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Alpha Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.alpha, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Alpha Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
    
    % Beta
    if freq == "beta" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.beta,ground_truth, 1);
        f = polyval(p,mean_connectivity.beta); 
        plot(mean_connectivity.beta,ground_truth,'.',mean_connectivity.beta,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.beta,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("Beta frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");

        figure();
        gscatter(mean_connectivity.beta, ground_truth, row_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Beta Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.beta, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Beta Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
    
    % Gamma
    if freq == "gamma" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.gamma,ground_truth, 1);
        f = polyval(p,mean_connectivity.gamma); 
        plot(mean_connectivity.gamma,ground_truth,'.',mean_connectivity.gamma,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.gamma,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("Gamma frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        
        figure();
        gscatter(mean_connectivity.gamma, ground_truth, row_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Gamma Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.gamma, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("Gamma Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
    
    % High Gamma
    if freq == "highGamma" || freq == "all"
        figure();
        p = polyfit(mean_connectivity.highGamma,ground_truth, 1);
        f = polyval(p,mean_connectivity.highGamma); 
        plot(mean_connectivity.highGamma,ground_truth,'.',mean_connectivity.highGamma,f,'-');
        % fit linear regressions model
        mdl = fitlm(mean_connectivity.highGamma,ground_truth);
        rsquared = mdl.Rsquared.Ordinary;
        
        legend('data','linear best fit');
        grid on;
        title("High gamma frequency, r =" + rsquared);
        xlabel("Mean Coherence");
        ylabel("Ground Truth");

        figure();
        gscatter(mean_connectivity.highGamma, ground_truth, row_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("High Gamma Frequency, rows");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
        figure();
        gscatter(mean_connectivity.highGamma, ground_truth, col_layers_matrix, 'rgbkmy', '.', 10);
        grid on;
        title("High Gamma Frequency, columns");
        xlabel("Mean Coherence");
        ylabel("Ground Truth");
    end
end