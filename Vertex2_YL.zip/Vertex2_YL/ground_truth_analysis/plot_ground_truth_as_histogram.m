% load ground truth
% ground_truth_res = load('~/vertex_results/random_con_scale_1_40s/ground_truth_all_900.mat');
ground_truth_res = load('./vertex_results/ground_truth_all.mat');
%ground_truth_matrix = ground_truth_res.res;
m = max(ground_truth_matrix,[],'all');
normed = ground_truth_matrix ./ m;
% normed(normed==0) = [];
disp(std(normed, 0, 'all'));
edges = 0:0.01:1;
histogram(normed, edges)
grid off
set(gca,'box','off')
title("All Anatomical Connectivity Histogram");
ylabel("Number of Pairings");
xlabel("Normalized Connectivity Weight in 0.01 Sized Bins")