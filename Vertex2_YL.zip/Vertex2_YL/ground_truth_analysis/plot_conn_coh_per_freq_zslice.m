function [] = plot_conn_coh_per_freq_zslice(freq, connectivityType, groundTruthType, LFP, save_dir)

    if ~exist('save_dir','var')
        save_plots = false;
    else
        save_plots = true;
    end
    
    %% load anatomical connectivity
    if (groundTruthType == GroundTruthType.All)
        ground_truth = load('./vertex_results/ground_truth_all.mat').ground_truth_matrix;
    elseif (groundTruthType == GroundTruthType.I)
        ground_truth = load('./vertex_results/ground_truth_i.mat').ground_truth_matrix;
    elseif (groundTruthType == GroundTruthType.E)
        ground_truth = load('./vertex_results/ground_truth_e.mat').ground_truth_matrix;
    elseif(groundTruthType == GroundTruthType.AllVoltageCalculated)
        ground_truth = load('./vertex_results/ground_truth_all_voltage_calculated.mat').ground_truth_matrix;
    end
    
    %% prep variables for plot looping
    cmap = parula(6);
    delta_legend = cell(5,1);
    delta_plots = [];
    theta_legend = cell(5,1);
    theta_plots = [];
    alpha_legend = cell(5,1);
    alpha_plots = [];
    beta_legend = cell(5,1);
    beta_plots = [];
    gamma_legend = cell(5,1);
    gamma_plots = [];
    highGamma_legend = cell(5,1);
    highGamma_plots = [];
    
    %% loop through z slice indices
    for z_slice_index = 2:6
        %% grab relevant rows and columns from  both matrices
        z_slice_LFP = LFP(z_slice_index*9-8:z_slice_index*9, :);
        z_slice_ground_truth = ground_truth(z_slice_index*9-8:z_slice_index*9, z_slice_index*9-8:z_slice_index*9);

        %% run the matrix through the functional connectivity pipeline
        mean_connectivity = evaluate_connectivity_frequency_bands_JB(connectivityType, z_slice_LFP);

        %% plot the functional connectivity vs the anatomical connectivity

        % Flatten matrices and remove diagonal values
        z_slice_ground_truth(logical(eye(size(z_slice_ground_truth)))) = [];
        mean_connectivity.delta(logical(eye(size(mean_connectivity.delta)))) = [];
        mean_connectivity.theta(logical(eye(size(mean_connectivity.theta)))) = [];
        mean_connectivity.alpha(logical(eye(size(mean_connectivity.alpha)))) = [];
        mean_connectivity.beta(logical(eye(size(mean_connectivity.beta)))) = [];
        mean_connectivity.gamma(logical(eye(size(mean_connectivity.gamma)))) = [];
        mean_connectivity.highGamma(logical(eye(size(mean_connectivity.highGamma)))) = [];

        % remove nan values set above once matrix converted to array
        mean_connectivity.delta = rmmissing(mean_connectivity.delta);
        mean_connectivity.theta = rmmissing(mean_connectivity.theta);
        mean_connectivity.alpha = rmmissing(mean_connectivity.alpha);
        mean_connectivity.beta = rmmissing(mean_connectivity.beta);
        mean_connectivity.gamma = rmmissing(mean_connectivity.gamma);
        mean_connectivity.highGamma = rmmissing(mean_connectivity.highGamma);
        z_slice_ground_truth = rmmissing(z_slice_ground_truth);
    
        % Delta
        if freq == "delta" || freq == "all"
            figure(1);
            
            % fit model
            p = polyfit(mean_connectivity.delta,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.delta); 
            scatter(mean_connectivity.delta,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.delta,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            delta_plots = [delta_plots, p];
            r = corrcoef(mean_connectivity.delta, z_slice_ground_truth);
            delta_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("Delta FC");
            ylabel("Ground Truth");

        end

        % Theta
        if freq == "theta" || freq == "all"
            figure(2);

            % fit model
            p = polyfit(mean_connectivity.theta,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.theta); 
            scatter(mean_connectivity.theta,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.theta,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            theta_plots = [theta_plots, p];
            r = corrcoef(mean_connectivity.theta, z_slice_ground_truth);
            theta_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("Theta FC");
            ylabel("Ground Truth");
            
        end

        % Alpha
        if freq == "alpha" || freq == "all"
            figure(3);

            % fit model
            p = polyfit(mean_connectivity.alpha,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.alpha); 
            scatter(mean_connectivity.alpha,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.alpha,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            alpha_plots = [alpha_plots, p];
            r = corrcoef(mean_connectivity.alpha, z_slice_ground_truth);
            alpha_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("Alpha FC");
            ylabel("Ground Truth");
            
        end

        % Beta
        if freq == "beta" || freq == "all"
            figure(4);

            % fit model
            p = polyfit(mean_connectivity.beta,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.beta); 
            scatter(mean_connectivity.beta,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.beta,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            beta_plots = [beta_plots, p];
            r = corrcoef(mean_connectivity.beta, z_slice_ground_truth);
            beta_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("Beta FC");
            ylabel("Ground Truth");
            
        end

        % Gamma
        if freq == "gamma" || freq == "all"
            figure(5);

            % fit model
            p = polyfit(mean_connectivity.gamma,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.gamma); 
            scatter(mean_connectivity.gamma,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.gamma,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            gamma_plots = [gamma_plots, p];
            r = corrcoef(mean_connectivity.gamma, z_slice_ground_truth);
            gamma_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("Gamma FC");
            ylabel("Ground Truth");
            
        end

        % High Gamma
        if freq == "highGamma" || freq == "all"
            figure(6);

            % fit model
            p = polyfit(mean_connectivity.highGamma,z_slice_ground_truth, 1);
            f = polyval(p,mean_connectivity.highGamma); 
            scatter(mean_connectivity.highGamma,z_slice_ground_truth,'.', 'MarkerEdgeColor', cmap(z_slice_index-1, :));
            hold on;
            p = plot(mean_connectivity.highGamma,f,'-', 'Color',  cmap(z_slice_index-1, :));
            
            highGamma_plots = [highGamma_plots, p];
            r = corrcoef(mean_connectivity.highGamma, z_slice_ground_truth);
            highGamma_legend{z_slice_index-1}=num2str(r(1,2)) ;

            xlabel("High Gamma FC");
            ylabel("Ground Truth");
            
        end
    end
    if freq == "delta" || freq == "all"
        figure(1)
        legend(delta_plots, delta_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "delta.pdf"))
        end
    end
    if freq == "theta" || freq == "all"
        figure(2)
        legend(theta_plots, theta_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "theta.pdf"))
        end
    end
    if freq == "alpha" || freq == "all"
        figure(3)
        legend(alpha_plots, alpha_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "alpha.pdf"))
        end
    end
    if freq == "beta" || freq == "all"
        figure(4)
        legend(beta_plots, beta_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "beta.pdf"))
        end
    end
    if freq == "gamma" || freq == "all"
        figure(5)
        legend(gamma_plots,gamma_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "gamma.pdf"))
        end
    end
    if freq == "highGamma" || freq == "all"
        figure(6)
        legend(highGamma_plots, highGamma_legend);
        if save_plots
            saveas(gcf, fullfile(save_dir, "hgamma.pdf"))
        end
    end


end