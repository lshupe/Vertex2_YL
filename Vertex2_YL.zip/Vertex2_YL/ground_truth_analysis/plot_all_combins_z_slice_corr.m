folder_super = "G:\.shortcut-targets-by-id\1kmRoMepS1x8yiLKacknTHrYa5X3DvFi2\Vertex Project\figures";
folder_prefix = "fc_gt_";

connectivity_types = [ConnectivityType.Coherence, ConnectivityType.Granger, ConnectivityType.PGranger];
folder_suffixes = ["coh", "granger", "pgranger"];

ground_truth_types = [GroundTruthType.E, GroundTruthType.I];
folder_mids = ["e_z_", "i_z_"];

for connectivity_type_i=1:size(connectivity_types, 2)
    connectivity_type = connectivity_types(connectivity_type_i)
    folder_suffix = folder_suffixes(connectivity_type_i);

    for ground_truth_type_i=1:size(ground_truth_types, 2)
        ground_truth_type = ground_truth_types(ground_truth_type_i)
        folder_mid = folder_mids(ground_truth_type_i);
        full_folder = fullfile(folder_super, strcat(folder_prefix, folder_mid, folder_suffix));

        if ~exist(full_folder, 'dir')
            mkdir(full_folder);    
        end

        plot_conn_coh_per_freq_zslice('all', connectivity_type, ground_truth_type, r.LFP, full_folder)
        
        close all
    end
end


