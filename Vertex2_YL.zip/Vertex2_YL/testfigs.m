function testfigs(results_directory)
addpath(genpath(pwd));
if nargin >= 1
    directory = results_directory;
else
    directory = './vertex_results';
end
close_flag = false; % Whether of not to close figures once saved.

%% Load previously saved results.  For most of these simulations, this is
% saved parameters, spikes, and LFP.  Weights and synapses are stored in
% separate files.

Results = loadResults(directory);

%% Plot the results
% Using these parameters, we obtain the following spike raster:

rasterParams.colors = {'k','m','k','m','k','m'};
rasterParams.groupBoundaryLines = 'c';
rasterParams.title = 'Spike Raster';
rasterParams.xlabel = 'Time (ms)';
rasterParams.ylabel = 'Neuron ID';
rasterParams.figureID = 1;
%rasterFigureImproved = plotSpikeRaster(Results, rasterParams);

%%
% Stimulation field plot needs work.
% figure;
% pdeplot3D(TissueParams.StimulationModel, 'ColorMap', TissueParams.StimulationField.NodalSolution, 'FaceAlpha', 0.8);
% % hold on;
% % pars.colors = rasterParams.colors;
% % plotSomaPositions(Results.params.TissueParams,pars);
% hold on;
% pdeplot3D(TissueParams.StimulationModel2, 'ColorMap', TissueParams.StimulationField2.NodalSolution, 'FaceAlpha', 0.8);
% hold on;
% pars.colors = rasterParams.colors;
% plotSomaPositions(Results.params.TissueParams,pars);
% 
[x1, x2] = bounds(Results.params.TissueParams.somaPositionMat(:, 1));
[y1, y2] = bounds(Results.params.TissueParams.somaPositionMat(:, 2));
[z1, z2] = bounds(Results.params.TissueParams.somaPositionMat(:, 3));
x1 = floor(x1); y1 = floor(y1); z1 = floor(z1);
x2 = ceil(x2); y2 = ceil(y2); z2 = ceil(z2);
% 
% xlim([x1 x2]);
% ylim([y1 y2]);
% zlim([z1 z2]);
% box on

%%
% Plotting the LFP around electrode2 during stimulation

sampleRate = Results.params.RecordingSettings.sampleRate;
simulationTime = Results.params.SimulationSettings.simulationTime;
timeStep = Results.params.SimulationSettings.timeStep;
hfig = figure;
hfig.Position = [20, 50, 800, 900];
%lfp_electrodes = [2 8 11 17 20 26 29 35 38 44 47 53]; % (Left, Center) and (Right, Center) recording locations
lfp_electrodes = [2 5 11 14 20 23 29 32 38 41 47 50]; % (Left, Center) and (Center, Center)

markers = '0+*x^vdsp';
colors =  'krgbcm';
if isempty(Results.events)
    stim_times = [];
    stim_ids = [];
else
    index = find([Results.events.marker] ~= '|');
    events = Results.events(index);
    stim_times = [events.time_ms];
    stim_ids = [events.id];
    color_ind = mod(ceil(stim_ids / length(markers)), length(colors)) + 1;
    stim_marker = mod(stim_ids, length(markers)) + 1;
end

ymeans = mean(Results.LFP(lfp_electrodes,:), 2);
yrange = 3 * max(std(Results.LFP(lfp_electrodes,:), 0, 2));
for i=1:length(lfp_electrodes)
    subplot(6,2, i);
    lfp = Results.LFP(lfp_electrodes(i),:);
    if (2 * sampleRate) > (1000 / timeStep)
        lfp = (lfp + [lfp(2:end) lfp(end)]) ./ 2; % smooth staircase caused by LFP sample rate near simulation sample rate
    end
    xaxis = (1:length(lfp)) * 1000 / sampleRate;
    plot(xaxis, lfp, 'LineWidth', 1);
    hold on;
    title(['LFP ' num2str(lfp_electrodes(i))]);
    for j=1:length(stim_times)
        plot(stim_times(j), ymeans(i), 'Marker', markers(stim_marker(j)), 'Color', colors(color_ind(j)));
    end
    ylim([ymeans(i)-yrange ymeans(i)+yrange]);
    %set(gcf,'color','w');
    %set(gca, 'FontSize', 16);
end
yscalefig([], hfig, (500:length(lfp)-500));
save_figure(directory, 'LFP', hfig, close_flag);


% Filtered LFP
%Results.params.TissueParams.LFP_filter_band = [20 30]; % Force filter band for testing purposes.
if isfield(Results.params.TissueParams, 'LFP_filter_band')
    hfig = figure;
    hfig.Position = [20, 50, 800, 900];
    filter_band = Results.params.TissueParams.LFP_filter_band; % Hz
    filter_order = 1;
    filter_pass = 'bandpass';
    [b, a] = butter(filter_order, filter_band * 2 / sampleRate, filter_pass);
    max_yrange = 0;
    for i=1:length(lfp_electrodes)
        subplot(6,2, i);
        lfp = Results.LFP(lfp_electrodes(i),:);
        lfp = lfp - mean(lfp); % Center raw LFP so it will overlap with filtered LFP
        yrange = 3 * std(lfp);
        max_yrange = max(max_yrange, yrange);
        plot((1:length(lfp)) * 1000 / sampleRate, lfp, 'LineWidth', 1);
        hold on;
        lfp = filter(b, a, lfp);
        plot((1:length(lfp)) * 1000 / sampleRate, lfp, 'LineWidth', 1);
        title(['fLFP ' num2str(lfp_electrodes(i))]);
        for j=1:length(stim_times)
            plot(stim_times(j), 0, 'Marker', markers(stim_marker(j)), 'Color', colors(color_ind(j)));
        end
        ylim([-yrange +yrange]);
        %set(gcf,'color','w');
        %set(gca, 'FontSize', 16);
    end
    yscalefig([], hfig, (500:length(lfp)-500));
    save_figure(directory, ['LFP_Filtered(' num2str(filter_band(1)) ',' num2str(filter_band(end)) ')'], hfig, close_flag);
end


% LFP stimulus responses
if isempty(stim_times)
    if isfield(Results.params.TissueParams, 'stim_ms')
        stim_ms = Results.params.TissueParams.stim_ms;
        stim_times = stim_ms;
        stim_ids = ones(size(stim_times));
        stim_delay = Results.params.TissueParams.stim_delay_ms;
        stim_size = Results.params.TissueParams.stim_size;
    end
end
if ~isempty(stim_times)
    stim_indices = floor(stim_times * 1000 / sampleRate);
    time_range = [-50 150];  % X-axis in milliseconds
    bin_range = floor(time_range * 1000 / sampleRate);
    bin_index = (bin_range(1):bin_range(2))';
    base_index = find(bin_index < 0);
    peak_index = find(bin_index > 0, 100); % RMS over 100 ms
    xaxis = bin_index * sampleRate / 1000;
    todo = stim_ids;
    for i = 1:length(todo)
        if ~isnan(todo(i))
            id = todo(i);
            stim_list = find(todo == id);
            hfig = figure;
            hfig.Position = [20, 50, 800, 900];
            iplot = 1;
            maxp2p = 0; % Keep track of maximum peak to peak value.
            for ilfp = lfp_electrodes
                subplot(6,2, iplot);
                iplot = iplot + 1;
                lfp = Results.LFP(ilfp,:);
                N = 0;
                yaxis = zeros(size(bin_index));
                for istim = stim_list
                    index = bin_index + stim_indices(istim);
                    if (index(1) >= 1) && (index(end) <= length(lfp))
                        yaxis = yaxis + lfp(index)';
                        N = N + 1;
                    end
                end
                if (N > 1)
                    yaxis = yaxis / N;
                end
                plot(xaxis', yaxis');
                title(['Stim ' num2str(id) ' -> LFP ' num2str(ilfp) ' (n = ' num2str(N) ')']);
                peak2peak = max(yaxis(peak_index)) - min(yaxis(peak_index));
                maxp2p = max(maxp2p, peak2peak);
                rmsval = sqrt(sum((yaxis(peak_index) - mean(yaxis(base_index))) .^2) / length(peak_index));
                xlim(time_range);
                xlabel(['ms (RMS 0-100ms = ' num2str(rmsval) ', P2P = ' num2str(peak2peak) ')']);
            end
            yscalefig([], hfig);
            save_figure(directory, ['STA_Stim' num2str(id) '_to_LFP'], hfig, close_flag);
            todo(stim_list) = nan; % mark these stims as done
        end
    end
end

% LFP stimulus responses with baselines subtracted. This can make it 
% easier to compare plots with differing scales and offsets.
if ~isempty(stim_times)
    stim_indices = floor(stim_times * 1000 / sampleRate);
    time_range = [-50 150];  % X-axis in milliseconds
    bin_range = floor(time_range * 1000 / sampleRate);
    bin_index = (bin_range(1):bin_range(2))';
    base_index = find(bin_index < 0);
    peak_index = find(bin_index > 0, 100); % RMS over 100 ms
    xaxis = bin_index * sampleRate / 1000;
    todo = stim_ids;
    for i = 1:length(todo)
        if ~isnan(todo(i))
            id = todo(i);
            stim_list = find(todo == id);
            hfig = figure;
            hfig.Position = [20, 50, 800, 900];
            iplot = 1;
            maxp2p = 0; % Keep track of maximum peak to peak value.
            for ilfp = lfp_electrodes
                subplot(6,2, iplot);
                iplot = iplot + 1;
                lfp = Results.LFP(ilfp,:);
                N = 0;
                yaxis = zeros(size(bin_index));
                for istim = stim_list
                    index = bin_index + stim_indices(istim);
                    if (index(1) >= 1) && (index(end) <= length(lfp))
                        yaxis = yaxis + lfp(index)';
                        N = N + 1;
                    end
                end
                if (N >= 1)
                    yaxis = (yaxis - mean(yaxis(base_index))) / N; % remove baseline
                end
                plot(xaxis', yaxis');
                title(['Stim ' num2str(id) ' -> LFP' num2str(ilfp) '-baseline (n = ' num2str(N) ')']);
                peak2peak = max(yaxis(peak_index)) - min(yaxis(peak_index));
                maxp2p = max(maxp2p, peak2peak);
                rmsval = sqrt(sum((yaxis(peak_index) - mean(yaxis(base_index))) .^2) / length(peak_index));
                xlim(time_range);
                xlabel(['ms (RMS 0-100ms = ' num2str(rmsval) ', P2P = ' num2str(peak2peak) ')']);
            end
            yscalefig([], hfig);
            save_figure(directory, ['STA_Stim' num2str(id) '_to_LFP-baseline'], hfig, close_flag);
            todo(stim_list) = nan; % mark these stims as done
        end
    end
end

% LFP Stimulus Response for first and last 3rd of stim_times
% for any simulations with plasticity (STDP) enabled
if ~isempty(stim_times) && Results.params.SimulationSettings.stdp
    stim_indices = floor(stim_times * 1000 / sampleRate);
    time_range = [-50 150];  % X-axis in milliseconds
    bin_range = floor(time_range * 1000 / sampleRate);
    bin_index = (bin_range(1):bin_range(2))';
    base_index = find(bin_index < 0);
    peak_index = find(bin_index > 0, 100); % RMS over 100 ms
    xaxis = bin_index * sampleRate / 1000;
    todo = stim_ids;
    for i = 1:length(todo)
        if ~isnan(todo(i))
            id = todo(i);
            stim_list = find(todo == id);
            hfig = figure;
            hfig.Position = [20, 50, 800, 900];
            iplot = 1;
            for ilfp = lfp_electrodes
                subplot(6,2, iplot);
                iplot = iplot + 1;
                lfp = Results.LFP(ilfp,:);

                N = 0;
                yaxis = zeros(size(bin_index));
                nstims3 = ceil(length(stim_list) / 3);
                stim_list_first_3rd = stim_list(1:nstims3);
                for istim = stim_list_first_3rd
                    index = bin_index + stim_indices(istim);
                    if (index(1) >= 1) && (index(end) <= length(lfp))
                        yaxis = yaxis + lfp(index)';
                        N = N + 1;
                    end
                end
                if (N > 1)
                    yaxis = yaxis / N;
                end
                plot(xaxis', yaxis');
                hold on;
                peak2peak = max(yaxis(peak_index)) - min(yaxis(peak_index));
                rmsval = sqrt(sum((yaxis(peak_index) - mean(yaxis(base_index))) .^2) / length(peak_index));
                N1 = N;

                N = 0;
                yaxis = zeros(size(bin_index));
                stim_list_last_3rd = stim_list(end-nstims3+1:end);
                for istim = stim_list_last_3rd
                    index = bin_index + stim_indices(istim);
                    if (index(1) >= 1) && (index(end) <= length(lfp))
                        yaxis = yaxis + lfp(index)';
                        N = N + 1;
                    end
                end
                if (N > 1)
                    yaxis = yaxis / N;
                end
                plot(xaxis', yaxis');

                legend({'First 3rd', 'Last 3rd'});
                title(['Stim ' num2str(id) ' -> LFP' num2str(ilfp) ' (n = ' num2str(N1) ' First 3rd, ' num2str(N) ' Last 3rd)']);
                peak2peak3 = max(yaxis(peak_index)) - min(yaxis(peak_index));
                rmsval3 = sqrt(sum((yaxis(peak_index) - mean(yaxis(base_index))) .^2) / length(peak_index));
                xlim(time_range);
                xlabel(['ms (RMS ' num2str(rmsval) ', ' num2str(rmsval3) '; P2P ' num2str(peak2peak) ', ' num2str(peak2peak3) ')']);
            end
            yscalefig([], hfig);
            save_figure(directory, ['STA_Stim' num2str(id) '_to_LFP_thirds'], hfig, close_flag);
            todo(stim_list) = nan; % mark these stims as done
        end
    end
end

% LFP power spectrum
hfig = figure;
periodogram(Results.LFP', hamming(length(lfp)), 1024, sampleRate); % LFP power spectrum
save_figure(directory, 'PSD', hfig, close_flag);

%%
% Plot the weight changes

disp('Loading synapse array...');
syn_arr = loadResultsSynapseFile(directory, 'synapses_');

% disp('Loading first weights array...');
% time1weights = [];
% weights_arr = loadResultsWeightFile(directory, 'weights1_');
% if ~isempty(weights_arr)
%     time1weights = getSparseConnectivityWeights(weights_arr, syn_arr, Results.params.TissueParams.N);
%     clear weights_arr;
% end
% 
% disp('Loading second weights array...');
% time2weights = [];
% weights_arr = loadResultsWeightFile(directory, 'weights2_');
% if ~isempty(weights_arr)
%     time2weights = getSparseConnectivityWeights(weights_arr, syn_arr, Results.params.TissueParams.N);
%     clear weights_arr;
% end   
% 
% wchange = [];
% if ~isempty(time1weights) && ~isempty(time2weights)
%     wchange = time2weights - time1weights;
% end
% 
% if ~isempty(wchange) && isfield(Results.params.TissueParams, 'stim_ms')
%     % Plot weight change spatially
%     % Mean non-zero weight changes for post synaptic units
%     sum_wchange = sum(wchange,2);
%     ns = sum(wchange ~= 0, 2); 
%     for i = 1:length(sum_wchange)
%         if ns(i) > 0
%             sum_wchange(i) = sum_wchange(i) / ns(i);
%         end
%     end
%     pars.toPlot = find(abs(sum_wchange) >= 2 * std(sum_wchange)); % Plot cells with larger than average synaptic changes
%     plotSomaPositionsMembranePotential(Results.params.TissueParams, sum_wchange(pars.toPlot), pars);
%     xlim([x1 x2]);
%     ylim([y1 y2]);
%     zlim([z1 z2]);
%     box on;
%     title('Units with significant incoming weight changes');
%     save_figure(directory, 'weight_changes_post_soma_pos', gcf, close_flag);
% 
%     %pars.toPlot = 1:1:Results.params.TissueParams.N;  % Consider all cells
%     sum_wchange = sum_wchange(pars.toPlot);
%     x_elect1 = mean(Results.params.TissueParams.stim_electrode_xpos(1,1:2));
%     z_elect1 = mean(Results.params.TissueParams.stim_electrode_zpos(1,1:2));
%     % drawcircle('Center', [x_elect1, cathode_tip_position(2)], 'Radius', 100, 'Color', 'Blue');
%     x_elect2 = mean(Results.params.TissueParams.stim_electrode_xpos(2,1:2));
%     z_elect2 = mean(Results.params.TissueParams.stim_electrode_zpos(2,1:2));
%     % drawcircle('Center', [x_elect2, cathode_tip_position(2) + electrode2_offset(2)], 'Radius', 100, 'Color', 'Red');
%     x_somas = Results.params.TissueParams.somaPositionMat(pars.toPlot, 1);
%     z_somas = Results.params.TissueParams.somaPositionMat(pars.toPlot, 3);
% 
%     disp(['Paired pulse delay (ms): ' num2str(Results.params.TissueParams.stim_delay_ms)]);
% 
%     % Average weight change to units with significant weight changes in Site1 and Site2
%     wchange_at_elect1 = sum_wchange(abs(x_somas - x_elect1) < 100 & abs(z_somas - z_elect1) < 100);
%     wchange_at_elect2 = sum_wchange(abs(x_somas - x_elect2) < 100 & abs(z_somas - z_elect2) < 100);
%     disp(['Weight changes for units with significant weight changes near stim1: ' num2str(mean(wchange_at_elect1)) ' (n_units = ' num2str(length(wchange_at_elect1)) ')']);
%     disp(['Weight changes for units with significant weight changes near stim2: ' num2str(mean(wchange_at_elect2)) ' (n_units = ' num2str(length(wchange_at_elect2)) ')']);
%     disp('');
% 
%     % Find somas near Site 1 and Site 2.
%     x_somas = Results.params.TissueParams.somaPositionMat(:, 1);
%     z_somas = Results.params.TissueParams.somaPositionMat(:, 3);
%     somas_at_elect1 = find((abs(x_somas - x_elect1)) < 100 & (abs(z_somas - z_elect1) < 100));
%     somas_at_elect2 = find((abs(x_somas - x_elect2)) < 100 & (abs(z_somas - z_elect2) < 100));
%     nsomas_at_elect1 = length(somas_at_elect1);
%     nsomas_at_elect2 = length(somas_at_elect2);
% 
%     % Calculate the mean weight changes for all weights near Site1 and Site2.
%     dwsite1 = 0; % Change in weights at Site1
%     nwsite1 = 0; % Number of weights at Site1
%     dwsite1abs = 0; % Absolute change in weights
%     dwnzsite1 = 0; % Change in non-zero weights
%     dwnzsite1abs = 0; % Absolute change in non-zero weights
%     nwnzsite1 = 0; % Number of non-zero weighs
%     for i = 1:nsomas_at_elect1 % Sum weights incoming to each soma near Site1
%         dw = wchange(somas_at_elect1(i), time1weights(somas_at_elect1(i), :) ~= 0);
%         dwsite1 = dwsite1 + sum(dw);
%         dwsite1abs = dwsite1abs + sum(abs(dw));
%         nwsite1 = nwsite1 + length(dw);
%         nwnzsite1 = nwnzsite1 + sum(dw ~= 0); % Number of non-zero weights 
%     end
%     if nwnzsite1 > 0
%         dwnzsite1 = dwsite1 / nwnzsite1;
%         dwnzsite1abs = dwsite1abs / nwnzsite1;
%     end
%     if nwsite1 > 0
%         dwsite1 = dwsite1 / nwsite1; % Mean
%         dwsite1abs = dwsite1abs / nwsite1;
%     end
%     disp(['Mean weight change near Site1: ' num2str(dwsite1) ' (n_weights = ' num2str(nwsite1) '), abs change: ' num2str(dwsite1abs)]);
%     disp(['Mean non-zero weight change near Site1: ' num2str(dwnzsite1) ' (n_nzweights = ' num2str(nwnzsite1) '), abs change: ' num2str(dwnzsite1abs)]);
%     disp('');
% 
%     dwsite2 = 0; % Change in weights at Site1
%     nwsite2 = 0; % Number of weights at Site1
%     dwsite2abs = 0; % Absolute change in weights
%     dwnzsite2 = 0; % Change in non-zero weights
%     dwnzsite2abs = 0; % Absolute change in non-zero weights
%     nwnzsite2 = 0; % Number of non-zero weighs
%     for i = 1:nsomas_at_elect2
%         dw = wchange(somas_at_elect2(i), time1weights(somas_at_elect2(i), :) ~= 0);
%         dwsite2 = dwsite2 + sum(dw);
%         dwsite2abs = dwsite2abs + sum(abs(dw));
%         nwsite2 = nwsite2 + length(dw);
%         nwnzsite2 = nwnzsite2 + sum(dw ~= 0); % Number of non-zero weights 
%     end
%     if nwnzsite2 > 0
%         dwnzsite2 = dwsite2 / nwnzsite2;
%         dwnzsite2abs = dwsite2abs / nwnzsite2;
%     end
%     if nwsite2 > 0
%         dwsite2 = dwsite2 / nwsite2;
%         dwsite2abs = dwsite2abs / nwsite2;
%     end
%     disp(['Mean weight change near Site2: ' num2str(dwsite2) ' (n_weights = ' num2str(nwsite2) '), abs change: ' num2str(dwsite2abs)]);
%     disp(['Mean non-zero weight change near Site2: ' num2str(dwnzsite2) ' (n_nzweights = ' num2str(nwnzsite2) '), abs change: ' num2str(dwnzsite2abs)]);
%     disp('');
% 
%     % Calculate the mean of weight changes for all weights
%     % connecting the two stimulation sites.
%     dw_Site1_to_Site2 = 0;
%     dwnz_Site1_to_Site2 = 0;
%     nw_Site1_to_Site2 = 0;
%     nwnz_Site1_to_Site2 = 0;
%     dw_Site2_to_Site1 = 0;
%     dwnz_Site2_to_Site1 = 0;
%     nw_Site2_to_Site1 = 0;
%     nwnz_Site2_to_Site1 = 0;
%     dwS1S2abs = 0;
%     dwS2S1abs = 0;
%     dwnzS1S2abs = 0;
%     dwnzS2S1abs = 0;
%     for i = 1:nsomas_at_elect1
%         ipre = somas_at_elect1(i);
%         for j = 1:nsomas_at_elect2
%             ipost = somas_at_elect2(j);
%             if time1weights(ipost, ipre) ~= 0
%                 dw_Site1_to_Site2 = dw_Site1_to_Site2 + wchange(ipost, ipre);
%                 dwS1S2abs = dwS1S2abs + abs(wchange(ipost, ipre));
%                 nw_Site1_to_Site2 = nw_Site1_to_Site2 + 1;
%                 if wchange(ipost, ipre) ~= 0
%                     nwnz_Site1_to_Site2 = nwnz_Site1_to_Site2 + 1;
%                 end
%             end
%             if time1weights(ipre, ipost) ~= 0
%                 dw_Site2_to_Site1 = dw_Site2_to_Site1 + wchange(ipre, ipost);
%                 dwS2S1abs = dwS2S1abs + abs(wchange(ipre, ipost));
%                 nw_Site2_to_Site1 = nw_Site2_to_Site1 + 1;
%                 if wchange(ipre, ipost) ~= 0
%                     nwnz_Site2_to_Site1 = nwnz_Site2_to_Site1 + 1;
%                 end
%             end
%         end
%     end
%     if nwnz_Site1_to_Site2 > 0
%         dwnz_Site1_to_Site2 = dw_Site1_to_Site2 / nwnz_Site1_to_Site2;
%         dwnzS1S2abs = dwS1S2abs / nwnz_Site1_to_Site2;
%     end
%     if nw_Site1_to_Site2 > 0
%         dw_Site1_to_Site2 = dw_Site1_to_Site2 / nw_Site1_to_Site2;
%         dwS1S2abs = dwS1S2abs / nw_Site1_to_Site2;
%     end
%     if nwnz_Site2_to_Site1 > 0
%         dwnz_Site2_to_Site1 = dw_Site2_to_Site1 / nwnz_Site2_to_Site1;
%         dwnzS2S1abs = dwS2S1abs / nwnz_Site2_to_Site1;
%     end
%     if nw_Site2_to_Site1 > 0
%         dw_Site2_to_Site1 = dw_Site2_to_Site1 / nw_Site2_to_Site1;
%         dwS2S1abs = dwS2S1abs / nw_Site2_to_Site1;
%     end
% 
%     disp(['Mean weight change Site1 -> Site2: ' num2str(dw_Site1_to_Site2) ' (n_weights = ' num2str(nw_Site1_to_Site2) '), abs change: ' num2str(dwS1S2abs)]);
%     disp(['Mean non-zero weight change Site1 -> Site2: ' num2str(dwnz_Site1_to_Site2) ' (n_nzweights = ' num2str(nwnz_Site1_to_Site2) '), abs change: ' num2str(dwnzS1S2abs)]);
%     disp('');
%     disp(['Mean weight change Site2 -> Site1: ' num2str(dw_Site2_to_Site1) ' (n_weights = ' num2str(nw_Site2_to_Site1) '), abs change: ' num2str(dwS2S1abs)]);
%     disp(['Mean non-zero weight change Site2 -> Site1: ' num2str(dwnz_Site2_to_Site1) ' (n_nzweights = ' num2str(nwnz_Site2_to_Site1) '), abs change: ' num2str(dwnzS2S1abs)]);
%     disp('');
% 
% end % if ~isempty(wchange)

%%
% Calculate unit firing frequency progression for each unit group.
% This shows how stable firing rates are over the course of the simulation.

% Calculate which units belong to which groups
nUnits = length(syn_arr); % Number of units
group_names = get_group_names();
group_bounds = Results.params.TissueParams.groupBoundaryIDArr;
nGroups = length(group_bounds) - 1;
unit2group = zeros(1, nUnits); % Converts unit index to group index
for iGroup = 1:nGroups
    unit2group(group_bounds(iGroup)+1:group_bounds(iGroup+1)) = iGroup;
end

% Estimate fire rate of each unit by counting the number of times it spikes
% spikes during each 1 second period.
unit_hz = zeros(nUnits,1);
spike_time_ms = Results.spikes(:,2);
spike_maxtime_sec = max(spike_time_ms) / 1000;
spike_time_sec1 = floor((Results.spikes(:,2) / 1000)) + 1;
spike_unit_id = floor(Results.spikes(:,1));
freq_prog = zeros(nGroups, floor(spike_maxtime_sec)+1, 43);
mean_unit_hz = zeros(1,floor(spike_maxtime_sec)+1);
max_unit_hz = zeros(1,floor(spike_maxtime_sec)+1);
isec = 1;
n = length(spike_unit_id);
for ispike = 1:n
    if spike_time_sec1(ispike) > isec
        % Record the firing rate histogram for this second
        max_unit_hz(isec) = max(unit_hz);
        mean_unit_hz(isec) = mean(unit_hz);
        unit_hz = min(unit_hz, 40) + 1;
        for iunit = 1:nUnits
            group_id = unit2group(iunit);
            ihz = unit_hz(iunit);
            freq_prog(group_id, isec, ihz) = freq_prog(group_id, isec, ihz) + 1;
        end
        unit_hz = zeros(nUnits, 1);
        isec = spike_time_sec1(ispike);
    end
    unit_id = spike_unit_id(ispike);
    unit_hz(unit_id) = unit_hz(unit_id) + 1;
end

if isec > 1
    hfig = figure;
    m = zeros(size(freq_prog,2), size(freq_prog,3));
    for igroup = 1:nGroups
        subplot(4, 4, igroup);
        m(:,:) = freq_prog(igroup,:,:);
        h = pcolor(m');
        h.LineStyle = 'none'; % Remove grid lines.
        if igroup >= 12
            xlabel('Seconds');
        end
        if ismember(igroup, [1 5 9 13])
            ylabel('Hz');
        end
        title(group_names{igroup});
        set(gca, 'XTickLabel', cellstr(num2str(get(gca, 'XTick')' - 1))); % Correct axes to start at 0 sec
    end
    subplot(4,4,16);
    plot([mean_unit_hz(1:end-1)', max_unit_hz(1:end-1)']);
    xlabel('Seconds');
    title('mean, max');
    save_figure(directory, 'firing_rate_progression', hfig, close_flag);
end

% Summary Firing Rate Statisics
aggregate_spike_rate = length(spike_time_ms) * 1000 / simulationTime;
disp(['Aggregate spike rate = ' num2str(aggregate_spike_rate) ' Hz']);
gbid = Results.params.TissueParams.groupBoundaryIDArr;

ngroups = length(gbid) - 1;
ind = cell(ngroups, 1);
ind2 = cell(ngroups, 1);
nunits = zeros(ngroups, 1);
for i = 1:ngroups
    nunits(i) = gbid(i+1) - gbid(i);
    ind{i} = find(spike_unit_id > gbid(i) & spike_unit_id <= gbid(i+1));
    ind2{i} = find(spike_unit_id > gbid(i) & spike_unit_id <= gbid(i+1) & spike_time_ms >= 0.5*simulationTime);
end

%%
% Calculate density maps by binning units by soma position in a XZ grid.

bin_size = 25; % microns
x_bins = (0:bin_size:Results.params.TissueParams.X);
y_bins = (0:bin_size:Results.params.TissueParams.Y);
z_bins = (0:bin_size:Results.params.TissueParams.Z);
x_somas = Results.params.TissueParams.somaPositionMat(:, 1);
y_somas = Results.params.TissueParams.somaPositionMat(:, 2);
z_somas = Results.params.TissueParams.somaPositionMat(:, 3);
ix = floor(x_somas / bin_size) + 1;
iy = floor(y_somas / bin_size) + 1;
iz = floor(z_somas / bin_size) + 1;

%%
% Plot density of weights by post-synaptic unit soma location

stdens = zeros(length(z_bins), length(x_bins));
stdens_pre = zeros(length(z_bins), length(x_bins));
for iPre = 1:size(syn_arr, 1)
    post_units = syn_arr{iPre,1};
    nPost = length(post_units);
    stdens_pre(iz(iPre), ix(iPre)) = stdens_pre(iz(iPre), ix(iPre)) + nPost;
    for iPost = 1:nPost
       j = post_units(iPost);
       stdens(iz(j), ix(j)) = stdens(iz(j), ix(j)) + 1; 
    end
end

hfig = figure;
hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 550 800];
subplot(2,1,1);
h = pcolor(stdens);
set(gca, 'XTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', flip(length(z_bins):-20:0));
set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Weight Density to Post-synaptic unit (soma position)');
colorbar;

subplot(2,1,2);
h = pcolor(stdens_pre);
set(gca, 'XTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', flip(length(z_bins):-20:0));
set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Weight density from Pre-synaptic units (soma position)');
colorbar;

save_figure(directory, 'weight_density_at_soma_xz', hfig, close_flag);

%%
% Activity plot for spikes occurring just after a stimulus.
% Count how many spikes occur for units in each bin.
% Coincidence window and baseline must fit in the [-50,150) ms data window.

coincidence_ms = [0 5];  % Count spikes occuring in this time window after a stimulus is delivered.
baseline_ms = 50;    % Time before stimulus for measuring baseline activity.

costr = [num2str(coincidence_ms(1)) '-' num2str(coincidence_ms(2)) 'ms'];
n = length(spike_unit_id);
psth = zeros(1, 200);
act = zeros(length(z_bins), length(x_bins));    % Activity
actxy = zeros(length(y_bins), length(x_bins));
bact = zeros(length(z_bins), length(x_bins));   % Baseline activity
bactxy = zeros(length(y_bins), length(x_bins));
stim_ms = [];
if ~isempty(stim_times)
    stim_ms = stim_times(stim_ids == 1);
elseif isfield(Results.params.TissueParams, 'stim_ms')
    stim_ms = Results.params.TissueParams.stim_ms;
    stim_delay = Results.params.TissueParams.stim_delay_ms;
    stim_size = Results.params.TissueParams.stim_size;
end
x_elect = [];
y_elect = [];
z_elect = [];

% Calculate unit layers.
layer_tops = Results.params.TissueParams.layerBoundaryArr;
unit2layer = ones(1, nUnits); % Converts unit index to a layer
nlayers = length(layer_tops) - 1;
for i = 1:nlayers
    unit2layer( (z_somas <= layer_tops(i)) & (z_somas > layer_tops(i+1)) ) = i;
end
layer_names = {'Layer 1', 'Layer 2/3', 'Layer 4', 'Layer 5', 'Layer 6'};
actxyl = zeros(length(y_bins), length(x_bins), nlayers); % Activity by layer
bactxyl = zeros(length(y_bins), length(x_bins), nlayers); % Baseline activity by layer

if length(stim_ms) > 1
    for i = 1:n % Run through list of spikes
        % count spikes near first stim in the pair
        deltat_ms = spike_time_ms(i) - stim_ms;
        index = find((deltat_ms >= -50) & (deltat_ms < 150));  % matching stimuli
        for j = index
            dt = floor(deltat_ms(j)) + 51; % Bin for ith spike
            psth(dt) = psth(dt) + 1;
            if (deltat_ms(j) >= coincidence_ms(1)) && (deltat_ms(j) < coincidence_ms(2))
                % count spike if it occurred upto dt ms after a stimulus
                id = spike_unit_id(i);
                xi = ix(id);
                yi = iy(id);
                zi = iz(id);
                act(zi, xi) = act(zi, xi) + 1;
                actxy(yi, xi) = actxy(yi, xi) + 1;
                layer_index = unit2layer(id);
                actxyl(yi, xi, layer_index) = actxyl(yi, xi, layer_index) + 1;               
            elseif (deltat_ms(j) >= -baseline_ms) && (deltat_ms(j) < 0)
                % count spike if it occurred upto dt ms before a stimulus
                id = spike_unit_id(i);
                xi = ix(id);
                yi = iy(id);
                zi = iz(id);
                bact(zi, xi) = bact(zi, xi) + 1;
                bactxy(yi, xi) = bactxy(yi, xi) + 1;
                layer_index = unit2layer(id);
                bactxyl(yi, xi, layer_index) = bactxyl(yi, xi, layer_index) + 1;               
            end
        end
    end
    hfig = figure;
    histogram('BinEdges', -50:150, 'BinCounts', psth);
    xlim([-50 150]);
    set(gca, 'XTick', [-50, 0, 150]);
    set(gca, 'TickDirMode', 'manual')
    set(gca, 'TickDir', 'both')
    title(['PSTH Stim1 -> All Spikes (n = ' num2str(length(stim_ms)) ')']);
    pre_count = sum(psth(45:49));
    post_count = sum(psth(50:54));
    percent_increase = 100 * (post_count - pre_count) / pre_count;
    xlabel(['ms (%increase 5ms post vs prestim = ' num2str(percent_increase) '%)']);
    save_figure(directory, 'PSTH_stim2all', hfig, close_flag);

    % Plot XZ projection of where spikes were correlated with stimulation
    hfig = figure;
    hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 550 800];
    h = pcolor(act);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', flip(length(z_bins):-20:0));
    set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            z_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_zpos(ielec,1:2));
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            z_elect(ielec) = Results.params.TissueParams.opto_source_zpos(ielec);
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike Coincidence Count (' costr ')']);
    xlabel('X');
    ylabel('Depth');
    save_figure(directory, ['Stim2Spike_coincidence__count_xz_' costr], hfig, close_flag);

    % Plot XZ projection of log increased spiking before/after stimulation
    scale_limits = [-5 10]; % [] for autoscale
    bact = bact * diff(coincidence_ms) / baseline_ms; % normalize for expected counts in coincidence window
    increased_act = act - bact; % Subtract baseline
    bact(bact <= 1) = 1; % Reduce noise from very low baseline counts (and prevent divide by zero)
    increased_act(abs(increased_act) < 0.01) = 0.01;  % So log percent increases start at 0 (and prevent taking log of zero)
    increased_act = 100 * increased_act ./ bact; % Percent Increase
    increased_act = sign(increased_act) .* log(abs(increased_act)); % Log scale
    if length(scale_limits) >= 2
        increased_act(increased_act < scale_limits(1)) = scale_limits(1);
        increased_act(increased_act > scale_limits(2)) = scale_limits(2);
        increased_act(1,end) = scale_limits(1);
        increased_act(end,end) = scale_limits(2);
    end
    hfig = figure;
    hfig.Position = (hfig.Position .* [1 0.4 0 0]) + [0 0 550 800];
    h = pcolor(increased_act);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', flip(length(z_bins):-20:0));
    set(gca, 'YTickLabel', cellstr(num2str(z_bins(end) + bin_size - bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            z_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_zpos(ielec,1:2));
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            z_elect(ielec) = Results.params.TissueParams.opto_source_zpos(ielec);
        end
        plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike log percent increased count (' costr ')']);
    xlabel('X');
    ylabel('Depth');
    save_figure(directory, ['Stim2Spike_log_percent_increase_xz_' costr], hfig, close_flag);

    % Plot XY projection of where spikes were correlated with stimulation
    hfig = figure;
    hfig.Position = (hfig.Position .* [1 .8 0 0]) + [0 0 550 460];
    h = pcolor(actxy);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', 0:20:length(y_bins));
    set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            y_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_ypos(ielec,1:2));
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            y_elect(ielec) = Results.params.TissueParams.opto_source_ypos(ielec);
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike Coincidence (' costr ')']);
    xlabel('X');
    ylabel('Y');
    save_figure(directory, ['Stim2Spike_coincidence_count_xy_' costr], hfig, close_flag);

    % Plot XY projection of log increased spiking before/after stimulation
    bactxy = bactxy * diff(coincidence_ms) / baseline_ms; % normalize for expected counts in coincidence window
    increased_act = actxy - bactxy; % Subtract baseline
    bactxy(bactxy <= 1) = 1; % Reduce noise from very low baseline counts (and prevent divide by zero)
    increased_act(abs(increased_act) < 0.01) = 0.01;  % Scale increases starting at 0% (and prevent taking log of zero)
    increased_act = 100 * increased_act ./ bactxy; % Percent Increase
    increased_act = sign(increased_act) .* log(abs(increased_act)); % Log scale
    if length(scale_limits) >= 2
        increased_act(increased_act < scale_limits(1)) = scale_limits(1);
        increased_act(increased_act > scale_limits(2)) = scale_limits(2);
        increased_act(1,end) = scale_limits(1);
        increased_act(end,end) = scale_limits(2);
    end
    hfig = figure;
    hfig.Position = (hfig.Position .* [1 0.8 0 0]) + [0 0 550 460];
    h = pcolor(increased_act);
    set(gca, 'YTick', 0:20:length(x_bins));
    set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
    set(gca, 'YTick', 0:20:length(z_bins));
    set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
    h.LineStyle = 'none'; % Remove grid lines.
    colorbar;
    hold on;
    % plot electrode positions
    if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
        nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
        for ielec = 1:nelec
            x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
            y_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_ypos(ielec,1:2));
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
        nelec = length(Results.params.TissueParams.opto_source_xpos);
        for ielec = 1:nelec
            x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
            y_elect(ielec) = Results.params.TissueParams.opto_source_ypos(ielec);
        end
        plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
    end
    title(['Stim -> Spike log percent increased count (' costr ')']);
    xlabel('X');
    ylabel('Y');
    save_figure(directory, ['Stim2Spike_log_percent_increase_xy_' costr], hfig, close_flag);

    % By layer: Plot XY projection of log increased spiking before/after stimulation
    bactxyl = bactxyl * diff(coincidence_ms) / baseline_ms; % normalize for expected counts in coincidence window
    hfig = figure;
    hfig.Position = [50 50 1100 900];

    for i = 2:5 % plotting for Layer2/3, 4, 5, 6
        subplot(2,2,i-1);
        bactxy = bactxyl(:,:,i);
        increased_act = actxyl(:,:,i) - bactxy; % Subtract baseline
        bactxy(bactxy <= 1) = 1; % Reduce noise from very low baseline counts (and prevent divide by zero)
        increased_act(abs(increased_act) < 0.01) = 0.01;  % Scale increases starting at 0% (and prevent taking log of zero)
        increased_act = 100 * increased_act ./ bactxy; % Percent Increase
        increased_act = sign(increased_act) .* log(abs(increased_act)); % Log scale
        if length(scale_limits) >= 2
            increased_act(increased_act < scale_limits(1)) = scale_limits(1);
            increased_act(increased_act > scale_limits(2)) = scale_limits(2);
            increased_act(1,end) = scale_limits(1);
            increased_act(end,end) = scale_limits(2);
        end
        h = pcolor(increased_act);
        set(gca, 'YTick', 0:20:length(x_bins));
        set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
        set(gca, 'YTick', 0:20:length(z_bins));
        set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
        h.LineStyle = 'none'; % Remove grid lines.
        colorbar;
        hold on;
        % plot electrode positions
        if isfield(Results.params.TissueParams, 'stim_electrode_xpos')
            nelec = size(Results.params.TissueParams.stim_electrode_xpos,1);
            for ielec = 1:nelec
                x_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_xpos(ielec,1:2));
                y_elect(ielec) = mean(Results.params.TissueParams.stim_electrode_ypos(ielec,1:2));
            end
            plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
        elseif isfield(Results.params.TissueParams, 'opto_source_xpos')
            nelec = length(Results.params.TissueParams.opto_source_xpos);
            for ielec = 1:nelec
                x_elect(ielec) = Results.params.TissueParams.opto_source_xpos(ielec);
                y_elect(ielec) = Results.params.TissueParams.opto_source_ypos(ielec);
            end
            plot(x_elect/bin_size, y_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
        end
        title(['Stim -> ' layer_names{i} ' Spikes, log percent increase (' costr ')']);
        xlabel('X');
        ylabel('Y');
    end
    save_figure(directory, ['Stim2Spike_log_percent_increase_xylayers_' costr], hfig, close_flag);
end

%%
%Calculate spike rate for each unit
nspikes = zeros(1, nUnits);
n = length(spike_unit_id);
for i = 1:n
    id = spike_unit_id(i);
    nspikes(id) = nspikes(id) + 1;
end

% Look at firing rates by soma location
act = zeros(length(z_bins), length(x_bins));
maxact = zeros(length(z_bins), length(x_bins));
nact = zeros(length(z_bins), length(x_bins));
for i = 1:nUnits
    nact(iz(i), ix(i)) = nact(iz(i), ix(i)) + 1; 
    act(iz(i), ix(i)) = act(iz(i), ix(i)) + nspikes(i); 
    maxact(iz(i), ix(i)) = max(maxact(iz(i), ix(i)), nspikes(i));
end
act = (act ./ max(1,nact)) * 1000 / simulationTime; % Activity in spikes per second

hfig = figure;
subplot(2,1,1);
h = pcolor(act);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', 0:20:length(z_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Mean firing frequency map (Hz)');
colorbar;
if ~isempty(x_elect)
    hold on; % plot electrode positions
    plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
end

subplot(2,1,2);
h = pcolor(maxact * 1000 / simulationTime);
set(gca, 'YTick', 0:20:length(x_bins));
set(gca, 'XTickLabel', cellstr(num2str(bin_size * get(gca, 'XTick')'))); % Correct axes for bin_size
set(gca, 'YTick', 0:20:length(z_bins));
set(gca, 'YTickLabel', cellstr(num2str(bin_size * get(gca, 'YTick')')));
h.LineStyle = 'none'; % Remove grid lines.
title('Maximum firing frequency map (Hz)');
colorbar;
if ~isempty(x_elect)
    hold on; % plot electrode positions
    plot(x_elect/bin_size, z_elect/bin_size, '.', 'Color', [1 1 1], 'MarkerSize', 20);
end
save_figure(directory, 'firing_rate_map', hfig, close_flag);

%%
% Display mean firing rates by group
fname = [directory '\group_firing_rates.txt'];
if exist(fname, 'file')
    delete(fname);
end
diary(fname);
group_spike_rate = zeros(ngroups, 1);
group_mean_spike_rate = zeros(ngroups, 1);
for i = 1:ngroups
    group_spike_rate(i) = length(ind{i}) * (1000 / simulationTime);
    group_mean_spike_rate(i) = group_spike_rate(i) / nunits(i);
    disp(['Group ' num2str(i) ' (' group_names{i} '), n = ' num2str(nunits(i)) ...
        ', mean spike rate (all time) = ' num2str(group_mean_spike_rate(i)) ' Hz']);
end

% only using last half of data
group_spike_rate2 = zeros(ngroups, 1);
group_mean_spike_rate2 = zeros(ngroups, 1);
for i = 1:ngroups
    group_spike_rate2(i) = length(ind2{i}) * 1000 / (0.5 * simulationTime);
    group_mean_spike_rate2(i) = group_spike_rate2(i) / nunits(i);
    disp(['Group ' num2str(i) ' (' group_names{i} '), n = ' num2str(nunits(i)) ...
        ', mean spike rate (2nd half) = ' num2str(group_mean_spike_rate2(i)) ' Hz']);
end
diary off;

%%
% if ~isempty(wchange) && isfield(Results.params.TissueParams, 'stim_ms')
%     % Accumulate a few stats in a results file.  This is done in case we run
%     % multiple stimulation sessions with different amplitudes or delays.
%     fid = fopen('PPResults_g_exp_stdp.txt', 'a');
%     fprintf(fid, '%g, %g, %g, %g, %g, %g\n', stim_size, stim_delay, ...
%         dwnz_Site1_to_Site2, dwnz_Site2_to_Site1, dwnzsite1, dwnzsite2);
%     fclose(fid);
% end

%%
% Peri-event-time histograms of spikes

% hfig = figure;
% maxt = max(spike_time_ms);
% for i = 1:ngroups
%     for j = i:ngroups
%         h = subplot(ngroups, ngroups, i + ngroups * (j - 1)); 
%         [xaxis, yvals, ns] = pethist(spike_time_ms(ind{i}), spike_time_ms(ind{j}), [-50 50], 1, [0 maxt]);
%         plot(xaxis, yvals);
%         if (j < ngroups)
%             h.XTick = [];
%         else
%             xlabel(['ms (n=' num2str(ns) ')']);
%             h.XTick = [-50 0 50];
%         end
%         if i * j == 1
%             title('1->1 PSTH');
%         else
%             title([num2str(i) '->' num2str(j)]);
%         end
%     end
% end
% save_figure(directory, 'PSTH_group2group', hfig, close_flag);



