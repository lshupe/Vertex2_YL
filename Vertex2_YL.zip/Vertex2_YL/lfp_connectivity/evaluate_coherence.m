function [] = evaluate_coherence(Results, output_dir, electrode_id_1, ...
    electrode_id_2, should_save)
    RS = Results.params.RecordingSettings;
    electrode_1_lfp = Results.LFP(electrode_id_1, :);
%     electrode_1_lfp = electrode_1_lfp(:, 200:(length(electrode_1_lfp) - 200));
    electrode_2_lfp = Results.LFP(electrode_id_2, :);
%     electrode_2_lfp = electrode_2_lfp(:, 200:(length(electrode_2_lfp) - 200));
%     f = 1:500;
    mscohere(electrode_1_lfp, electrode_2_lfp, hamming(500), 250, [], RS.sampleRate)
    id_1_str = num2str(electrode_id_1);
    id_2_str = num2str(electrode_id_2);
    
    title_str = strcat( ... 
        'Magnitude Squared Coherence between Electrodes ID ', ...
        id_1_str, ' and ', id_2_str);
    title(title_str, 'FontSize', 16)
    file_name = strcat(output_dir, '/cohere_', id_1_str, '_', id_2_str);
    if should_save 
        savefig(strcat(file_name, '.fig'))
        saveas(gcf, strcat(file_name, '.png'))
    end
end

