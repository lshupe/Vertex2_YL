function [f, freqs] = evaluate_pgranger(LFP)

    regmode   = 'OLS';  % VAR model estimation regression mode ('OLS', 'LWR' or empty for default)
%     icregmode = 'LWR';  % information criteria regression mode ('OLS', 'LWR' or empty for default)
%     morder    = 'AIC';  % model order to use ('actual', 'AIC', 'BIC' or supplied numerical value)
    momax     = 25;     % maximum model order for model order estimation
    acmaxlags = [];   % maximum autocovariance lags (empty for automatic calculation)
    fs        = 1000;    % sample rate (Hz)
    fres      = [];     % frequency resolution (empty for automatic calculation)
    %%
%     [aic,bic,moaic,mobic] = tsdata_to_infocrit(results,momax,icregmode);
%     morder = moaic;

    morder = momax;
    
    % Estimate VAR model of selected order from data.
    ptic('\n*** tsdata_to_var... ');
    [A,SIG] = tsdata_to_var(LFP,morder,regmode);
    ptoc;
    
    % Check for failed regression
    assert(~isbad(A),'VAR estimation failed');
    % NOTE: at this point we have a model and are finished with the data! - all
    % subsequent calculations work from the estimated VAR parameters A and SIG.

    %%
    % The autocovariance sequence drives many Granger causality calculations (see
    % next section). Now we calculate the autocovariance sequence G according to the
    % VAR model, to as many lags as it takes to decay to below the numerical
    % tolerance level, or to acmaxlags lags if specified (i.e. non-empty).

    ptic('*** var_to_autocov... ');
    [G,info] = var_to_autocov(A,SIG,acmaxlags);
    ptoc;

    % The above routine does a LOT of error checking and issues useful diagnostics.
    % If there are problems with your data (e.g. non-stationarity, colinearity,
    % etc.) there's a good chance it'll show up at this point - and the diagnostics
    % may supply useful information as to what went wrong. It is thus essential to
    % report and check for errors here.

    var_acinfo(info,true); % report results (and bail out on error)

    %%

    % Calculate spectral pairwise-conditional causalities at given frequency
    % resolution - again, this only requires the autocovariance sequence.

    ptic('\n*** autocov_to_spwcgc... ');
    [f, fres] = autocov_to_spwcgc(G,fres);
    ptoc;
    
    freqs = sfreqs(fres, fs);

    % Check for failed spectral GC calculation

    assert(~isbad(f,false),'spectral GC calculation failed');

    % Plot spectral causal graph.
    % 
    % figure(3); clf;
    % plot_spw(f,fs);