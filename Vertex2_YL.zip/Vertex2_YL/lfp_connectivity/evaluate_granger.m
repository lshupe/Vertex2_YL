function [grang_mat, freqs] = evaluate_granger(LFP)

    regmode   = 'OLS';  % VAR model estimation regression mode ('OLS', 'LWR' or empty for default)
%     icregmode = 'LWR';  % information criteria regression mode ('OLS', 'LWR' or empty for default)
%     morder    = 'AIC';  % model order to use ('actual', 'AIC', 'BIC' or supplied numerical value)
    momax     = 25;     % maximum model order for model order estimation
    acmaxlags = [];   % maximum autocovariance lags (empty for automatic calculation)
    fs        = 1000;    % sample rate (Hz)
    fres      = [];     % frequency resolution (empty for automatic calculation)
    %%
        
    num_electrodes = size(LFP, 1);
    first = true;
    for i = 1:num_electrodes
        for j = i+1:num_electrodes
%             fres = [];
%             if i == j
%                 continue
%             end

            morder = momax; % Hardcoded to make sure order is same between all pairs
            [A,SIG] = tsdata_to_var(LFP([i, j], :),morder,regmode);
            assert(~isbad(A),'VAR estimation failed');
            [G,~] = var_to_autocov(A,SIG,acmaxlags);
            [ij_grang, fres] = autocov_to_spwcgc(G,fres);
                        
            assert(~isbad(ij_grang,false),'spectral GC calculation failed');
                    
            if first % Initialize matrix to store results
                grang_mat = zeros(num_electrodes, num_electrodes, size(ij_grang, 3));
                first = false;
            end
            
            grang_mat(i, j, :) = ij_grang(1, 2, :);
            grang_mat(j, i, :) = ij_grang(2, 1, :);
        end
        grang_mat(i, i, :) = ones(1, size(grang_mat, 3));
        disp(i)
    end
    
    freqs = sfreqs(fres, fs);

            

    
    
    
