function [MCOH,F] = evaluate_pcoherence(results)
% Calculation of multiple coherence.
%
% x :inputs (#time samples x #inputs) % swapped dims
% y :outputs (#time samples x #outputs) % swapped dims
% index : selected output 
% nfft : number of fft
% fs : sampling rate
% window : you can change window function if your data are not periodic
%
% Note: input are the "froms", conditioned on each other
%       and output is the "to"
%       I believe that output should be removed from input
%       Also its pretty dumb that there is an "index" param since they only
%       use one row from y. Like just pass in a single y row. Can just keep
%       index at 1 i guess
%
% Sample usage:
%   [mCoh,F] = MultipleCoherehence(2048,inputs,Datas,5,2048);
%
%
%
%  For other Modal Analysis Routines please contact :
%  mmbicak@mtu.edu
%  http://www.me.mtu.edu/~mmbicak

    fs = 1000;
    index = 1;
    nfft = 1000; % also ends up being the window size

    % grab x and y from results
    num_electrodes = 10;%size(results.LFP, 1);
    first = true;
    for j = 1:num_electrodes % to
        % get output and set it to y
        % remove that index from the matrix and set it to x
        y = results.LFP(j, :);
        x = results.LFP(1:10,:);
        x(j, :) = []; % remove the output from the input

        % matlab shared function below
        x = x.';
        y = y.';
    %     nfft = size
        noverlap = floor(nfft/2);    
        m = length(x(1,:));% # inputs 
        n = length(y(1,:));% # outputs     
        if (index<=0) | (index>n) 
            error('index error, check index value (index)') 
        end
        window = hamming(nfft);% assuming pure harmonic signal,otherwise use a window
        for ii = 1 : m 
            for jj = 1 : m
              [Cxy,F] = cpsd(x(:,ii),x(:,jj),window, noverlap,nfft,fs); 
              GXX{ii,jj} = Cxy;
            end
        end

        for ii = 1 : m 
             [Cyx,F] = cpsd(y(:,index),x(:,ii),window, noverlap,nfft,fs); 
             GYX{ii,1} = Cyx;             
             GXY{ii,1}=conj(Cyx); % added from mathworks comment
        end
        [Cyy,F] = cpsd(y(:,index),y(:,index),window, noverlap,nfft,fs);     
        GYY{1}=Cyy;    
        GYXX = [GYX';GXX];    
        GY = [GYY;GXY];
        GYXX = [GY GYXX];    
        for ii= 1:length(F)        
            for jj = 1 :m+1
                for kk = 1:m+1;
                    G = GYXX{jj,kk};
                    GYXX_f( jj , kk )=G(ii);
                end
            end
            for jj = 1 :m
                for kk = 1:m;
                    G = GXX{jj,kk};
                    GXX_f( jj , kk )=G(ii);
                end
            end       
            MCOH(ii) = 1 - (det(GYXX_f)/(Cyy(ii)*det(GXX_f)));
        end
        
    if first % Initialize matrix to store results
        pcoh_mat = zeros(num_electrodes, num_electrodes, size(MCOH, 3));
        first = false;
    end

    pcoh_mat(:, j, :) = MCOH(1, 2, :);
    pcoh_mat(i, i, :) = ones(1, size(pcoh_mat, 3));
    disp(i)
    
    freqs = sfreqs(fres, fs);
    
    end;
    
    
        
        