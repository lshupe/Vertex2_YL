function [coh_mat, f] = evaluate_coherence_new(LFP)
    num_electrodes = size(LFP, 1);
    
    window_size = floor(size(LFP, 2) / 20);
    noverlap = floor(window_size / 2);

    first = true;
    for i = 1:num_electrodes
        for j = i:num_electrodes
            [ij_coh, f] = mscohere(LFP(i, :), LFP(j, :), hamming(window_size, ...
                        'periodic'), noverlap, [], 1000);    
            if first
                coh_mat = zeros(num_electrodes, num_electrodes, size(ij_coh, 1));% matrix to store coherence
                first = false;
            end
            coh_mat(i, j, :) = ij_coh;
            coh_mat(j, i, :) = ij_coh;
        end
        coh_mat(i, i, :) = ones(1, size(coh_mat, 3));
        disp(i)
    end
end

