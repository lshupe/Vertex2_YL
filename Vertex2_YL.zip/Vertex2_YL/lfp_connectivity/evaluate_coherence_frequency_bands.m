function [mean_coherence] = evaluate_coherence_frequency_bands(frequencies, coherence)
    % freqBands - is all coherences for given freq band
    % coherence - is electrode x electrode grid with a list of 1025
    % frequencies at each electrode pair. Each frequency has a coherence
    % value
    % frequencies - is list of 1025 frequencies corresponding to coherence's
    % frequencies in coherence variable
    % mean_coherence - mean coherence per freq Band
    [freqBands.delta, freqBands.theta, freqBands.alpha, freqBands.beta, freqBands.gamma, freqBands.highGamma] = deal(zeros(54,54));
    [deltaLength, thetaLength, alphaLength, betaLength, gammaLength, highGammaLength] = deal(0);

    % get freq and coherence if empty
    freqExists = exist('frequencies','var');
    coherenceExists = exist('coherence', 'var');

    if ~freqExists || ~coherenceExists
        resultsDict = loadResults('./vertex_results');
        [coherence, frequencies] = evaluate_coherence_new(resultsDict.LFP);
        save('.\vertex_results\frequencies', 'frequencies');
        save('.\vertex_results\coherence', 'coherence');
    end
    for i=1:length(frequencies)-1
        freq = frequencies(i);
        % 54 x 54 grid of electrodes w/ coh val at freq_i
        coherenceVals = coherence(:,:,i);
        if freq < 4
            freqBands.delta = freqBands.delta + coherenceVals;
            deltaLength = deltaLength + 1;
        elseif freq < 8 && freq >= 4
            freqBands.theta = freqBands.theta + coherenceVals;
            thetaLength = thetaLength + 1;
        elseif freq < 12 && freq >= 8
            freqBands.alpha = freqBands.alpha + coherenceVals;
            alphaLength = alphaLength + 1;
        elseif freq < 30 && freq >= 12
            freqBands.beta = freqBands.beta + coherenceVals;
            betaLength = betaLength + 1;
        elseif freq < 60 && freq >= 30
            freqBands.gamma = freqBands.gamma + coherenceVals;
            gammaLength = gammaLength + 1;
        elseif freq < 200 && freq >= 60
            freqBands.highGamma = freqBands.highGamma + coherenceVals;
            highGammaLength = highGammaLength + 1;
        else 
            continue
        end
    end
    
    % calc mean of coherence of each  and save to file
    mean_coherence.delta = freqBands.delta ./ deltaLength;
    mean_coherence.theta = freqBands.theta ./ thetaLength;
    mean_coherence.alpha = freqBands.alpha ./ alphaLength;
    mean_coherence.beta = freqBands.beta ./ betaLength;
    mean_coherence.gamma = freqBands.gamma ./ gammaLength;
    mean_coherence.highGamma = freqBands.highGamma ./ highGammaLength;
    
    % May need to adjust this file path for your local development setuip
    save('.\vertex_results\mean_coherence', 'mean_coherence');

end
