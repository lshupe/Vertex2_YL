classdef ConnectivityType
   enumeration
      Coherence, PCoherence, Granger, PGranger
   end
end