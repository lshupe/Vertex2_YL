function [mean_connectivity] = evaluate_connectivity_frequency_bands_JB(connectivityType, LFP)
    % freqBands - is all coherences for given freq band
    % coherence - is electrode x electrode grid with a list of 1025
    % frequencies at each electrode pair. Each frequency has a coherence
    % value
    % frequencies - is list of 1025 frequencies corresponding to coherence's
    % frequencies in coherence variable
    % mean_connectivity - mean coherence per freq Band

    % Pick connectivity type here (see ConnectivityType.m file)
    [freqBands.delta, freqBands.theta, freqBands.alpha, freqBands.beta, freqBands.gamma, freqBands.highGamma] = deal(zeros(size(LFP, 1),size(LFP, 1)));
    [deltaLength, thetaLength, alphaLength, betaLength, gammaLength, highGammaLength] = deal(0);

    switch connectivityType
        case ConnectivityType.Coherence
            [connectivity, frequencies] = evaluate_coherence_new(LFP);
        case ConnectivityType.Granger
            [connectivity, frequencies] = evaluate_granger(LFP);
        case ConnectivityType.PGranger
            [connectivity, frequencies] = evaluate_pgranger(LFP);
    end
    
    for i=1:length(frequencies)-1
        freq = frequencies(i);
        % 54 x 54 grid of electrodes w/ coh val at freq_i
        connectivityVals = connectivity(:,:,i);
        if freq < 4
            freqBands.delta = freqBands.delta + connectivityVals;
            deltaLength = deltaLength + 1;
        elseif freq < 8 && freq >= 4
            freqBands.theta = freqBands.theta + connectivityVals;
            thetaLength = thetaLength + 1;
        elseif freq < 12 && freq >= 8
            freqBands.alpha = freqBands.alpha + connectivityVals;
            alphaLength = alphaLength + 1;
        elseif freq < 30 && freq >= 12
            freqBands.beta = freqBands.beta + connectivityVals;
            betaLength = betaLength + 1;
        elseif freq < 60 && freq >= 30
            freqBands.gamma = freqBands.gamma + connectivityVals;
            gammaLength = gammaLength + 1;
        elseif freq < 200 && freq >= 60
            freqBands.highGamma = freqBands.highGamma + connectivityVals;
            highGammaLength = highGammaLength + 1;
        else 
            continue
        end
    end
    
    % calc mean of connectivity of each  and save to file
    mean_connectivity.delta = freqBands.delta ./ deltaLength;
    mean_connectivity.theta = freqBands.theta ./ thetaLength;
    mean_connectivity.alpha = freqBands.alpha ./ alphaLength;
    mean_connectivity.beta = freqBands.beta ./ betaLength;
    mean_connectivity.gamma = freqBands.gamma ./ gammaLength;
    mean_connectivity.highGamma = freqBands.highGamma ./ highGammaLength;
    
end
