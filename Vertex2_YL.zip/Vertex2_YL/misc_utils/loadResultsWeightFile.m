function [weights_arr] = loadResultsWeightFile(saveDir, fName)
%loadResultsWeightFile loads a weights array from a weights file.
%   weights_arr = loadResultsWeightFile(saveDir, fName)
%
%   Loads a weights file saved by runSimulation().
%
%   saveDir is a character array (string) specifying the directory where
%   the simulation results were saved.
%
%   fName is the file prefix which is usually 'weights', 'weights1',
%   'weights1_', 'weights2_', etc.  If fName ends in a '_' then a series 
%   of weight files are loaded as saved by saveDataSPMD.m, and the data
%   will be combined to form the expected weights_arr{nUnits} cell array
%   matching the simulation's synapse array.

weights_arr = {};

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

parallel_mode = (fName(end) == '_');
n = 1;
should_load_next_file = true;
while should_load_next_file
    if parallel_mode
        file_name = [saveDir fName num2str(n) '.mat'];
    else
        file_name = [saveDir fName '.mat'];
        should_load_next_file = false; % only 1 file to read
    end
    if ~exist(file_name, 'file')
        should_load_next_file = false;
        if n == 1
            disp(['Load weights failed: ' file_name ' not found.']);
        end
    else
        loadedData = load(file_name);
        ff = fields(loadedData);
        wArr = loadedData.(ff{1});
        if n == 1
            weights_arr = wArr;
        else
            % Append weights
            for iN = 1:length(weights_arr)
                weights_arr{iN}(end+1:end+length(wArr{iN})) = wArr{iN};
            end
        end
    end
    n = n + 1; % Next file index
end
