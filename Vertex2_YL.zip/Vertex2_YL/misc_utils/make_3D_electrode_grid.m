function [coords] = make_3D_electrode_grid(starting_coords, length_by_dim, num_electrodes_by_dim)
%make_3D_electrode_grid creates an evenly spaced electrode grid, represented as
%list of [x, y, z] coordinates
% Params: 
%   starting_coords: [x, y, z] represents starting position of the grid 
%   length_by_dim: [x, y, z] represents length of each dimension
%   num_electrodes_by_dim: [x, y, z] represents number of electrodes for
%   each dimension
% Returns:
%   coords: a list of coordinates in [x, y, z]
xs = get_arr_for_dimension(1, starting_coords, length_by_dim, num_electrodes_by_dim);
ys = get_arr_for_dimension(2, starting_coords, length_by_dim, num_electrodes_by_dim);
zs = get_arr_for_dimension(3, starting_coords, length_by_dim, num_electrodes_by_dim);

[x, y, z] = meshgrid(xs, ys, zs);
coords = [x(:), y(:), z(:)];
end

function [arr] = get_arr_for_dimension(idx, starting_coords, length_by_dim, num_electrodes_by_dim)
    arr = starting_coords(idx):length_by_dim(idx) /(num_electrodes_by_dim(idx) - 1):starting_coords(idx) + length_by_dim(idx);
end

