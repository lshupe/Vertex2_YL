function [coords] = make_electrode_grid(length ,buffer, number)
%ELECTRODE_GRID creates an evenly spaced electrode grid, represented as
%list of [x, y] coordinates
% Params: 
%   length: in micrometers, length of X-Y square. 
%   buffer: in micrometers, how much buffer to leave on each side
%   number: number of electrodes, must be a square value
% Returns:
%   coords: a list of coordinates in [x, y]
low = buffer;
high = length - buffer;
vec = low:((high - low) / (sqrt(number) - 1)):high;
[x, y] = meshgrid(vec, vec);
coords = [x(:), y(:)];
end

