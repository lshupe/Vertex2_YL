function [xaxis, yvals, nsweeps] = pethist(source_times, target_times, time_range, bin_width, valid_time)
% Creates a peri-event-time histogram Source -> Target by summing
% target events in a time range around each source time.  The resulting
% sum is then normalized by nsweeps, the number of source_times actually
% used.
%
% xaxis -- returns the left edge of each histogram bin.
% yvals -- returns the histogram values.
% nsweeps -- returns the number of source_times used
%
% source_times -- The time of each source event. Source times that yield
%   time ranges outside of valid_time are discarded.
% target_times -- The time of each target event
% time_range -- The left most (inclusive) and right most (exclusive) time
%   offsets in the resulting histogram.  E.G. [-100 200]
% bin_width -- The width of each histogram bin.
% valid_time -- The valid time range of the data.  E.G. [0  100000]
%
% Any time base may be used as long as all parameters use the same base. 

nbins = ceil((time_range(2) - time_range(1)) / bin_width); % Number of bins in the resulting histogram.
xaxis = ((0:nbins-1) .* bin_width) + time_range(1);
yvals = zeros(1,nbins);

ns = length(source_times);
nsweeps = 0;
for isource = 1:ns
    t = source_times(isource);
    window = time_range + t;   % Source time window
    if (window(1) >= valid_time(1)) && (window(2) < valid_time(2))
        nsweeps = nsweeps + 1;
        % Get all events within the source time window.
        events = target_times(target_times >= window(1) & target_times < window(2));
        if ~isempty(events)
            bins = floor((events - (t + xaxis(1))) / bin_width) + 1; % The bin that each event falls into
            nt = length(bins);
            for itarg = 1:nt
                bin = bins(itarg);
                yvals(bin) = yvals(bin) + 1; % One count for each event in this sweep.
            end
        end
    end
end

% Normalize to sweeps
if nsweeps > 0
    yvals = yvals / nsweeps;
end