function scale = yscalefig(yscale_value, figure_handle, indices_to_use)
% yscale_value -- size in y-axis units to use for each y-axis in the figure.
%   if empty or omitted, the largest ydata bounds will be used.
% figure_handle -- the figure with plots to scale.  If omitted or empty, 
%   gcf will be used (this is usually the front-most figure.
% indices_to_use -- optional list of indices to look at when calculating 
% the scale. Can be used to select a time region of interest.
%
% Sets the y-axis limits of each axis object in the figure to the same
% y-scale and centers each set of ydata.  Returns the yscale_value used.
% YData bounds are calculated on points that are < 5 standard deviations
% from the mean to remove outliers.

scale = []; % Default return value
if (nargin >= 1) && ~isempty(yscale_value)
    scale = yscale_value(1); % User explicity gave the yscale value to use.
end

if (nargin < 2) || isempty(figure_handle)
    axes_list = get(gcf, 'Children'); % Use front-most figure
else
    axes_list = get(figure_handle, 'Children');
end

if nargin < 3
    indices_to_use = [];
end

% Find ydata bounds for each ydata set in the figure

n = length(axes_list);
ymin = nan(size(axes_list));
ymax = nan(size(axes_list));

for i = 1:n
    if strcmp(axes_list(i).Type, 'axes')
        child_list = get(axes_list(i), 'Children');
        m = length(child_list);
        for j = 1:m
            chobj = child_list(j);
            if isprop(chobj, 'YData')
                ydata = chobj.YData;
                if ~isempty(indices_to_use)
                    ydata = ydata(ismember(1:length(ydata), indices_to_use));
                end
                if length(ydata) > 4
                    ydata = ydata(abs(ydata - mean(ydata)) <= 5 * std(ydata)); % remove outliers
                    [vmin, vmax] = bounds(ydata);
                    if isnan(ymin)
                        ymin(i) = vmin;
                    else
                        ymin(i) = min(ymin(i), vmin);
                    end
                    if isnan(ymax)
                        ymax(i) = vmax;
                    else
                        ymax(i) = max(ymax(i), vmax);
                    end
                end
            end
        end
    end
end

% Set all y axes to the same scale and center each data set.

range = ymax - ymin;
if isempty(scale)
    scale = ceil(100 * max(range)) / 100; % Limit to 2 decimal points.
end

for i = 1:n
    if ~isnan(range(i))
        dy = (scale - range(i)) / 2;
        ylim(axes_list(i), [ymin(i) - dy, ymax(i) + dy]);
    end
end


