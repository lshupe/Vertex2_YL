function[neuron_to_group] = get_neuron_to_group(params)
    group_boundaries = params.TissueParams.groupBoundaryIDArr;
    num_neurons = params.TissueParams.N;
    neuron_to_group = zeros(num_neurons, 1, 'int8');
    for neuron_id = 1:num_neurons
        neuron_to_group(neuron_id) = get_neuron_group(neuron_id, group_boundaries);
    end
end

function[group] = get_neuron_group(neuron_id, group_boundaries)
    for i = 2:length(group_boundaries)
        if neuron_id <= group_boundaries(i)
            group = i - 1;
            return
        end
    end
    error(strcat("No group found for neuron id: ", num2str(neuron_id)));
end
