function [] = disp_with_time(message)
    time = datestr(now,'yyyy-mm-dd HH:MM:SS');
    disp(strcat(time, ": ", message));
end

