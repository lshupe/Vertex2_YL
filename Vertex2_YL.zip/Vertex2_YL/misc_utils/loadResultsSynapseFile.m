function [syn_arr] = loadResultsSynapseFile(saveDir, fName)
%loadResultsWeightFile loads a weights array from a weights file.
%   syn_arr = loadResultsSynapseFile(saveDir, fName)
%       syn_arr{iN,1} contains Target units for Source unit iN
%       syn_arr{iN,2} is the Target unit Compartment
%       syn_arr{iN,3} is the synapse Delay steps
%
%   Loads a synapse file saved by runSimulation().
%
%   saveDir is a character array (string) specifying the directory where
%   the simulation results were saved.
%
%   fName is the file prefix which is usually 'synapses', or 'synapses_',
%   If fName ends in a '_' then a series of synapse files are loaded and
%   reconstructed from the parallel saved files.

syn_arr = {};

if ~strcmpi(saveDir(end), '/')
    saveDir = [saveDir '/'];
end

parallel_mode = (fName(end) == '_');
n = 1;
should_load_next_file = true;
while should_load_next_file
    if parallel_mode
        file_name = [saveDir fName num2str(n) '.mat'];
    else
        file_name = [saveDir fName '.mat'];
        should_load_next_file = false; % only 1 file to read
    end
    if ~exist(file_name, 'file')
        should_load_next_file = false;
        if n == 1
            disp(['Load syanpses failed: ' file_name ' not found.']);
        end
    else
        loadedData = load(file_name);
        ff = fields(loadedData);
        sArr = loadedData.(ff{1});
        if n == 1
            syn_arr = sArr;
        else
            % Append synapse information
            for iN = 1:length(syn_arr)
               syn_arr{iN,1}(end+1:end+length(sArr{iN,1})) = sArr{iN,1}; % Target unit
               syn_arr{iN,2}(end+1:end+length(sArr{iN,2})) = sArr{iN,2}; % Target Compartment
               syn_arr{iN,3}(end+1:end+length(sArr{iN,3})) = sArr{iN,3}; % Delay steps
            end
        end
    end
    n = n + 1; % Next file index
end
