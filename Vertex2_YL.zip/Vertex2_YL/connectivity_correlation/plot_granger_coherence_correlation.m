% load granger
granger_res = load('~/vertex_results/nsg_40s_54el_1p5arb/granger.mat');
granger_freqs = granger_res.freqs;
granger_metric = granger_res.grang_mat;

% load coherence
coherence_res = load('~/vertex_results/nsg_40s_54el_1p5arb/coherence.mat');
coherence_freqs = coherence_res.f;
coherence_metric = coherence_res.c;
coherence_freqs_with_round = zeros(length(coherence_freqs), 2);
coherence_freqs_with_round(:, 1) = round(coherence_freqs);
coherence_freqs_with_round(:, 2) = coherence_freqs;

selected_coherences = zeros(501, 1);
cur_freq = 0;
cur_smallest = intmax;
cur_smallest_index = 0;
for i = 1:length(coherence_freqs_with_round)
    rounded_freq = coherence_freqs_with_round(i, 1);
    freq = coherence_freqs_with_round(i, 2);
    diff = abs(rounded_freq - freq);
    if rounded_freq == cur_freq
        % same frequency, compare
        if diff < cur_smallest
            % found smaller, update
            cur_smallest = diff;
            cur_smallest_index = i;
        end
    else
        % diff frequency, update cur_freq
        selected_coherences(cur_freq + 1) = cur_smallest_index;
        cur_freq = rounded_freq;
        cur_smallest = diff;
        cur_smallest_index = i;
    end
end
selected_coherences(cur_freq + 1) = cur_smallest_index;

correlation_by_freq = zeros(501, 2);
correlation_by_freq(:, 1) = granger_freqs;
for i = 1:length(granger_freqs)
    granger_matrix = granger_metric(:, :, i);
    granger_plus_trans = granger_matrix + granger_matrix';
    coherence_index = selected_coherences(i);
    coherence_matrix = coherence_metric(:, :, coherence_index);
    % rows = complete setting to ignore NaN elements
    correlation = corrcoef(granger_plus_trans, coherence_matrix, 'rows', 'complete');
    % correlation(1, 2) should = correlation(2, 1) so just choose one
    correlation_by_freq(i, 2) = correlation(1, 2);
end

l1 = plot(correlation_by_freq(:, 1), correlation_by_freq(:, 2), 'blue');
hold on

legend([l1], ...
    {'Coherence-Pairwise Granger Correlation'});
title('Correlation of Coherence to Pairwise Granger by Frequency')
xlabel('Frequency (Hz)')
ylabel('Pearsons Correlation Coefficient')
grid off
set(gca,'box','off')
hold off


