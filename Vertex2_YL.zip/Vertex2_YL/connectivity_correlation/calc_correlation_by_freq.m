function [correlation_by_freq] = calc_correlation_by_freq(freqs, metric, ground_truth)
% Calculation of correlation of a certain metric to ground truth by
% frequency band
%   freqs: num_freqs x 1 matrix containing frequency values
%   metrics: num_electrode x num_electrode x num_freqs matrix, metric of
%       interest
%   ground_truth: num_electrode x num_electrode matrix

correlation_by_freq = zeros(length(freqs), 2);
correlation_by_freq(:, 1) = freqs;
for i = 1:length(freqs)
    metric_matrix = metric(:, :, i);
    % rows = complete setting to ignore NaN elements
    correlation = corrcoef(ground_truth, metric_matrix, 'rows', 'complete');
    % correlation(1, 2) should = correlation(2, 1) so just choose one
    correlation_by_freq(i, 2) = correlation(1, 2);
end

end

