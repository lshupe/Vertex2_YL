% load coherence
% coherence_res = load('~/vertex_results/nsg_40s_54el_1p5arb/coherence.mat');
% freqs = coherence_res.f;
% metric = coherence_res.c;
freqs = pgrang_f;
metric = pgrang_m;
% load ground truth
ground_truth_res = load('~/vertex_results/random_con_scale_1_40s/ground_truth_all_900.mat');
ground_truth_matrix = ground_truth_res.res;

partial_granger_correlation_by_freq_900 = calc_correlation_by_freq(freqs, metric, ground_truth_matrix);



