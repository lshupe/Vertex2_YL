windowSize = 10; 
b = (1/windowSize)*ones(1,windowSize);
a = 1;
smoothed_correlation = filter(b, a, coherence_correlation_by_freq_900(:, 2));
l1 = plot(coherence_correlation_by_freq_900(:, 1), smoothed_correlation, 'blue');
hold on
l2 = plot(pairwise_granger_correlation_by_freq_900(:, 1), pairwise_granger_correlation_by_freq_900(:, 2), 'green');
l3 = plot(partial_granger_correlation_by_freq_900(:, 1), partial_granger_correlation_by_freq_900(:, 2), 'red');


legend([l1, l2, l3], ...
    {'Coherence', 'Pairwise Granger Causality', 'Partial Granger Causality'}, ...
    'Location', 'southeast');
title('Correlation of Functional Connectivity Metrics to Anatomical Connectivity Between Recording Sites by Frequency')
xlabel('Frequency (Hz)')
ylabel('Pearsons Correlation Coefficient')
grid off
set(gca,'box','off')
hold off