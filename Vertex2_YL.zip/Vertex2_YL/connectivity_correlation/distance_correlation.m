% load ground truth
ground_truth_res = load('~/vertex_results/random_con_scale_1_40s/ground_truth_all_900.mat');
ground_truth_matrix = ground_truth_res.res;

params = load_params_from_dir('~/vertex_results/random_con_long');
rs = params.RecordingSettings;
len = length(rs.meaXpositions);
distance_matrix = zeros(len, len);
for i = 1:len
    for j = 1:len
        distance_matrix(i, j) = sqrt(...
            (rs.meaXpositions(i) - rs.meaXpositions(j)) ^ 2 + ...
            (rs.meaYpositions(i) - rs.meaYpositions(j)) ^ 2 + ...
            (rs.meaZpositions(i) - rs.meaZpositions(j)) ^ 2);
    end
end
% rows = complete setting to ignore NaN elements
correlation = corrcoef(ground_truth_matrix, distance_matrix, 'rows', 'complete');
% correlation(1, 2) should = correlation(2, 1) so just choose one
dist_correlation = correlation(1, 2);
fprintf("Distance Correlation: %f\n", dist_correlation);  
distance_flattened = distance_matrix(:);
ground_truth_flattened = ground_truth_matrix(:);
scatter(distance_flattened, ground_truth_flattened)
hold on
title("All Anatomical Connectivity with Respect to Distance");
ylabel("Anatomical Connectivity Weight");
xlabel("Distance (micrometers)");
coefficients = polyfit(distance_flattened, ground_truth_flattened, 1);
x_fit = linspace(min(distance_flattened), max(distance_flattened), 1000);
y_fit = polyval(coefficients , x_fit);
plot(x_fit, y_fit)
hold off