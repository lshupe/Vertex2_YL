% Main function for simulations with Spike-Timing Dependant Plasticity
% and field stimulation conditioning
function [params, connections, electrodes] = run_bsf_model_stdp_sim(...
    xy_length, simulation_time, electrode_pos, directory, setup)

% setup.should_save_randomized_connectivity should be false for local run
% (don't save anything)
%SMALL_BSF_MODEL_FUNC Function that initializes and simulates a bsf model 
% of arbitrary X-Y square grid. 
% Outputs to directory:
%   Simulation data
%   For each specified LFP, saves fig and png of plot and spectrogram
%   fig and png of spike raster 
% Params: 
%   length: in micrometers, length of X-Y square. 
%   electrode_pos: 2-d array, x,y coords of each electrode to be placed. 
%       columns represent x,y, rows are each electrode
%   directory: path to save the results
%
% Change log:
% 10/26/2022 Forked from run_bsf_model_local.m
% 10/26/2022 Additional setup: bsf_stdp, bsf_paired_pulse_stimulation
% 12/15/2022 added setup input structure to combine the setup parameters.
%   setup.run_local = true; % for running the local machine
% 1/25/2023 added b_4_mean_scaler copied latest parameter setup.

if setup.run_local
    mkdir(".", directory);
    diary([directory '\cmdlog.txt']);
end

if ~exist('setup', 'var')
    setup = [];
end

if ~isfield(setup, 'run_local')
    setup.run_local = false;
end

input_std_scaler = 1;
if isfield(setup, 'input_std_scaler')
    input_std_scaler = setup.input_std_scaler;
end

input_mean_scaler = 1;
if isfield(setup, 'input_mean_scaler')
    input_mean_scaler = setup.input_mean_scaler;
end

p23_scaler = 1;
if isfield(setup, 'p23_scaler')
    p23_scaler = setup.p23_scaler;
end

b_4_mean_scaler = 1;
if isfield(setup, 'b_4_mean_scaler')
    b_4_mean_scaler = setup.b_4_mean_scaler;
end

b_2_3_std_scaler = 1;
if isfield(setup, 'b_2_3_std_scaler')
    b_2_3_std_scaler = setup.b_2_3_std_scaler;
end

arb_radius_scaler = 1;
if isfield(setup, 'arb_radius_scaler')
    arb_radius_scaler = setup.arb_radius_scaler;
end

should_save_model = false;
if isfield(setup, 'should_save_model')
    should_save_model = setup.should_save_model;
end

should_save_ground_truth = false;
if isfield(setup, 'should_save_ground_truth')
    should_save_ground_truth = setup.should_save_ground_truth;
end

should_save_randomized_connectivity = true;
if isfield(setup, 'should_save_randomized_connectivity')
    should_save_randomized_connectivity = setup.should_save_randomized_connectivity;
end

should_save_v = false;
if isfield(setup, 'should_save_v')
    should_save_v = setup.should_save_v;
end

% Import all the default BSF model variables first

bsf_tissue;   
bsf_neurons;
bsf_connectivity_dist;
bsf_recording;
bsf_simulation;

% Override Tissue params X-Y dimensions to be xy_length
TP.X = xy_length(1);
TP.Y = xy_length(end);

% Override directory
RS.saveDir = directory;
RS.sampleRate = 1000;   % LFP samples per second
RS.maxRecTime = 200;    % Number of milliseconds of LFP stored in each Recordings<n>.mat file
if should_save_v
    RS.v_m = 1:1:224260; % Record membrane potentials for 1.5 size full
else
    RS.v_m = []; % Not recording membrane potentials.
end

% Override recording settings
RS.meaXpositions = electrode_pos(:, 1).';
RS.meaYpositions = electrode_pos(:, 2).';
if size(electrode_pos, 2) == 3
    RS.meaZpositions = TP.Z - electrode_pos(:, 3).';
else
    RS.meaZpositions = TP.Z * ones(1, size(electrode_pos, 1));
end
if isfield(setup, 'weight_save_time_ms')
  % Record extra weight matrices during the simulation.
  RS.weight_save_time_steps = floor(setup.weight_save_time_ms / SS.timeStep);
end

% Local runs lower neuron density to speed up simulation for testing.
if setup.run_local
    TP.neuronDensity = TP.neuronDensity / 25; % /25 for testing
end

% Set simulations settings to be able to run on machine
SS.parallelSim = true;
SS.poolSize = 8;     % Set workers for runs on cluster
if setup.run_local
	SS.poolSize = 2; % Set workers for local machine
end
SS.simulationTime = simulation_time;

% Spike-Timing Dependant Plasticity setings after final dimensions and times are set.
SS.stdp = false; % Off by default, caller sets setup.stdp_enabled = true to turn plasticity on.
if isfield(setup, 'stdp_enabled')
    SS.stdp = setup.stdp_enabled;
    if SS.stdp 
        bsf_stdp;
    end
end

% Field stimulation settings after final dimensions and times are set.
SS.field_stim_type = 'none'; % No stimulation by default
if isfield(setup, 'field_stim_type')
    SS.field_stim_type = setup.field_stim_type;
    if ~strcmpi(SS.field_stim_type, 'none')
        run(setup.field_stim_setup_script);
    end
end

% Optogenetic stimulation enabled by setup.opto_stim_type = 'pulse_train'
% or 'closed_loop'
SS.opto_stim_type = 'none';  % No optical stimulation by default
if isfield(setup, 'opto_stim_type')
    SS.opto_stim_type = setup.opto_stim_type;  
    if ~strcmpi(SS.opto_stim_type, 'none')
        run(setup.opto_stim_setup_script);
    end
end

% Optionally load weights from a previously saved simulation with the
% exact same topology, random seed, and parallel processor cores.
% Example: SS.LoadWeightsFromFile = './weights_';
% This will load files 'weights_1.mat', 'weights_2.mat', ... into
% Lab 1,2,... after weights have been initialized runSimulation.m.
if isfield(setup, 'LoadWeightsFromFile')
    SS.LoadWeightsFromFile = setup.LoadWeightsFromFile;
end

%%
% Initialise the network
disp_with_time("Intializing Network...");
[params, connections, electrodes] = initNetwork(TP, NP, CP, RS, SS);

%%
% Run the simulation
disp_with_time("Network Initialization completed, Running Simulation with Stimulation...");
runSimulation_stim(params, connections, electrodes, should_save_randomized_connectivity);
disp_with_time("Simulation Finished");

if should_save_model
    save_network(directory, params, connections, electrodes);
end

if should_save_ground_truth
    save_ground_truth(directory, params, connections);
end

%%
% Report Matlab version
%ver

%%
% Delete Parallel Pool

if setup.run_local
    diary off;
else
    p = gcp('nocreate');
    if ~isempty(p)
        disp_with_time("Parallel Pool exists with the following properties, deleting");
        disp(p);
        delete(p);
    end
end