function [params, connections, electrodes] = run_bsf_model_sim(...
    length, time, electrode_pos, ...
    directory, input_std_scaler, ...
    input_mean_scaler, b_2_3_std_scalar, arb_radius_scalar, ...
    should_save_model, should_save_ground_truth, should_save_randomized_connectivity)

%SMALL_BSF_MODEL_FUNC Function that initializes and simulates a bsf model 
% of arbitrary X-Y square grid. 
% Outputs to directory:
%   Simulation data
%   For each specified LFP, saves fig and png of plot and spectrogram
%   fig and png of spike raster 
% Params: 
%   length: in micrometers, length of X-Y square. 
%   electrode_pos: 3-d array, x,y,z coords of each electrode to be placed. 
%       columns represent x,y, rows are each electrode
%   directory: path to save the results

% Import all the default BSF model variables first

if ~exist('input_std_scaler', 'var')
    input_std_scaler = 1;
end

if ~exist('input_mean_scaler', 'var')
    input_mean_scaler = 1;
end

if ~exist('b_2_3_std_scalar', 'var')
    b_2_3_std_scalar = 1;
end

if ~exist('arb_radius_scalar', 'var')
    arb_radius_scalar = 1;
end

if ~exist('should_save_model', 'var')
    should_save_model = true;
end

if ~exist('should_save_ground_truth', 'var')
    should_save_ground_truth = true;
end

if ~exist('should_save_randomized_connectivity', 'var')
    should_save_randomized_connectivity = true;
end

bsf_tissue;    
bsf_neurons;
bsf_connectivity_dist;
bsf_recording;
bsf_simulation;
%bsf_field_stimulation;

% Override Tissue params X-Y dimenstions to be length
TP.X = length;
TP.Y = length;

% Override directory
RS.saveDir = directory;

% Set simulations settings to be able to run on machine
SS.parallelSim = true;
SS.poolSize = 16; 
SS.profileName = 'local';
SS.simulationTime = time;

% Override recording settings
RS.meaXpositions = electrode_pos(:, 1).';
RS.meaYpositions = electrode_pos(:, 2).';
if size(electrode_pos, 2) == 3
    RS.meaZpositions = 2600 - electrode_pos(:, 3).';
else
    RS.meaZpositions = 2600 * ones(1, size(electrode_pos, 1));
end
% remove membrane potential settings, we're not recording that yet
%RS.v_m = [];
%%
% Initialise the network
disp_with_time("Intializing Network...");
[params, connections, electrodes] = initNetwork(TP, NP, CP, RS, SS);

%%
% Run the simulation
disp_with_time("Network Initialization completed, Running Simulation...");
runSimulation(params, connections, electrodes, should_save_randomized_connectivity);
disp_with_time("Simulation Finished");

if should_save_model
    save_network(directory, params, connections, electrodes);
end

if should_save_ground_truth
    save_ground_truth(directory, params, connections);
end

%%
% Delete Parallel Pool if it exists
p = gcp('nocreate');
if ~isempty(p)
    disp_with_time("Parallel Pool exists with the following properties, deleting");
    disp(p);
    delete(p);
end

end

