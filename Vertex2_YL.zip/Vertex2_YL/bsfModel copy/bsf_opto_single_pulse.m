% Optogenetic stimulation settings for single pulse at 5 Hz
% This requires InputModel_i_opto.m and a change in setupInputDynamicVars.m
% to send TissueParameters (TP) to all input models on initialization.
% TP is used to determine how far each neuron is from each light source.
%
% setupInputDynamicVars.m lines 11, and 35..37
% 11   if isfield(NP(iGroup).Input(iIn), 'compartments') && ~isempty(NP(iGroup).Input(iIn).compartments)
%
% 35   InputModelArr{iGroup,iIn} = ...
% 36      constructor(NP(iGroup), iIn, ...
% 37      TP.numInGroupInLab(iGroup, labindex()), SS.timeStep, comparts, subsetInLab, TP);
%
% Any other input models used must have their initializers changed to
% accept TP as a parameter, for example:
%
% InputModel.m line 9
% 09   function IM = InputModel(N, inputID, number, compartmentsInput, subset, TP)
%
% InputModel_i_ou.m line 29
% 29   function IM = InputModel_i_ou(N, inputID, number, timeStep, compartmentsInput, subset, TP)
%
% In this module we define the parameters for light sources, a pulse
% train for each light source, and an InputModel for each neuron group
% affected by each light source.
%
% Pulse trains are started from within simulateParallel_stim.m
%
% For example, to start a pulse train for neuron groups affected by light
% source iopto, a call needs to be made to OptoStartPulseTrain() for each 
% neuron group assigned to that light source. If the pulse train parameters
% have changed this should be preceded by a call to OptoSetupPulseTrain().
% OptoStepOn() and OptoStepOff() may be called for direct control over each
% light source, but this should only be done if the pulse train is stopped.
% 
%     opto_groups = TP.opto_neuron_groups{iopto};
%     for index = 1:length(opto_groups)
%         iGroup = opto_groups(index);
%         iIn = TP.opto_input_model_index(iGroup, iopto);
%         % OptoSetupPulseTrain(InModel{iGroup, iIn}, TP); % Setup pulse train if the pulse train parameters have changed.
%         OptoStartPulseTrain(InModel{iGroup, iIn}, delay_ms); % Start train at a delay from current timestep
%         % OptoStartPulseTrain(InModel{iGroup, iIn}, -1); % Stop a train in progress.
%         % OptoStepOn(InModel{iGroup, iIn})   % Used to turn light on
%         % OptoStepOff(InModel{iGroup, iIn})  % Used to turn light off
%     end

if ~isfield(SS, 'opto_stim_type')
    SS.opto_stim_type = 'none'; % Stimulation off by default
end

if ~any(strcmpi(SS.opto_stim_type, {'open_loop', 'closed_loop'}))
    disp_with_time('Optogenetic stimulation module is included but inactive.');
else
    numGroups = length(NP);
    disp_with_time(['Optogenetic stimulation module is active (' SS.opto_stim_type ' mode): Single Pulse']);
    TP.opto_source_power_mW = [7.2]; % Light source output power in milli-Watts.
    TP.opto_source_diameter = [200]; % Micron diameter of optical light sources.
    TP.opto_source_tau = [100];      % Light source exponential fall-off in microns.
    TP.opto_neuron_groups = {[1:15]};% Which neuron groups have opto-receptors, excitatory = [1 4 5 6 9 10 13 14]; inhibitory = [2 3 7 8 11 12 15];

    % Pulse train parameters
    TP.opto_isi_ms = 200;                 % Interval between trains.
    TP.opto_pulse_freq = [20];        % Pulses per second in each train.
    TP.opto_pulse_count = [1];         % Number of pulses in each train.
    TP.opto_train_delay_ms = [0];     % Delay to the first pulse in the train.
    TP.opto_pulse_duration_ms = [5];   % Duration of pulse

    % Define position of optical light sources
    opto_source_layer = [1.0];     % Target layer. 1.0 is surface. n.0 = top of layer n, n.5 = middle of layer n.
    TP.opto_source_xpos = floor(TP.X * [1/2]); % 1/3 and 2/3 of X slice.
    TP.opto_source_ypos = floor(TP.Y * [0.5]); % Middle of the Y slice.
    
    % Setup stimulation times. For closed_loop, this can be an empty list so that
    % stimulation times can be started based on conditions during run time.

    if isfield(RS, 'weight_save_time_steps') && (length(RS.weight_save_time_steps) >= 2)
        stim_start_ms = RS.weight_save_time_steps(1) * SS.timeStep;
        stim_stop_ms = RS.weight_save_time_steps(2) * SS.timeStep;
    else
        stim_start_ms = SS.simulationTime / 6;
        stim_stop_ms = SS.simulationTime * 5 / 6;  
    end
    TP.stim_start_ms = stim_start_ms;
    TP.stim_stop_ms = stim_stop_ms;

    % Calculate start times for each stimulation pattern.
    % Leave this array empty for close-loop stimulation where stimulation
    % times must be activated during the simulation. The existence of 
    % TP.opto_stim_ms is used to test if optical stimulation is running

    TP.opto_stim_ms = stim_start_ms : TP.opto_isi_ms : stim_stop_ms - TP.opto_isi_ms;
    if strcmpi(SS.opto_stim_type, 'closed_loop')
        TP.opto_stim_ms = [];         % [] For closed loop stimulation.
        TP.LFP_filter_band = [20 30]; % Hz for butterworth bandpass filter
        TP.LFP_filter_index = 2;      % Index of LFP electrode
        TP.LFP_trigger_direction = -1; % 1 = rising, -1 = falling, 0 = disabled
        TP.LFP_trigger_level = 0;     % LFP triggering threshold
        TP.LFP_trigger_amplitude = 0.004;     % Required amplitude of preceding max or |min|
        TP.LFP_trigger_refractory_ms = 150;   % Should be > stimulus train duration
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Exact timestep of pulse train starts
    % The existence of this field is used to test if optical stimulation is running
    TP.opto_stim_timesteps = floor(TP.opto_stim_ms / SS.timeStep);

    % Convert light source layer to tissue z position
    layer_tops = TP.layerBoundaryArr';
    layer_thickness = diff(layer_tops);
    target_layers = floor(opto_source_layer);
    percent_to_next_layer = opto_source_layer - target_layers;
    TP.opto_source_zpos = layer_tops(target_layers) + percent_to_next_layer .* layer_thickness(target_layers);
            
    % Define optically activated inputs for affected neuron groups.
    n_opto_sources = length(TP.opto_source_power_mW);
    TP.opto_input_model_index = zeros(numGroups, n_opto_sources); % Used to find InputModel_i_opto objects
    for iopto = 1:n_opto_sources  % For each light source      
        opto_groups = TP.opto_neuron_groups{iopto};
        for igroup = opto_groups % For each group affected by the light source
           iIn = length(NP(igroup).Input) + 1; % Define one more input to this neuron group.
           NP(igroup).Input(iIn).inputType = 'i_opto';
           NP(igroup).Input(iIn).irradianceFNC = 'opto_irradiance_exp';
           NP(igroup).Input(iIn).currentFNC = 'opto_current_exp';
           NP(igroup).Input(iIn).tau_on = 1.5;      % ms. Stimulation-on asymptotic rise constant.   ChR2 time constant from Foutz,Arlow,McIntire 2012,
           NP(igroup).Input(iIn).tau_off = 11.6;    % ms. Stimulation-off decay constant.           https://doi.org/10.1152/jn.00501.2011
           NP(igroup).Input(iIn).compartments = [1]; % [1] Apply to soma compartment
           NP(igroup).Input(iIn).opto_source_index = iopto; % Index of the light source.
           NP(igroup).Input(iIn).groupID = igroup;   % Need this to access tissue parameters from within the input model instance
           TP.opto_input_model_index(igroup, iopto) = iIn;  % Index of the input model instance
        end
    end
      
end
