%% Spike-Timing Dependant Plasticity settings

if ~isfield(SS, 'stdp')
    SS.stdp = false; % false to turn stimulation off and disregard setup
end

if ~SS.stdp
    disp_with_time('STDP module is included but inactive.');
else
    disp_with_time('STDP module is active.');
    
    % In Bi and Poo (2001 Fig1) the time constant for potentiation was
    % estimated as 17 ms and 34 ms for depression. The scaling amplitudes were
    % A = 0.777 and −0.273, but here the scalers are used to balance the area
    % between the two sides of the plasticity curve with the depression side
    % having slightly more area to help prevent runaway weights and make
    % conditioning effects stand out. There is no active mechanism for weight
    % homeostasis other than clipping to minimum and maximum values.
    
    stdp_synapse_model = 'g_exp_stdp'; % 'g_exp_stdp_delays' is very slow but models axonal delays (not dendritic)
    stdp_neuron_groups = [1:15]; % excitatory = [1 4 5 6 9 10 13 14]; inhibitory = [2 3 7 8 11 12 15];

    stdp_minimum_weight = 0.001;
    stdp_maximum_weight = 4;
    % Hebbian potentiating side of plasticity curve
    stdp_presynaptic_activity_scaler = 0.005; % Largest strengthening weight change possible for each pair of spikes.
    stdp_presynaptic_activity_time_constant = 17; % milliseconds
    % Depression side with somewhat more area due to larger time constant.
    %stdp_postsynaptic_activity_scaler = -0.50 * stdp_presynaptic_activity_scaler; % Weakening scaler for equal STDP areas
    stdp_postsynaptic_activity_scaler = -0.53 * stdp_presynaptic_activity_scaler; % Weakening scaler for slightly more depression than potentiation
    %stdp_postsynaptic_activity_scaler = -0.55 * stdp_presynaptic_activity_scaler; % Weakening scaler for more depression than potentiation
    stdp_postsynaptic_activity_time_constant = 2 * stdp_presynaptic_activity_time_constant;
    
    % STDP synapse models maintain pre and post synaptic activity state with
    % exponentially decaying values.
    %   Apre: Models recent presynaptic activity, decays with tau = tPre
    %   Apost: Models recent postsynaptic activy, decays with tau = tPost
    % When the postsynaptic unit fires, Apost is updated with postRate and
    %   Apre strengthena the connection.
    % When the presynaptic unit fires, Apre is updated with preRate and
    %   Apost weakens the connection.
    
    for iPre = 1:TP.numGroups
        %NP(iPre).Input(1).inputType = 'i_ou_rand';  % Change neuron input model here if desired.
        
        for iPost = 1:TP.numGroups
            % Replace Synapse Model with one supporting STDP
            if ismember(iPre, stdp_neuron_groups)
                CP(iPre).synapseType{iPost} = stdp_synapse_model;
            end
            
            % Settings for 'g_exp_stdp' or 'g_exp_stdp_delays'
            CP(iPre).preRate{iPost} = stdp_presynaptic_activity_scaler;
            CP(iPre).postRate{iPost} = stdp_postsynaptic_activity_scaler;
            CP(iPre).tPre{iPost} = stdp_presynaptic_activity_time_constant;
            CP(iPre).tPost{iPost} = stdp_postsynaptic_activity_time_constant;
            CP(iPre).wmin{iPost} = stdp_minimum_weight;
            CP(iPre).wmax{iPost} = stdp_maximum_weight;
        end
    end
    
    clear iPre iPost;
end