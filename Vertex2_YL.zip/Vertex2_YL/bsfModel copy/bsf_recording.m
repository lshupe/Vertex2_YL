RS.saveDir = '~/VERTEX_bsf_results/';
RS.LFP = true;
[meaX, meaY, meaZ] = meshgrid(-400:400:4400, 200, 2450:-400:-1150);
RS.meaXpositions = meaX;
RS.meaYpositions = meaY;
RS.meaZpositions = meaZ;
RS.minDistToElectrodeTip = 20;
RS.maxRecTime = 500;
RS.sampleRate = 1000;
% RS.v_m = 1:1:224260; % for 1.5 size full
% RS.v_m = 1:1:622944; % for 2.5 size full
% RS.v_m = 1:1:997; % for local
clear meaX meaY meaZ;