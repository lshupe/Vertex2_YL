
%stimstrength=2;
%B=20; % the frequency in Hz.
%TP.StimulationField = invitroSliceStim('bsf.stl',stimstrength);
TP.StimulationField = result;


TP.StimulationOn = 0;
TP.StimulationOff = SS.simulationTime;