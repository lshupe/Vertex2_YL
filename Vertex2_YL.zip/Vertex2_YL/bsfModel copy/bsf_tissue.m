TP.X = 4400;
TP.Y = 400;
TP.Z = 2600;
TP.neuronDensity = 38335;
TP.layerBoundaryArr = [2600 2362 1835 1122 832 0];
TP.numLayers = 5;
TP.numGroups = 15;
TP.tissueConductivity = 0.3;
TP.numStrips = 44;
TP.maxZOverlap = [0 -25]; % [0 -25] for standard neuron placement.
% The first number in maxZOverlap is the neuron-position overlap (in microns) 
% with the previous layer. If greater than zero, this creates a linear
% gradiant overlap of the specified thickness between layers.  This is
% done in \vertex\vertex_netgen\positionNeurons.m
% Leave the second number negative unless you understand what it does.
