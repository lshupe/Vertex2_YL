% Stimulation settings for single-pulse field stimulatin
%
% Stimulation is a symmeteric bipolar biphasic current pulse with the
% cathode first phase current given by TP.stim_size which can be negative
% as is the case in many physiology experiments.  The anode_current
% is -cathode_current for a differential stimulus. Currents are inverted
% for the second phase which occurs halfway through TP.stim_width_ms.
% The electrodes here differ from the second Vertex2 paper in that they
% travel vertically down through the tissue layers and only the tips are
% conductive.

if ~isfield(SS, 'field_stim_type')
    SS.field_stim_type = 'none'; % Stimulation off by default
end

if ~any(strcmpi(SS.field_stim_type, {'open_loop', 'closed_loop'}))
    disp_with_time('Pattern field stimulation module is included but inactive.');
else
    disp_with_time(['Pattern field stimulation module is active (' SS.field_stim_type ' mode)']);
    TP.stim_isi_ms = 200;   % Time between stimulation events
    TP.stim_phases = 2;     % 2 for a biphasic 50% pos / 50% neg waveform, otherwise stimulation is monophasic.
    TP.stim_size = [-1000; -1000; -1000; -1000]; % Stimulation mV for cathode first phase. In physiology experiments this is often negative.
    TP.stim_width_ms = [0.4; 0.4; 0.4; 0.4]; % Stimulation width (sum both phases)

    % Delay from start of stimulation for each differential electrode pair.
    % Must be positive and large enough to prevent overlap between pulses,
    % but do not need to be in order.
    % Negative values will disable that one electrode pair.  If this is a
    % single value, then it is used as an inter-stimulus delay and the
    % electrode pairs will be stimulated in order from 1:n.
    TP.stim_delay_ms = [0; 15; 30; 45]; 

    % Stimulation time window is between the first two weight save times, or
    % or in the middle of the simulation time
    if isfield(RS, 'weight_save_time_steps') && (length(RS.weight_save_time_steps) >= 2)
        stim_start_ms = RS.weight_save_time_steps(1) * SS.timeStep;
        stim_stop_ms = RS.weight_save_time_steps(2) * SS.timeStep;
    else
        stim_start_ms = 2000;
        stim_stop_ms = SS.simulationTime - 2000;  
    end
    TP.stim_start_ms = stim_start_ms;
    TP.stim_stop_ms = stim_stop_ms;

    % Calculate start times for each stimulation pattern.
    % Leave this array empty for close-loop stimulation where stimulation
    % times must be activated during the simulation. The existence of
    % TP.stim_ms is used to test if field stimulation is running.
    
    TP.stim_ms = stim_start_ms : TP.stim_isi_ms : stim_stop_ms-TP.stim_isi_ms;
    if strcmpi(SS.field_stim_type, 'closed_loop')
         TP.LFP_filter_band = [5 120]; % Hz passband for butterworth filter
         TP.LFP_filter_index = 2;      % Index of LFP electrode
         TP.LFP_stim_max_response = 0.1; % decrease stimulus if LFP amplitude > this
         TP.LFP_stim_min_response = 0.1; % Increase stimulus if LFP amplitude < this
         TP.LFP_stim_scaler = 1.05;      % 5% stimulus adjustment
    end

    % Define pairs of differental electrodes [cathode1 anode1; cathode2 anode2; ...]
    ew = 35; % Electrode base width (microns)
    tl = 50; % Electrode tip length (microns)
    TP.stim_electrode_base_xy = [ew ew ew ew; ew ew ew ew; ew ew ew ew; ew ew ew ew];  % micron xy wire diameters =  [x1 y1 x2 y2;]
    TP.stim_electrode_tip_xy = [2 2 2 2; 2 2 2 2; 2 2 2 2; 2 2 2 2];   % micron xy wire tip diameters =  [tx1 ty1 tx2 ty2;]
    TP.stim_electrode_tip_length = [tl tl; tl tl; tl tl; tl tl]; % micron length of each conductive tip = [catlen anolen;]
    TP.stim_electrode_insulation_thickness = [2 2; 2 2; 2 2; 2 2]; % micron insulation thickness (>= 1)
    stim_electrode_layer = [2.5 2.5; 2.5 2.5; 2.5 2.5; 2.5 2.5];   % target layer depth. (1.0 = top of layer 1, 2.5 = middle of layer 2).
    dxy = 100 / sqrt(2) / 2; % For 100 micron tip separation.
    TP.stim_electrode_xpos = TP.X * [1/3 1/3; 2/3 2/3; 2/3 2/3; 1/3 1/3] + [-dxy dxy; -dxy dxy; -dxy dxy; -dxy dxy]; % X with tip separation in microns
    TP.stim_electrode_ypos = TP.Y * [1/3 1/3; 2/3 2/3; 1/3 1/3; 2/3 2/3] + [-dxy dxy; -dxy dxy; -dxy dxy; -dxy dxy]; % Middle of the Y slice with tip separation.

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate electrode topology and electric fields

    % Convert electrode target layer to tissue z position
    layer_tops = TP.layerBoundaryArr;
    layer_thickness = diff(layer_tops);
    target_layers = floor(stim_electrode_layer);
    percent_to_next_layer = stim_electrode_layer - target_layers;
    TP.stim_electrode_zpos = layer_tops(target_layers) + percent_to_next_layer .* layer_thickness(target_layers);

    xbounds = [-200 TP.X+200]; % Geometry is a bounding box with long rectangular holes for the cathode and anode cut into the Ymax plane
    ybounds = [-200 TP.Y+200]; % Cathode and anode tips should have very similar Z positions since the tesselation
    zbounds = [-200 TP.Z+200]; % assumes line of sight from external corners to closest Z-axis electrode tip corners.
    
    hfig = figure; % Figure for electrode geometry
    stim_n_electrodes = size(TP.stim_electrode_xpos, 1);
    for diffpair = 1:stim_n_electrodes
        cathode_tip_position = [TP.stim_electrode_xpos(diffpair, 1) ...
            TP.stim_electrode_ypos(diffpair, 1) ...
            TP.stim_electrode_zpos(diffpair, 1)];
        
        anode_tip_position = [TP.stim_electrode_xpos(diffpair, 2) ...
            TP.stim_electrode_ypos(diffpair, 2) ...
            TP.stim_electrode_zpos(diffpair, 2)];
       
        % Construct and plot 3D model of electrodes.
        [model, outerfaces, cathodefaces, anodefaces, cat_ins, ano_ins] = ...
            BipolarElectrodeVerticalGeometry(xbounds, ybounds, zbounds,...
            cathode_tip_position, anode_tip_position, ...
            TP.stim_electrode_base_xy(diffpair,:), ...
            TP.stim_electrode_tip_xy(diffpair,:), ...
            TP.stim_electrode_tip_length(diffpair,:), ...
            TP.stim_electrode_insulation_thickness(diffpair,:));
        
        hold on; % Plot all electrodes on same figure

        % Constructs a PDEmodel from the given geometry.
        % Bipolar +strength on anode, -strength on cathode during 1st phase.
        applyBoundaryCondition(model, 'face',[outerfaces cat_ins ano_ins], 'g',0.0, 'q',0.0);
        applyBoundaryCondition(model, 'face',cathodefaces, 'h',1.0, 'r',TP.stim_size(diffpair)); % mV
        applyBoundaryCondition(model, 'face',anodefaces, 'h',1.0, 'r',-TP.stim_size(diffpair));  % mV   
        warning('off', 'MATLAB:subscripting:noSubscriptsSpecified'); % Disable warning of no subscripts deprecation for PDE toolbox in R2022b.
        specifyCoefficients(model, 'm',0, 'd',0, 'c',TP.tissueConductivity / 1000000, 'a',0, 'f',0); % Siemans/micron
        generateMesh(model);
        TP.StimulationField(diffpair) = solvepde(model);
        TP.stim_field_scale(diffpair) = 1; % Can be used to scale the amplitude of individual pulses during the simulation.
        warning('on', 'MATLAB:subscripting:noSubscriptsSpecified');  % Reenable warning for our own code to not have empty 'x()' supscripts.
        TP.StimulationModel(diffpair) = model;
        
        % Estimate current flowing through the differential pair.
        [cathode_uA, anode_uA, cathode_n, anode_n] = EstimateElectrodeCurrent(TP, diffpair);
        disp(['Current estimate at cathode ' num2str(diffpair) ' = ' num2str(cathode_uA) ' uA, n = ' num2str(cathode_n)]);
        disp(['Current estimate at anode ' num2str(diffpair) ' = ' num2str(anode_uA) ' uA, n = ' num2str(anode_n)]);
        TP.FieldStimEstimatedCurrent_uA(diffpair, :) = [cathode_uA, anode_uA];
    end
    save_figure(directory, 'stim_electrode_geometry.fig', hfig, 'close');
    
    % Plot stimulation model. This doesn't show much except current on the
    % electrode surface.  Requires zooming into the location of the electrode.
%     pdeplot3D(TP.StimulationModel(1),'ColorMapData', TP.StimulationField(1).NodalSolution);
%     hold on; % Overlay electrode wire frame
%     pdegplot(TP.StimulationModel(1),'FaceAlpha',0.4, 'FaceLabels', 'on');
%     save_figure(directory, 'stim_electrode_pair1_field.fig', gcf, 'close');
end
