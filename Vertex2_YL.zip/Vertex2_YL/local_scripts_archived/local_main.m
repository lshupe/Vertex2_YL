disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

%% Set driving current scaling of default params
input_std_scaler = 2;
input_mean_scaler = 1;
b_2_3_std_scalar = 1.25;
arb_radius_scalar = 1.5;

length = 1000;
time = 50;
% gaps in x,y at 250, 3x3 electrodes, 6 layers
coords = make_electrode_grid(1000, 0, 9);
res = run_bsf_model_local(length, time, coords, ...
    'vertex_results/nsg_long_more_electrodes', input_std_scaler, ...
    input_mean_scaler, arb_radius_scalar, b_2_3_std_scalar, false, false, true);