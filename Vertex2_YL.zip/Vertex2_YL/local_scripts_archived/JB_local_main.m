length = 1000;
time = 250;
coords = make_electrode_grid(length, length/10, 3);

%% Set driving current scaling of default params
input_std_scaler = 1.75;
input_mean_scaler = 1;

% dir = './vertex_results/2500_1p5sd_sim';
dir = './vertex_results/localmod';
res = run_bsf_model_sim(length, time, coords, dir, input_std_scaler, input_mean_scaler);
plot_lfp_signals(dir, dir, true);