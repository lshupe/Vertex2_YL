disp_with_time("Printing pwd and mfilename, then going to add that to the path")
disp_with_time(pwd);
disp_with_time(mfilename);
folder = fileparts(which(mfilename)); 
disp_with_time(folder);
addpath(genpath(folder));

disp_with_time('loading connections from directory');
% Load connections, params from relative path

% SPECIFY INPUT DIRECTORY HERE
dir = '~/vertex_results/random_con_long';
params = load_params_from_dir(dir);
[synapses, weights] = load_randomized_connectivity(params, dir); 
disp_with_time('connections loaded, generating sparse connectivity matrix');
% Generate sparse matrix
%%
connectivity_matrix = get_sparse_weighted_connectivity_2(params, synapses, weights, 'all');
disp_with_time('sparse matrix generated, calculated ground truth');
% Loop through electrodes, calculate ground truth per electrode pair
num_electrodes = length(params.RecordingSettings.meaXpositions);
%%
ground_truth_matrix = zeros(num_electrodes, num_electrodes);
for i = 1:num_electrodes
    for j = 1:num_electrodes
        disp_with_time(strcat('calculating ground truth for electrodes: ', ...
            num2str(i), ', ', num2str(j)));
        ground_truth = evaluate_ground_truth_connectivity_with_radius(...
            params, connectivity_matrix, i, j, 100);
        ground_truth_matrix(i, j) = ground_truth;
    end
end

% SPECIFY OUTPUT DIRECTORY HERE
save_path = '~/vertex_results/random_con_long/ground_truth_all_radius_100.mat';
save(save_path, 'ground_truth_matrix', '-v7.3');


        