function [params] = load_params_from_dir(saveDir)
    if ~strcmpi(saveDir(end), '/')
        saveDir = [saveDir '/'];
    end
    savedParams = load([saveDir 'parameters.mat']);
    pFields = fields(savedParams);
    params.TissueParams = savedParams.(pFields{1}){1};
    params.NeuronParams = savedParams.(pFields{1}){2};
    params.ConnectionParams = savedParams.(pFields{1}){3};
    params.RecordingSettings = savedParams.(pFields{1}){4};
    params.SimulationSettings = savedParams.(pFields{1}){5};
    % Need to remove this Composite, also never used
    params.TissueParams.compartmentlocations = []
end

