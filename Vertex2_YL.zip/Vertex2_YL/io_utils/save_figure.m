function [] = save_figure(directory, figure_name, figure_handle, close_flag)
% save_figure(directory, figure_name, figure_handle, close_flag);
% Save a figure into the results folder

try
    if ~exist(directory, 'dir')
        mkdir(directory);
    end
    saveas(figure_handle, [directory '/' figure_name]); % Matlab toolbox
catch
end

% Optionally close figure
if nargin > 3
    try
        if ~isempty(close_flag)
            if close_flag
                close(figure_handle);
            end
        end
    catch
    end
end
