function [synapses, weights] = load_randomized_connectivity(params, directory)
    % Function to save network post-initialization
    if params.SimulationSettings.parallelSim
        num_workers = params.SimulationSettings.poolSize;
        synapses = {1, num_workers};
        weights = {1, num_workers};
        for i = 1:num_workers
            synapses_file_path = strcat(directory, "/synapses_", num2str(i), ".mat");
            weights_file_path = strcat(directory, "/weights_", num2str(i), ".mat");
            synapses{i} = load(synapses_file_path).synapses_for_worker;
            weights{i} = load(weights_file_path).weights_for_worker;
        end
    else
        synapses_file_path = strcat(directory, "/synapses.mat");
        weights_file_path = strcat(directory, "/weights.mat");
        synapses = load(synapses_file_path);
        weights = load(weights_file_path);
    end
end