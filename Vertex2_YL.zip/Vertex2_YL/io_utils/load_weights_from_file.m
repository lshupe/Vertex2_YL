function [weights, errors, errstr] = load_weights_from_file(weight_file_prefix, params, current_weights)
    % Function to load network weights post-initialization.
    % Weight files are usually copied from a previous vertex_results
    % folder to the main simulation folder for this purpose.
    % Example:
    %   [weightArr, errors, errstr] = load_weights_from_file('.\weights2_', params, weightArr);
    %
    % Some error checking is done to ensure the current network topology
    % matches the loaded weights.  The errors return value returns non-zero
    % if an error is detected, and errstr will contain a description.
    
    errors = 0;
    errstr = '';
    if params.SimulationSettings.parallelSim
        % Parallel simulation has weights as a composite variable with a
        % file saved for each Lab.
        num_workers = params.SimulationSettings.poolSize;
        weights = current_weights;
        for i = 1:num_workers
            weights_file_path = strcat(weight_file_prefix, num2str(i), '.mat');
            try
                loadedData = load(weights_file_path);
                ff = fields(loadedData); % First field holds weights
                w = loadedData.(ff{1});
                cw = current_weights{i};
                n1 = length(w);
                n2 = length(cw);
                if n1 ~= n2
                    errors = errors + 1;
                    errstr = ['Weight-list length mismatch for Lab ' num2str(i)];
                else
                    % Make sure all units have same number of synapses
                    for j = 1:n1
                        nsyn1 = length(w{j});
                        nsyn2 = length(cw{j});
                        if nsyn1 ~= nsyn2
                            errors = errors + 1;
                            errstr = ['Weight-list synapase mismatch for Lab ' num2str(i), ' Neuron ' num2str(j)];
                            break;
                        end
                    end
                    weights{i} = w;
                end
            catch
                errors = errors + 1;
                errstr = ['Could not load weights from: ' weights_file_path];
            end
        end
    else
        % Non parallel simulation has all weights in one file.
        weights_file_path = strcat(weight_file_prefix, '.mat');
        try
            loadedData = load(weights_file_path);
            ff = fields(loadedData); % First field holds weights
            weights = loadedData.(ff{1});
            n1 = length(weights);
            for j = 1:n1
                nsyn1 = length(weights{j});
                nsyn2 = length(current_weights{j});
                if nsyn1 ~= nsyn2
                    errors = errors + 1;
                    errstr = ['Weight-list synapase mismatch for Neuron ' num2str(j)];
                    break;
                end
            end
        catch
            errors = errors + 1;
            errstr = ['Could not load weights from: ' weights_file_path];
        end
    end
end