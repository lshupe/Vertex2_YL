function [] = save_network(directory, params, connections, electrodes)
    % initialize directory
    if ~exist(directory, 'dir')
        mkdir(directory);
    end
    % Function to save network post-initialization
    if params.SimulationSettings.parallelSim
        % simulation was done in parallel, need to put composites 
        % of electrodes and conections into normal arrays
        for i = 1:length(connections)
            connections_file_path = strcat(directory, "/connections_", num2str(i), ".mat");
            electrodes_file_path = strcat(directory, "/electrodes_", num2str(i), ".mat");
            connections_for_worker = connections{i};
            save(connections_file_path, 'connections_for_worker', '-v7.3');
            electrodes_for_worker = electrodes{i};
            save(electrodes_file_path, 'electrodes_for_worker', '-v7.3');
        end
    else
        connections_file_path = strcat(directory, "/connections.mat");
        electrodes_file_path = strcat(directory, "/electrodes.mat");
        save(connections_file_path, 'connections', '-v7.3');
        save(electrodes_file_path, 'electrodes', '-v7.3');
    end
    params_file_path = strcat(directory, "/params.mat");
    save(params_file_path, 'params', '-v7.3');
    %dsave(params_file_path, 'params');
end