function [] = save_ground_truth(directory, params, connections)
    disp_with_time('Calculating ground truth given connection params');
    % Generate sparse matrix
    connectivity_matrix = get_sparse_weighted_connectivity(params, connections);
    disp_with_time('Sparse matrix generated, calculating ground truth');
    % Loop through electrodes, calculate ground truth per electrode pair
    num_electrodes = length(params.RecordingSettings.meaXpositions);
    ground_truth_matrix = zeros(num_electrodes, num_electrodes);
    for i = 1:num_electrodes
        for j = i:num_electrodes
            disp_with_time(strcat('calculating ground truth for electrodes: ', ...
                num2str(i), ', ', num2str(j)));
            ground_truth = evaluate_ground_truth_connectivity(...
                params, connectivity_matrix, i, j);
            ground_truth_matrix(i, j) = ground_truth;
            ground_truth_matrix(j, i) = ground_truth;

        end
    end

    % SPECIFY OUTPUT DIRECTORY HERE
    save_path = strcat(directory, '/ground_truth.mat');
    save(save_path, 'ground_truth_matrix', '-v7.3');
end