function [params, connections, electrodes] = load_network(directory)
    params_file_path = strcat(directory, "/params.mat");
    params = load(params_file_path, 'params');
    params = params.params;
    % Function to save network post-initialization
    if params.SimulationSettings.parallelSim
        num_workers = params.SimulationSettings.poolSize;
        connections = {1, num_workers};
        electrodes = {1, num_workers};
        for i = 1:num_workers
            connections_file_path = strcat(directory, "/connections_", num2str(i), ".mat");
            electrodes_file_path = strcat(directory, "/electrodes_", num2str(i), ".mat");
            connections{i} = load(connections_file_path).connections_for_worker;
            electrodes{i} = load(electrodes_file_path).electrodes_for_worker;
        end
    else
        connections_file_path = strcat(directory, "/connections.mat");
        electrodes_file_path = strcat(directory, "/electrodes.mat");
        connections = load(connections_file_path);
        electrodes = load(electrodes_file_path);
    end
end