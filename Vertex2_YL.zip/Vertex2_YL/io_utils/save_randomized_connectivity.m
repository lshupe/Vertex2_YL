function [] = save_randomized_connectivity(directory, params, synapses, weights)
    % initialize directory
    if ~exist(directory, 'dir')
        mkdir(directory);
    end
    % Function to save network post-initialization
    if params.SimulationSettings.parallelSim
        % simulation was done in parallel, need to put composites 
        % of electrodes and conections into normal arrays
        for i = 1:length(synapses)
            synapses_file_path = strcat(directory, "/synapses_", num2str(i), ".mat");
            weights_file_path = strcat(directory, "/weights_", num2str(i), ".mat");
            synapses_for_worker = synapses{i};
            save(synapses_file_path, 'synapses_for_worker', '-v7.3');
            weights_for_worker = weights{i};
            save(weights_file_path, 'weights_for_worker', '-v7.3');
        end
    else
        synapses_file_path = strcat(directory, "/synapses.mat");
        weights_file_path = strcat(directory, "/weights.mat");
        save(synapses_file_path, 'synapses', '-v7.3');
        save(weights_file_path, 'weights', '-v7.3');
    end
end